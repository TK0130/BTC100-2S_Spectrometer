#!/usr/bin/env python3
"""
BWTEK BTC100/BTC110/BRC100/BRC110/BTC200 spectrometer control software.

Version: v14 hot-pixel/black-level scaling controls.

Portable design:
- Standard library only for the simulator, CLI, CSV/JSON output, processing, and Tk GUI.
- Optional pyserial is used only when connecting to real RS-232/USB-serial hardware.

Typical use with real hardware:
    python bwtek_spectrometer.py list-ports
    python bwtek_spectrometer.py --model BTC100 --port COM3 acquire --integration 200 --average 1 --output spectrum.csv --plot

Simulator mode, no hardware or third-party packages needed:
    python bwtek_spectrometer.py --simulate acquire --integration 200 --output simulated.csv --graph simulated.svg --plot
    python bwtek_spectrometer.py --simulate live --integration 200 --average 1
    python bwtek_spectrometer.py --simulate gui

Protocol notes implemented from the supplied BWTEK command set:
- Default RS-232: 8 data bits, no parity, 1 stop bit, no flow control.
- BTC100/BTC110/BRC100 default baud 9600; BRC110 default baud 19200.
- S starts spectral acquisition.
- Q initializes defaults.
- A {n}, I {ms}, K {code}, C {n} {float}, P ..., T ..., x ... set parameters.
- ?A, ?K, ?I, ?a, ?C, ?v, ?t, ?P, ?T, ?x query parameters.
- BTC100 uses the older compact command form from public BTC100 notes, e.g.
  I200, A1, K3 instead of the later spaced form I 200, A 1, K 3. This driver
  is deliberately tolerant of command echo, which older BTC-series firmware and
  some RS-232 adapters may return before ACK/NAK.
- Lowercase a and b are used for ASCII and compressed binary data modes because the
  command summary uses lowercase and uppercase A is also the averaging command.
  The code optionally falls back to uppercase A/B for older firmware/document variants.
"""

from __future__ import annotations

import argparse
import csv
import html
import json
import math
import os
import queue
import random
import re
import sys
import threading
import time
import webbrowser
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple, Union

ACK_BYTE = 0x06
NAK_BYTE = 0x15
DEFAULT_PIXEL_COUNT = 2048

BAUD_CODES: Dict[int, int] = {
    7: 600,
    6: 1200,
    5: 2400,
    4: 4800,
    3: 9600,
    2: 19200,
    1: 38400,
    0: 115200,
}
BAUD_TO_CODE: Dict[int, int] = {baud: code for code, baud in BAUD_CODES.items()}


class SpectrometerError(Exception):
    """Base class for spectrometer errors."""


class ProtocolError(SpectrometerError):
    """Raised when the instrument response cannot be parsed."""


class ProtocolTimeout(SpectrometerError):
    """Raised when the instrument does not respond in time."""


class NakError(SpectrometerError):
    """Raised when the spectrometer returns NAK."""


class ConfigurationError(SpectrometerError):
    """Raised for invalid model, range, or setup values."""


@dataclass(frozen=True)
class SpectrometerModelSpec:
    name: str
    default_baud: int
    default_integration_ms: int
    min_integration_ms: int
    max_integration_ms: int
    max_average: int
    adc_bits: int
    pixel_count: int = DEFAULT_PIXEL_COUNT
    supports_pixel_mode: bool = False
    supports_time_delay: bool = False
    supports_cooler_temperature: bool = False
    supports_multiplier: bool = False
    compact_commands: bool = False

    @property
    def adc_max(self) -> int:
        return (1 << self.adc_bits) - 1


MODEL_SPECS: Dict[str, SpectrometerModelSpec] = {
    "BTC100": SpectrometerModelSpec(
        name="BTC100",
        default_baud=9600,
        default_integration_ms=50,
        min_integration_ms=50,
        max_integration_ms=65000,
        max_average=65535,
        adc_bits=16,
        supports_cooler_temperature=True,
        compact_commands=True,
    ),
    "BTC110": SpectrometerModelSpec(
        name="BTC110",
        default_baud=9600,
        default_integration_ms=21,
        min_integration_ms=21,
        max_integration_ms=65000,
        max_average=65535,
        adc_bits=16,
        supports_cooler_temperature=True,
    ),
    "BRC100": SpectrometerModelSpec(
        name="BRC100",
        default_baud=9600,
        default_integration_ms=35,
        min_integration_ms=35,
        max_integration_ms=65000,
        max_average=15,
        adc_bits=12,
    ),
    "BRC110": SpectrometerModelSpec(
        name="BRC110",
        default_baud=19200,
        default_integration_ms=35,
        min_integration_ms=35,
        max_integration_ms=65000,
        max_average=65535,
        adc_bits=12,
        supports_pixel_mode=True,
        supports_time_delay=True,
    ),
    "BTC200": SpectrometerModelSpec(
        name="BTC200",
        default_baud=9600,
        default_integration_ms=21,
        min_integration_ms=21,
        max_integration_ms=65000,
        max_average=65535,
        adc_bits=16,
        supports_multiplier=True,
    ),
}


# ---------------------------------------------------------------------------
# Compression and binary conversion
# ---------------------------------------------------------------------------


def signed_byte(value: int) -> int:
    """Interpret one byte as a signed 8-bit integer."""
    if not 0 <= value <= 255:
        raise ValueError("byte value out of range")
    return value - 256 if value >= 128 else value


def uint16_to_bytes(value: int) -> bytes:
    """Encode unsigned 16-bit integer as MSB then LSB."""
    if not 0 <= int(value) <= 0xFFFF:
        raise ValueError("uint16 value out of range")
    value = int(value)
    return bytes(((value >> 8) & 0xFF, value & 0xFF))


def bytes_to_uint16(msb: int, lsb: int) -> int:
    """Decode unsigned 16-bit integer, MSB first."""
    return ((msb & 0xFF) << 8) | (lsb & 0xFF)


def encode_uncompressed_binary(values: Sequence[int]) -> bytes:
    """Encode values as 16-bit MSB/LSB pairs."""
    out = bytearray()
    for value in values:
        out.extend(uint16_to_bytes(int(value)))
    return bytes(out)


def decode_uncompressed_binary(data: bytes, count: Optional[int] = None) -> List[int]:
    """Decode 16-bit MSB/LSB binary values."""
    if len(data) % 2:
        raise ProtocolError("uncompressed binary payload has an odd number of bytes")
    values = [bytes_to_uint16(data[i], data[i + 1]) for i in range(0, len(data), 2)]
    if count is not None and len(values) != count:
        raise ProtocolError("decoded %d values, expected %d" % (len(values), count))
    return values


def encode_compressed_binary(values: Sequence[int]) -> bytes:
    """
    Encode the BTC110/BRC100-style compressed binary stream.

    Each value is either sent as an absolute value:
        0x80, high_byte, low_byte
    or as a one-byte signed delta relative to the previous value. 0x80 is reserved
    as the absolute-value sentinel, so a delta of -128 is sent as an absolute value.
    The first pixel is always absolute.
    """
    out = bytearray()
    prev = 0
    for index, raw_value in enumerate(values):
        value = int(raw_value)
        if not 0 <= value <= 0xFFFF:
            raise ValueError("compressed binary supports unsigned 16-bit values only")
        delta = value - prev
        if index == 0 or delta < -127 or delta > 127:
            out.append(0x80)
            out.extend(uint16_to_bytes(value))
        else:
            out.append(delta & 0xFF)
        prev = value
    return bytes(out)


def decode_compressed_binary_bytes(data: bytes, count: Optional[int] = None) -> List[int]:
    """Decode a compressed binary payload already present in memory."""
    values: List[int] = []
    prev = 0
    i = 0
    while i < len(data) and (count is None or len(values) < count):
        first = data[i]
        i += 1
        if first == 0x80:
            if i + 2 > len(data):
                raise ProtocolError("truncated compressed absolute-value token")
            value = bytes_to_uint16(data[i], data[i + 1])
            i += 2
        else:
            value = prev + signed_byte(first)
        values.append(value)
        prev = value
    if count is not None and len(values) != count:
        raise ProtocolError("decoded %d values, expected %d" % (len(values), count))
    return values


def decode_compressed_binary_stream(read_byte: Callable[[], int], count: int) -> List[int]:
    """Decode compressed values from a byte-reader callback until count values exist."""
    values: List[int] = []
    prev = 0
    while len(values) < count:
        first = read_byte()
        if first == 0x80:
            high = read_byte()
            low = read_byte()
            value = bytes_to_uint16(high, low)
        else:
            value = prev + signed_byte(first)
        values.append(value)
        prev = value
    return values


def decode_compressed_binary_partial(data: bytes, adc_max: int = 0xFFFF) -> List[int]:
    """Decode as many complete compressed values as are present in data.

    This is intentionally tolerant: it stops on a truncated final absolute-value token
    instead of blocking forever. It is used for old BTC100 units where the scan payload
    length is variable and some adapters/firmware add echo or ACK bytes around the scan.
    """
    values: List[int] = []
    prev = 0
    i = 0
    while i < len(data):
        first = data[i]
        i += 1
        if first == 0x80:
            if i + 2 > len(data):
                break
            value = bytes_to_uint16(data[i], data[i + 1])
            i += 2
        else:
            value = prev + signed_byte(first)
        if value < 0 or value > adc_max:
            # Bad alignment or an ASCII/status prefix interpreted as binary. Keep the
            # value out of the result so scoring can reject this offset.
            break
        values.append(value)
        prev = value
    return values


def parse_ascii_spectrum_bytes(data: bytes, count: int) -> Optional[List[int]]:
    """Return integer values if data appears to be an ASCII spectrum, else None."""
    if not data:
        return None
    printable = sum(1 for b in data if b in b"0123456789+- \t\r\n,;")
    if printable < max(16, int(len(data) * 0.85)):
        return None
    text = data.decode("ascii", errors="ignore")
    values = [int(m.group(0)) for m in re.finditer(r"[-+]?\d+", text)]
    if len(values) >= max(16, min(count, 128)):
        return values[:count]
    return None


def decode_compressed_binary_best_effort(data: bytes, count: int, adc_max: int = 0xFFFF) -> Tuple[List[int], int, str]:
    """Decode a variable-length compressed scan, trying to recover from prefixes.

    Returns (values, offset, note). The offset is the number of leading bytes ignored.
    """
    if not data:
        raise ProtocolTimeout("no spectral bytes received")

    # ASCII mode can happen if the unit ignored a mode change or was left in ASCII by
    # another program. Detect it and parse instead of feeding digits into the binary decoder.
    ascii_values = parse_ascii_spectrum_bytes(data, count)
    if ascii_values is not None:
        return ascii_values, 0, "parsed ASCII-looking scan payload"

    # Strip common harmless prefixes: ACK, CR/LF, and echoed S command.
    stripped = data
    prefix_len = 0
    changed = True
    while changed and stripped:
        changed = False
        while stripped and stripped[0] in (ACK_BYTE, 10, 13, 0):
            stripped = stripped[1:]
            prefix_len += 1
            changed = True
        if len(stripped) >= 2 and stripped[:1].upper() == b"S" and stripped[1] in (10, 13, 32):
            drop = 2
            if len(stripped) >= 3 and stripped[2] in (10, 13):
                drop = 3
            stripped = stripped[drop:]
            prefix_len += drop
            changed = True

    candidates: List[Tuple[int, int, List[int]]] = []
    max_offset = min(16, len(stripped))
    for off in range(max_offset + 1):
        vals = decode_compressed_binary_partial(stripped[off:], adc_max=adc_max)
        if not vals:
            continue
        # Lower score is better. Prefer exact/near expected count, then less offset.
        score = abs(len(vals) - count) * 100 + off
        if len(vals) > count:
            score += (len(vals) - count) * 10
        candidates.append((score, prefix_len + off, vals))
    if not candidates:
        raise ProtocolError("could not decode compressed scan payload; first bytes=%r" % data[:32])
    candidates.sort(key=lambda item: item[0])
    _, offset, values = candidates[0]
    note = "decoded compressed payload"
    if offset:
        note += "; ignored %d leading status/echo byte(s)" % offset
    if len(values) > count:
        values = values[:count]
        note += "; trimmed to %d pixels" % count
    elif len(values) < count:
        note += "; partial scan: %d/%d pixels" % (len(values), count)
    return values, offset, note


# ---------------------------------------------------------------------------
# Data classes and processing helpers
# ---------------------------------------------------------------------------


@dataclass
class Spectrum:
    pixels: List[int]
    intensities: List[float]
    wavelengths_nm: Optional[List[float]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    corrected: Optional[List[float]] = None
    dark: Optional[List[float]] = None
    reference: Optional[List[float]] = None

    def __post_init__(self) -> None:
        if len(self.pixels) != len(self.intensities):
            raise ValueError("pixels and intensities must have the same length")
        if self.wavelengths_nm is not None and len(self.wavelengths_nm) != len(self.intensities):
            raise ValueError("wavelengths and intensities must have the same length")
        for optional_name in ("corrected", "dark", "reference"):
            values = getattr(self, optional_name)
            if values is not None and len(values) != len(self.intensities):
                raise ValueError("%s length does not match intensities" % optional_name)

    def active_values(self) -> List[float]:
        return list(self.corrected if self.corrected is not None else self.intensities)

    def peak(self) -> float:
        values = self.active_values()
        return max(values) if values else float("nan")

    def save_csv(self, path: str) -> None:
        """Save spectrum as CSV with metadata comments at the top."""
        with open(path, "w", newline="", encoding="utf-8") as handle:
            handle.write("# BWTEK spectrometer spectrum\n")
            for key in sorted(self.metadata):
                value = self.metadata[key]
                handle.write("# %s=%s\n" % (key, json.dumps(value, sort_keys=True)))
            fieldnames = ["pixel"]
            if self.wavelengths_nm is not None:
                fieldnames.append("wavelength_nm")
            fieldnames.append("intensity")
            if self.dark is not None:
                fieldnames.append("dark")
            if self.reference is not None:
                fieldnames.append("reference")
            if self.corrected is not None:
                fieldnames.append("corrected")
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            for i, pixel in enumerate(self.pixels):
                row: Dict[str, Union[int, float, str]] = {"pixel": pixel, "intensity": self.intensities[i]}
                if self.wavelengths_nm is not None:
                    row["wavelength_nm"] = self.wavelengths_nm[i]
                if self.dark is not None:
                    row["dark"] = self.dark[i]
                if self.reference is not None:
                    row["reference"] = self.reference[i]
                if self.corrected is not None:
                    row["corrected"] = self.corrected[i]
                writer.writerow(row)

    def save_json(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(
                {
                    "metadata": self.metadata,
                    "pixels": self.pixels,
                    "wavelengths_nm": self.wavelengths_nm,
                    "intensities": self.intensities,
                    "dark": self.dark,
                    "reference": self.reference,
                    "corrected": self.corrected,
                },
                handle,
                indent=2,
                sort_keys=True,
            )


def validate_equal_length(*series: Optional[Sequence[float]]) -> int:
    lengths = [len(s) for s in series if s is not None]
    if not lengths:
        return 0
    first = lengths[0]
    for length in lengths[1:]:
        if length != first:
            raise ValueError("series lengths do not match")
    return first


def align_series_to_pixels(
    series: Sequence[float],
    pixels: Sequence[int],
    name: str = "series",
) -> List[float]:
    """Return values from a stored full-spectrum series aligned to current pixels.

    Some BTC100 compressed scans occasionally decode to 2047/2046 points instead of
    exactly 2048, while a captured dark/reference vector is usually 2048 points.
    Dark correction should not fail in that case; it should apply the dark value for
    each pixel that was actually returned. This helper also supports future pixel
    modes where the returned pixel list is not simply 0..N-1.
    """
    target_count = len(pixels)
    source_count = len(series)
    if source_count == target_count:
        return [float(v) for v in series]
    if target_count == 0:
        return []
    if source_count == 1:
        return [float(series[0]) for _ in pixels]
    try:
        max_pixel = max(int(p) for p in pixels)
        min_pixel = min(int(p) for p in pixels)
    except ValueError:
        return []
    if min_pixel >= 0 and max_pixel < source_count:
        return [float(series[int(p)]) for p in pixels]

    # Be tolerant of BTC100 compressed-scan edge cases.  Depending on where the
    # stream goes quiet, either the stored dark or the current scan can be a few
    # samples shorter.  A strict failure here makes dark correction unusable; a
    # small index-based alignment with last-value padding is much better for a
    # dark/background trace.
    if abs(source_count - target_count) <= 16:
        fallback = float(series[-1]) if source_count else 0.0
        aligned: List[float] = []
        for index, pixel in enumerate(pixels):
            ip = int(pixel)
            if 0 <= ip < source_count:
                aligned.append(float(series[ip]))
            elif index < source_count:
                aligned.append(float(series[index]))
            else:
                aligned.append(fallback)
        return aligned

    raise ValueError(
        "%s length %d cannot be aligned to %d returned pixels "
        "(pixel range %d..%d)" % (name, source_count, target_count, min_pixel, max_pixel)
    )


def subtract_dark(values: Sequence[float], dark: Sequence[float]) -> List[float]:
    """Subtract a dark trace, tolerating small BTC100 length differences.

    Older BTC100 compressed transfers can occasionally return a point or two fewer
    than the stored dark trace.  Correction should use the overlapping samples
    instead of failing with a series length error.
    """
    n = min(len(values), len(dark))
    if n == 0:
        return []
    return [float(values[i]) - float(dark[i]) for i in range(n)]


def transmittance(values: Sequence[float], dark: Sequence[float], reference: Sequence[float]) -> List[float]:
    n = min(len(values), len(dark), len(reference))
    out: List[float] = []
    for i in range(n):
        value, d, ref = values[i], dark[i], reference[i]
        numerator = float(value) - float(d)
        denominator = float(ref) - float(d)
        out.append(numerator / denominator if denominator else float("nan"))
    return out


def absorbance(values: Sequence[float], dark: Sequence[float], reference: Sequence[float]) -> List[float]:
    tx = transmittance(values, dark, reference)
    out: List[float] = []
    for item in tx:
        if item and item > 0 and math.isfinite(item):
            out.append(-math.log10(item))
        else:
            out.append(float("nan"))
    return out


def boxcar_smooth(values: Sequence[float], width: int) -> List[float]:
    width = int(width)
    if width <= 1:
        return [float(v) for v in values]
    radius = width // 2
    out: List[float] = []
    running = [float(v) for v in values]
    n = len(running)
    for i in range(n):
        start = max(0, i - radius)
        end = min(n, i + radius + 1)
        out.append(sum(running[start:end]) / (end - start))
    return out


def median_filter(values: Sequence[float], width: int) -> List[float]:
    """Return an odd-width median-filtered copy of values.

    The filter is intentionally simple and standard-library-only.  Even widths are
    rounded up to the next odd width so the selected point remains centered.
    """
    width = int(width)
    if width <= 1:
        return [float(v) for v in values]
    if width % 2 == 0:
        width += 1
    radius = width // 2
    running = [float(v) for v in values]
    out: List[float] = []
    n = len(running)
    for i in range(n):
        start = max(0, i - radius)
        end = min(n, i + radius + 1)
        window = sorted(running[start:end])
        m = len(window) // 2
        if len(window) % 2:
            out.append(window[m])
        else:
            out.append((window[m - 1] + window[m]) / 2.0)
    return out


def triangular_smooth(values: Sequence[float], width: int) -> List[float]:
    """Return a triangular-weighted moving average.

    This is a gentle smoothing option that preserves broad peak positions better
    than a plain boxcar of the same width while remaining standard-library-only.
    """
    width = int(width)
    if width <= 1:
        return [float(v) for v in values]
    if width % 2 == 0:
        width += 1
    radius = width // 2
    running = [float(v) for v in values]
    out: List[float] = []
    n = len(running)
    for i in range(n):
        total = 0.0
        wsum = 0.0
        for j in range(max(0, i - radius), min(n, i + radius + 1)):
            w = float(radius + 1 - abs(j - i))
            total += running[j] * w
            wsum += w
        out.append(total / wsum if wsum else running[i])
    return out


def gaussian_smooth(values: Sequence[float], width: int) -> List[float]:
    """Return an approximate Gaussian-smoothed copy of values."""
    width = int(width)
    if width <= 1:
        return [float(v) for v in values]
    if width % 2 == 0:
        width += 1
    radius = width // 2
    sigma = max(width / 6.0, 0.5)
    kernel = [math.exp(-0.5 * ((k / sigma) ** 2)) for k in range(-radius, radius + 1)]
    running = [float(v) for v in values]
    out: List[float] = []
    n = len(running)
    for i in range(n):
        total = 0.0
        wsum = 0.0
        for offset, w in zip(range(-radius, radius + 1), kernel):
            j = i + offset
            if 0 <= j < n:
                total += running[j] * w
                wsum += w
        out.append(total / wsum if wsum else running[i])
    return out


def savitzky_golay_smooth(values: Sequence[float], width: int) -> List[float]:
    """Quadratic Savitzky-Golay-like smoothing.

    A local degree-2 least-squares fit is evaluated at the center pixel.  It is
    useful for smoothing spectra while preserving peak height and width better
    than a boxcar.
    """
    width = int(width)
    if width <= 2:
        return [float(v) for v in values]
    if width % 2 == 0:
        width += 1
    radius = width // 2
    running = [float(v) for v in values]
    n = len(running)
    out: List[float] = []
    for i in range(n):
        xs: List[float] = []
        ys: List[float] = []
        for j in range(max(0, i - radius), min(n, i + radius + 1)):
            xs.append(float(j - i))
            ys.append(running[j])
        if len(xs) < 3:
            out.append(running[i])
            continue
        s0 = float(len(xs))
        s1 = sum(xs)
        s2 = sum(x*x for x in xs)
        s3 = sum(x*x*x for x in xs)
        s4 = sum(x*x*x*x for x in xs)
        t0 = sum(ys)
        t1 = sum(x*y for x, y in zip(xs, ys))
        t2 = sum(x*x*y for x, y in zip(xs, ys))
        # Solve only for the intercept of [ [s0 s1 s2], [s1 s2 s3], [s2 s3 s4] ] * [a b c] = [t0 t1 t2].
        det = s0*(s2*s4 - s3*s3) - s1*(s1*s4 - s3*s2) + s2*(s1*s3 - s2*s2)
        if abs(det) < 1e-12:
            out.append(running[i])
            continue
        det_a = t0*(s2*s4 - s3*s3) - s1*(t1*s4 - s3*t2) + s2*(t1*s3 - s2*t2)
        out.append(det_a / det)
    return out


def despike_filter(values: Sequence[float], width: int = 5, threshold: float = 6.0) -> List[float]:
    """Replace isolated spikes using a local median/MAD detector.

    A point is replaced by the local median when its distance from that median is
    more than threshold times the local median absolute deviation.  This is useful
    for hot pixels and single-pixel serial decode glitches, but should be disabled
    for very narrow line spectra when exact peak amplitudes matter.
    """
    width = max(3, int(width or 5))
    if width % 2 == 0:
        width += 1
    threshold = float(threshold or 0.0)
    if threshold <= 0:
        return [float(v) for v in values]
    radius = width // 2
    running = [float(v) for v in values]
    out = list(running)
    n = len(running)
    for i in range(n):
        start = max(0, i - radius)
        end = min(n, i + radius + 1)
        window = sorted(running[start:end])
        med = window[len(window)//2]
        devs = sorted(abs(v - med) for v in window)
        mad = devs[len(devs)//2]
        scale = max(1e-9, 1.4826 * mad)
        if abs(running[i] - med) > threshold * scale:
            out[i] = med
    return out


def apply_display_filters(
    values: Sequence[float],
    median_width: int = 1,
    smooth_width: int = 1,
    smooth_kind: str = "boxcar",
    despike_enabled: bool = False,
    despike_threshold: float = 6.0,
) -> List[float]:
    """Apply display-only filters in a predictable order.

    Order: median -> optional despike -> selected smoother.  The stored raw scan
    remains unchanged, so these can all be adjusted after acquisition and redrawn.
    """
    out = [float(v) for v in values]
    if int(median_width or 1) > 1:
        out = median_filter(out, int(median_width))
    if despike_enabled:
        out = despike_filter(out, max(3, int(median_width or 5)), float(despike_threshold or 6.0))
    kind = (smooth_kind or "boxcar").strip().lower()
    if int(smooth_width or 1) > 1:
        if kind in ("none", "off"):
            pass
        elif kind in ("triangular", "triangle"):
            out = triangular_smooth(out, int(smooth_width))
        elif kind == "gaussian":
            out = gaussian_smooth(out, int(smooth_width))
        elif kind in ("savitzky-golay", "savitzky_golay", "savgol"):
            out = savitzky_golay_smooth(out, int(smooth_width))
        else:
            out = boxcar_smooth(out, int(smooth_width))
    return out


def _is_number(text: Any) -> bool:
    try:
        v = float(str(text).strip())
        return math.isfinite(v)
    except Exception:
        return False


def _clean_header_name(name: str) -> str:
    return ''.join(ch.lower() if ch.isalnum() else '_' for ch in str(name).strip()).strip('_')


def load_photon_transfer_csv(path: str) -> List[Tuple[float, float]]:
    """Load mean/variance pairs from a photon-transfer CSV file.

    Supported formats:
    - Header columns such as mean/counts/signal/intensity and variance/var/noise_var.
    - Header columns with std/sigma/noise_std, which are squared into variance.
    - No header: the first two numeric columns are interpreted as mean and variance.

    Lines starting with # are ignored.
    """
    rows: List[List[str]] = []
    with open(path, 'r', newline='', encoding='utf-8-sig') as handle:
        reader = csv.reader(line for line in handle if not line.lstrip().startswith('#'))
        for row in reader:
            if row and any(str(cell).strip() for cell in row):
                rows.append(row)
    if not rows:
        raise ConfigurationError('photon transfer CSV is empty')

    header: Optional[List[str]] = None
    data_rows = rows
    if any(not _is_number(cell) for cell in rows[0]):
        header = [_clean_header_name(cell) for cell in rows[0]]
        data_rows = rows[1:]

    pairs: List[Tuple[float, float]] = []
    if header:
        mean_keys = ('mean', 'avg', 'average', 'signal', 'signal_mean', 'mean_count', 'mean_counts', 'counts', 'count', 'adu', 'intensity', 'level')
        var_keys = ('variance', 'var', 'signal_variance', 'noise_variance', 'var_counts', 'variance_counts')
        std_keys = ('std', 'stdev', 'stddev', 'sigma', 'noise', 'noise_std', 'rms')
        def find_col(candidates: Tuple[str, ...]) -> Optional[int]:
            for candidate in candidates:
                for i, name in enumerate(header or []):
                    if name == candidate or name.endswith('_' + candidate) or candidate in name:
                        return i
            return None
        mean_i = find_col(mean_keys)
        var_i = find_col(var_keys)
        std_i = None if var_i is not None else find_col(std_keys)
        if mean_i is None or (var_i is None and std_i is None):
            raise ConfigurationError('PTC CSV needs mean and variance columns, or mean and std/noise columns')
        for row in data_rows:
            try:
                if mean_i >= len(row):
                    continue
                x = float(row[mean_i])
                if var_i is not None:
                    if var_i >= len(row):
                        continue
                    y = float(row[var_i])
                else:
                    if std_i is None or std_i >= len(row):
                        continue
                    y = float(row[std_i]) ** 2
                if math.isfinite(x) and math.isfinite(y) and y >= 0:
                    pairs.append((x, y))
            except Exception:
                continue
    else:
        for row in data_rows:
            nums = []
            for cell in row:
                try:
                    val = float(cell)
                    if math.isfinite(val):
                        nums.append(val)
                except Exception:
                    pass
            if len(nums) >= 2 and nums[1] >= 0:
                pairs.append((nums[0], nums[1]))

    if len(pairs) < 2:
        raise ConfigurationError('PTC CSV must contain at least two numeric mean/variance points')
    pairs.sort(key=lambda item: item[0])
    return pairs


def fit_photon_transfer_curve(pairs: Sequence[Tuple[float, float]]) -> Dict[str, float]:
    """Fit variance = slope * mean + intercept for PTC data.

    In ADU/count units, slope ~= 1 / conversion_gain_e_per_count.  The zero-variance
    x-intercept, -intercept/slope, is a useful estimated black/offset count when
    the CSV used raw mean counts rather than dark-subtracted signal.
    """
    clean = [(float(x), float(y)) for x, y in pairs if math.isfinite(float(x)) and math.isfinite(float(y))]
    if len(clean) < 2:
        raise ConfigurationError('not enough finite PTC points to fit')
    xs = [x for x, _y in clean]
    ys = [y for _x, y in clean]
    n = float(len(clean))
    sx = sum(xs); sy = sum(ys)
    sxx = sum(x*x for x in xs); sxy = sum(x*y for x, y in clean)
    denom = n * sxx - sx * sx
    if abs(denom) < 1e-18:
        raise ConfigurationError('PTC mean values do not span a usable range')
    slope = (n * sxy - sx * sy) / denom
    intercept = (sy - slope * sx) / n
    if not math.isfinite(slope) or slope <= 0:
        raise ConfigurationError('PTC fit produced a non-positive slope')
    black = -intercept / slope if slope else float('nan')
    gain = 1.0 / slope
    read_noise_counts = math.sqrt(max(0.0, intercept)) if math.isfinite(intercept) else float('nan')
    read_noise_electrons = read_noise_counts * gain if math.isfinite(read_noise_counts) else float('nan')
    y_mean = sy / n
    ss_tot = sum((y - y_mean) ** 2 for y in ys)
    ss_res = sum((y - (slope * x + intercept)) ** 2 for x, y in clean)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 1.0
    return {
        'slope_variance_per_count': slope,
        'intercept_variance': intercept,
        'black_level_counts': black,
        'conversion_gain_e_per_count': gain,
        'read_noise_counts': read_noise_counts,
        'read_noise_electrons': read_noise_electrons,
        'r2': r2,
        'point_count': float(len(clean)),
    }


def normalize(values: Sequence[float], target: float = 1.0) -> List[float]:
    max_abs = max((abs(float(v)) for v in values), default=0.0)
    if not max_abs:
        return [0.0 for _ in values]
    return [float(v) / max_abs * target for v in values]


def wavelength_from_coefficients(pixel: float, coefficients: Sequence[float]) -> float:
    if len(coefficients) != 4:
        raise ValueError("exactly four wavelength coefficients are required")
    a0, a1, a2, a3 = [float(c) for c in coefficients]
    return a0 + a1 * pixel + a2 * pixel * pixel + a3 * pixel * pixel * pixel


def wavelengths_for_pixels(pixels: Sequence[int], coefficients: Sequence[float]) -> List[float]:
    return [wavelength_from_coefficients(float(pixel), coefficients) for pixel in pixels]


def apply_wavelength_calibration(spectrum: Spectrum, coefficients: Optional[Sequence[float]]) -> Spectrum:
    """Attach wavelength values to an existing spectrum using polynomial coefficients."""
    if coefficients is None:
        spectrum.wavelengths_nm = None
        spectrum.metadata.pop("coefficients", None)
        spectrum.metadata.pop("wavelength_calibrated", None)
        return spectrum
    coeffs = [float(c) for c in coefficients]
    if len(coeffs) != 4:
        raise ConfigurationError("four wavelength coefficients are required")
    spectrum.wavelengths_nm = wavelengths_for_pixels(spectrum.pixels, coeffs)
    spectrum.metadata["coefficients"] = list(coeffs)
    spectrum.metadata["wavelength_calibrated"] = True
    return spectrum


def solve_linear_system(matrix: List[List[float]], vector: List[float]) -> List[float]:
    """Solve a small dense linear system with Gauss-Jordan elimination."""
    n = len(vector)
    if any(len(row) != n for row in matrix):
        raise ValueError("matrix must be square")
    aug = [list(map(float, matrix[i])) + [float(vector[i])] for i in range(n)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(aug[r][col]))
        if abs(aug[pivot][col]) < 1e-12:
            raise ConfigurationError("calibration points are singular; use more separated pixel positions")
        if pivot != col:
            aug[col], aug[pivot] = aug[pivot], aug[col]
        scale = aug[col][col]
        aug[col] = [value / scale for value in aug[col]]
        for row in range(n):
            if row == col:
                continue
            factor = aug[row][col]
            if factor:
                aug[row] = [aug[row][i] - factor * aug[col][i] for i in range(n + 1)]
    return [aug[i][-1] for i in range(n)]


def fit_wavelength_coefficients(points: Sequence[Tuple[float, float]], degree: Optional[int] = None) -> List[float]:
    """Least-squares fit for wavelength = a0 + a1*pixel + a2*pixel^2 + a3*pixel^3."""
    clean: List[Tuple[float, float]] = []
    for pixel, wavelength in points:
        px = float(pixel)
        wl = float(wavelength)
        if math.isfinite(px) and math.isfinite(wl):
            clean.append((px, wl))
    if len(clean) < 2:
        raise ConfigurationError("enter at least two pixel,wavelength calibration points")
    if degree is None:
        degree = min(3, len(clean) - 1)
    degree = max(1, min(3, int(degree), len(clean) - 1))
    size = degree + 1
    sums = [0.0 for _ in range(2 * degree + 1)]
    rhs = [0.0 for _ in range(size)]
    for pixel, wavelength in clean:
        powers = [1.0]
        for _ in range(2 * degree):
            powers.append(powers[-1] * pixel)
        for k in range(len(sums)):
            sums[k] += powers[k]
        for row in range(size):
            rhs[row] += wavelength * powers[row]
    normal = [[sums[row + col] for col in range(size)] for row in range(size)]
    coeffs = solve_linear_system(normal, rhs)
    while len(coeffs) < 4:
        coeffs.append(0.0)
    return coeffs[:4]


def parse_calibration_points(text: str) -> List[Tuple[float, float]]:
    """Parse calibration points from lines like 'pixel,wavelength' or 'pixel wavelength'."""
    points: List[Tuple[float, float]] = []
    for raw_line in re.split(r"[;\n]+", text):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        nums = parse_floats(line)
        if len(nums) < 2:
            raise ConfigurationError("could not parse calibration line: %r" % raw_line)
        points.append((nums[0], nums[1]))
    if not points:
        raise ConfigurationError("no calibration points entered")
    return points

def spectrum_dark_to_config(dark: Optional[Sequence[float]]) -> Optional[List[float]]:
    """Return a JSON-safe dark/black-level vector, or None when not set."""
    if dark is None:
        return None
    return [float(v) for v in dark]


def scalar_black_level_from_dark(dark: Optional[Sequence[float]]) -> Optional[float]:
    """Estimate a single black level from a stored dark spectrum."""
    if not dark:
        return None
    values = [float(v) for v in dark if math.isfinite(float(v))]
    if not values:
        return None
    values.sort()
    n = len(values)
    mid = n // 2
    return values[mid] if n % 2 else 0.5 * (values[mid - 1] + values[mid])


def estimate_hot_pixel_compensation_scale(values: Sequence[float], dark: Sequence[float]) -> float:
    """Estimate a scalar multiplier for dark subtraction by minimizing high-frequency roughness.

    The BTC100 dark trace contains the detector offset plus fixed-pattern/hot-pixel
    structure.  The best display compensation is often not exactly 1.000 because the
    dark scan and live scan can be taken at slightly different detector temperatures.
    This estimates a multiplier ``s`` for ``values - s*dark`` by minimizing the RMS of
    the second difference of the corrected trace.  Using the second difference focuses
    the optimization on sharp hot-pixel artifacts rather than broad spectral peaks.
    """
    n = min(len(values), len(dark))
    if n < 5:
        raise ConfigurationError("need at least five points to estimate hot-pixel compensation")
    v = [float(values[i]) for i in range(n)]
    d = [float(dark[i]) for i in range(n)]
    numerator = 0.0
    denominator = 0.0
    for i in range(1, n - 1):
        rv = v[i - 1] - 2.0 * v[i] + v[i + 1]
        rd = d[i - 1] - 2.0 * d[i] + d[i + 1]
        if math.isfinite(rv) and math.isfinite(rd):
            numerator += rv * rd
            denominator += rd * rd
    if denominator <= 1e-12:
        return 1.0
    scale = numerator / denominator
    if not math.isfinite(scale):
        return 1.0
    # Keep the automatic choice sane.  Values outside this range usually mean the
    # dark trace is not representative of the current scan.
    return max(0.0, min(2.0, scale))


def scaled_series(values: Sequence[float], scale: float) -> List[float]:
    """Return a scaled copy of a dark/reference-like series."""
    factor = float(scale)
    return [float(v) * factor for v in values]


def load_spectrometer_config(path: str) -> Dict[str, Any]:
    """Load a .cfg file. The format is JSON so it remains human-readable and portable."""
    with open(path, "r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ConfigurationError("configuration file must contain a JSON object")
    return data


def save_spectrometer_config(path: str, data: Dict[str, Any]) -> None:
    """Save a human-readable .cfg file."""
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, sort_keys=True)
        handle.write("\n")


# ---------------------------------------------------------------------------
# Transport layer
# ---------------------------------------------------------------------------


class Transport:
    def write(self, data: bytes) -> None:
        raise NotImplementedError

    def read(self, size: int, timeout: Optional[float] = None) -> bytes:
        raise NotImplementedError

    def flush_input(self) -> None:
        pass

    def set_baudrate(self, baudrate: int) -> None:
        pass

    def close(self) -> None:
        pass


class PySerialTransport(Transport):
    """pyserial-backed transport for real hardware."""

    def __init__(self, port: str, baudrate: int, timeout: float = 1.0) -> None:
        try:
            import serial  # type: ignore
        except ImportError as exc:
            raise ConfigurationError(
                "Real serial communication requires pyserial. Install it with: python -m pip install pyserial"
            ) from exc
        self._serial_module = serial
        self.serial = serial.Serial(
            port=port,
            baudrate=baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=timeout,
            write_timeout=timeout,
            xonxoff=False,
            rtscts=False,
            dsrdtr=False,
        )

    def write(self, data: bytes) -> None:
        self.serial.write(data)
        self.serial.flush()

    def read(self, size: int, timeout: Optional[float] = None) -> bytes:
        old_timeout = self.serial.timeout
        if timeout is not None:
            self.serial.timeout = max(0.0, float(timeout))
        try:
            return self.serial.read(size)
        finally:
            self.serial.timeout = old_timeout

    def flush_input(self) -> None:
        self.serial.reset_input_buffer()

    def set_baudrate(self, baudrate: int) -> None:
        self.serial.baudrate = int(baudrate)

    def close(self) -> None:
        self.serial.close()


class SimulatorTransport(Transport):
    """
    Standard-library simulator for development and testing without hardware.

    It accepts the documented command set and returns ACK/NAK plus synthetic spectra.
    """

    def __init__(self, model: str = "BTC110", seed: int = 1) -> None:
        model = model.upper()
        if model not in MODEL_SPECS:
            raise ConfigurationError("unknown simulator model %r" % model)
        self.spec = MODEL_SPECS[model]
        self.random = random.Random(seed)
        self._rx = bytearray()
        self._cmd = bytearray()
        self._closed = False
        self.reset_defaults()

    def reset_defaults(self) -> None:
        self.baudrate = self.spec.default_baud
        self.integration_ms = self.spec.default_integration_ms
        self.average = 1
        self.data_mode = "compressed"
        self.coefficients = [400.0, 0.25, 0.0, 0.0]
        self.pixel_mode: Tuple[Any, ...] = (0,)
        self.time_delay_ms = 35
        self.multiplier = 1
        self.version = "SIM-%s-1.0" % self.spec.name
        self.cooler_temperature_c = 20.0

    def write(self, data: bytes) -> None:
        if self._closed:
            raise ProtocolError("transport is closed")
        self._cmd.extend(data)
        while True:
            indexes = [i for i in (self._cmd.find(b"\r"), self._cmd.find(b"\n")) if i >= 0]
            if not indexes:
                break
            index = min(indexes)
            line = bytes(self._cmd[:index]).strip()
            del self._cmd[: index + 1]
            if line:
                self._handle_command(line.decode("ascii", errors="replace"))

    def read(self, size: int, timeout: Optional[float] = None) -> bytes:
        if self._closed:
            return b""
        deadline = None if timeout is None else time.monotonic() + max(0.0, float(timeout))
        while not self._rx:
            if deadline is not None and time.monotonic() >= deadline:
                return b""
            time.sleep(0.001)
        take = min(size, len(self._rx))
        data = bytes(self._rx[:take])
        del self._rx[:take]
        return data

    def flush_input(self) -> None:
        self._rx.clear()

    def set_baudrate(self, baudrate: int) -> None:
        self.baudrate = int(baudrate)

    def close(self) -> None:
        self._closed = True

    def _ack(self) -> None:
        self._rx.append(ACK_BYTE)

    def _nak(self) -> None:
        self._rx.append(NAK_BYTE)

    def _ack_text(self, value: Any) -> None:
        self._ack()
        self._rx.extend(str(value).encode("ascii", errors="replace") + b"\r\n")

    def _handle_command(self, command: str) -> None:
        parts = command.strip().split()
        if not parts:
            return
        head = parts[0]
        # Older BTC100 firmware uses compact setter commands with no space
        # between the command letter and value, e.g. I200, A1, K3. Normalize
        # those into the same token list used by the newer command set.
        if len(parts) == 1 and len(command) > 1 and command[0] in "AIKCTPx":
            head = command[0]
            parts = [head, command[1:]]
        try:
            if command == "Q":
                self.reset_defaults()
                self._ack()
            elif command == "a":
                self.data_mode = "ascii"
                self._ack()
            elif command == "b":
                self.data_mode = "compressed"
                self._ack()
            elif command == "B":
                self.data_mode = "binary"
                self._ack()
            elif head == "A" and len(parts) == 2:
                n = int(parts[1])
                if not 1 <= n <= self.spec.max_average:
                    raise ValueError
                self.average = n
                self._ack()
            elif head == "I" and len(parts) == 2:
                ms = int(parts[1])
                if not self.spec.min_integration_ms <= ms <= self.spec.max_integration_ms:
                    raise ValueError
                self.integration_ms = ms
                self._ack()
            elif head == "K" and len(parts) == 2:
                code = int(parts[1])
                if code not in BAUD_CODES:
                    raise ValueError
                self.baudrate = BAUD_CODES[code]
                self._ack()
            elif head == "C" and len(parts) == 3:
                index = int(parts[1])
                if not 1 <= index <= 4:
                    raise ValueError
                self.coefficients[index - 1] = float(parts[2])
                self._ack()
            elif head == "P":
                self.pixel_mode = parse_pixel_mode_args(parts[1:])
                self._ack()
            elif head == "T" and len(parts) == 2:
                self.time_delay_ms = int(parts[1])
                self._ack()
            elif head == "x" and len(parts) == 2:
                self.multiplier = float(parts[1])
                self._ack()
            elif head.startswith("?"):
                key = head[1:] if len(head) > 1 else (parts[1] if len(parts) > 1 else "")
                self._handle_query(key)
            elif command == "S":
                self._send_spectrum()
            else:
                self._nak()
        except Exception:
            self._nak()

    def _handle_query(self, key: str) -> None:
        if key == "A":
            self._ack_text(self.average)
        elif key == "K":
            self._ack_text(BAUD_TO_CODE.get(self.baudrate, self.baudrate))
        elif key == "I":
            self._ack_text(self.integration_ms)
        elif key == "a":
            self._ack_text(self.data_mode)
        elif key == "C":
            payload = "".join(("% .5E" % c).rjust(12)[:12] for c in self.coefficients)
            self._rx.append(ACK_BYTE)
            self._rx.extend(payload.encode("ascii") + b"\n\r")
        elif key == "v":
            self._ack_text(self.version)
        elif key == "t":
            self._ack_text("%.2f" % self.cooler_temperature_c)
        elif key == "P":
            self._ack_text(" ".join(str(x) for x in self.pixel_mode))
        elif key == "T":
            self._ack_text(self.time_delay_ms)
        elif key == "x":
            self._ack_text(self.multiplier)
        else:
            self._nak()

    def _pixel_indices(self) -> List[int]:
        return pixel_indices_for_mode(self.pixel_mode, self.spec.pixel_count)

    def _send_spectrum(self) -> None:
        indices = self._pixel_indices()
        if self.pixel_mode and self.pixel_mode[0] == 4:
            # BRC110 pixel mode 4 performs a 256-scan time series per the command notes.
            scan_indices: List[int] = []
            for _ in range(256):
                scan_indices.extend(indices)
            indices = scan_indices
        values = [self._spectrum_value(pixel, i) for i, pixel in enumerate(indices)]
        if self.data_mode == "ascii":
            self._rx.extend(("\r\n".join(str(v) for v in values) + "\r\n").encode("ascii"))
        elif self.data_mode == "binary":
            self._rx.extend(encode_uncompressed_binary(values))
        else:
            self._rx.extend(encode_compressed_binary(values))

    def _spectrum_value(self, pixel: int, sequence_index: int) -> int:
        scale = max(0.05, min(8.0, self.integration_ms / float(self.spec.default_integration_ms)))
        avg_noise = max(1.0, math.sqrt(float(self.average)))
        x = float(pixel)
        background = 80.0 + 8.0 * math.sin(x / 70.0)
        peaks = (
            900.0 * math.exp(-0.5 * ((x - 380.0) / 25.0) ** 2),
            2300.0 * math.exp(-0.5 * ((x - 950.0) / 55.0) ** 2),
            1400.0 * math.exp(-0.5 * ((x - 1480.0) / 35.0) ** 2),
        )
        signal = background + sum(peaks) * scale
        if self.spec.supports_multiplier:
            signal *= float(self.multiplier)
        # Add a small repeatable time-series ripple in pixel mode 4.
        signal += 15.0 * math.sin(sequence_index / 11.0)
        signal += self.random.gauss(0.0, 6.0 / avg_noise)
        return int(max(0, min(self.spec.adc_max, round(signal))))


# ---------------------------------------------------------------------------
# Protocol client
# ---------------------------------------------------------------------------


def normalize_model_name(model: str) -> str:
    model = model.upper()
    if model not in MODEL_SPECS:
        raise ConfigurationError("unknown model %r; choose one of %s" % (model, ", ".join(sorted(MODEL_SPECS))))
    return model


def parse_pixel_mode_args(args: Sequence[Any]) -> Tuple[Any, ...]:
    if not args:
        raise ConfigurationError("pixel mode requires at least a mode number")
    nums = [int(x) for x in args]
    mode = nums[0]
    if mode == 0:
        if len(nums) != 1:
            raise ConfigurationError("P 0 takes no extra arguments")
        return (0,)
    if mode in (1, 2):
        if len(nums) != 2 or nums[1] <= 0:
            raise ConfigurationError("P %d requires n > 0" % mode)
        return (mode, nums[1])
    if mode == 3:
        if len(nums) != 4:
            raise ConfigurationError("P 3 requires x y n")
        _, x, y, n = nums
        if not (0 <= x <= y < DEFAULT_PIXEL_COUNT and n > 0):
            raise ConfigurationError("P 3 requires 0 <= x <= y < 2048 and n > 0")
        return (3, x, y, n)
    if mode == 4:
        if len(nums) < 3:
            raise ConfigurationError("P 4 requires n followed by n pixel values")
        n = nums[1]
        pixels = nums[2:]
        if n != len(pixels) or not 1 <= n <= 6:
            raise ConfigurationError("P 4 requires 1..6 pixel values and n must match their count")
        if any(p < 0 or p >= DEFAULT_PIXEL_COUNT for p in pixels):
            raise ConfigurationError("P 4 pixels must be between 0 and 2047")
        return tuple([4, n] + pixels)
    raise ConfigurationError("unsupported pixel mode %s" % mode)


def pixel_indices_for_mode(mode_tuple: Tuple[Any, ...], pixel_count: int = DEFAULT_PIXEL_COUNT) -> List[int]:
    if not mode_tuple:
        return list(range(pixel_count))
    mode = int(mode_tuple[0])
    if mode == 0:
        return list(range(pixel_count))
    if mode in (1, 2):
        n = int(mode_tuple[1])
        return list(range(0, pixel_count, n))
    if mode == 3:
        _, x, y, n = mode_tuple
        return list(range(int(x), int(y) + 1, int(n)))
    if mode == 4:
        n = int(mode_tuple[1])
        return [int(p) for p in mode_tuple[2 : 2 + n]]
    raise ConfigurationError("unsupported pixel mode %s" % mode)


class Spectrometer:
    """High-level driver for the BWTEK serial spectrometer command set."""

    def __init__(
        self,
        transport: Transport,
        model: str = "BTC110",
        timeout: float = 2.0,
        command_terminator: bytes = b"\r",
        allow_legacy_data_mode_commands: bool = True,
    ) -> None:
        model = normalize_model_name(model)
        self.transport = transport
        self.spec = MODEL_SPECS[model]
        self.timeout = float(timeout)
        self.inter_byte_timeout = 0.20
        self.command_terminator = command_terminator
        self.allow_legacy_data_mode_commands = allow_legacy_data_mode_commands
        self._rx_buffer = bytearray()
        self._lock = threading.RLock()
        self.average = 1
        self.integration_ms = self.spec.default_integration_ms
        self.data_mode = "compressed"
        self.coefficients: Optional[List[float]] = None
        self.pixel_mode: Tuple[Any, ...] = (0,)
        self.time_delay_ms = 35
        self.multiplier: Optional[float] = None
        self.dark: Optional[List[float]] = None
        self.reference: Optional[List[float]] = None

    def close(self) -> None:
        self.transport.close()

    def _discard_pending_input(self) -> None:
        self._rx_buffer.clear()
        self.transport.flush_input()

    def _write_command(self, command: str) -> None:
        data = command.encode("ascii") + self.command_terminator
        self.transport.write(data)

    def _discard_command_echo(self, command: str, timeout: float = 0.05) -> None:
        """Discard an immediate echoed command line, if one is present."""
        expected = command.strip().encode("ascii", errors="ignore")
        if not expected:
            return
        first = self._read(1, timeout=timeout)
        if not first:
            return
        if first != expected[:1]:
            self._unread(first)
            return
        collected = bytearray(first)
        while len(collected) < len(expected) + 2:
            extra = self._read(1, timeout=0.01)
            if not extra:
                break
            collected.extend(extra)
            if extra[0] in (10, 13):
                break
        if bytes(collected).strip() == expected:
            # Also remove the paired LF/CR when present.
            extra = self._read(1, timeout=0.005)
            if extra and extra[0] not in (10, 13):
                self._unread(extra)
            return
        self._unread(bytes(collected))

    def _unread(self, data: bytes) -> None:
        if data:
            self._rx_buffer = bytearray(data) + self._rx_buffer

    def _read(self, size: int, timeout: Optional[float] = None) -> bytes:
        if size <= 0:
            return b""
        out = bytearray()
        if self._rx_buffer:
            take = min(size, len(self._rx_buffer))
            out.extend(self._rx_buffer[:take])
            del self._rx_buffer[:take]
        if len(out) < size:
            out.extend(self.transport.read(size - len(out), timeout=timeout))
        return bytes(out)

    def _read_exact(self, size: int, timeout: Optional[float] = None) -> bytes:
        deadline = time.monotonic() + (self.timeout if timeout is None else float(timeout))
        out = bytearray()
        while len(out) < size:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise ProtocolTimeout("timed out while reading %d bytes; got %d" % (size, len(out)))
            chunk = self._read(size - len(out), timeout=remaining)
            if not chunk:
                continue
            out.extend(chunk)
        return bytes(out)

    def _read_until_idle(self, total_timeout: float, idle_timeout: float = 0.45, chunk_size: int = 256) -> bytes:
        """Read bytes until the stream goes quiet or total_timeout expires.

        Compressed BTC/BRC spectra have no terminator and variable length. Waiting for
        exactly 2048 decoded values can make the GUI appear hung if the unit prepends an
        ACK/echo byte, returns ASCII unexpectedly, or ends with a truncated token. This
        method follows the physical behavior instead: wait for the first byte, then stop
        once no bytes arrive for idle_timeout.
        """
        deadline = time.monotonic() + float(total_timeout)
        out = bytearray()
        saw_first = False
        while True:
            remaining_total = deadline - time.monotonic()
            if remaining_total <= 0:
                if out:
                    return bytes(out)
                raise ProtocolTimeout("timed out waiting for spectral data")
            wait = min(remaining_total, idle_timeout if saw_first else remaining_total)
            chunk = self._read(chunk_size, timeout=wait)
            if chunk:
                out.extend(chunk)
                saw_first = True
                continue
            if saw_first:
                return bytes(out)

    def _read_byte(self, timeout: Optional[float] = None) -> int:
        return self._read_exact(1, timeout=timeout)[0]

    def _read_line(self, timeout: Optional[float] = None, max_bytes: int = 512) -> bytes:
        deadline = time.monotonic() + (self.timeout if timeout is None else float(timeout))
        out = bytearray()
        while len(out) < max_bytes:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                if out:
                    return bytes(out)
                raise ProtocolTimeout("timed out while reading line")
            read_timeout = min(remaining, self.inter_byte_timeout if out else remaining)
            chunk = self._read(1, timeout=read_timeout)
            if not chunk:
                if out:
                    return bytes(out)
                continue
            b = chunk[0]
            if b in (10, 13):
                if not out:
                    # Skip leading CR/LF. Some firmware sends textual ACK followed by
                    # a newline before the actual query payload.
                    continue
                # Eat a paired LF/CR if it is already waiting; otherwise leave stream alone.
                extra = self._read(1, timeout=0.01)
                if extra and extra[0] not in (10, 13):
                    self._unread(extra)
                return bytes(out)
            out.append(b)
        raise ProtocolError("line exceeds %d bytes" % max_bytes)

    def _consume_immediate_line_endings(self) -> None:
        """Consume CR/LF bytes that immediately follow a textual ACK/NAK."""
        while True:
            extra = self._read(1, timeout=0.01)
            if not extra:
                return
            if extra[0] in (10, 13):
                continue
            self._unread(extra)
            return

    def _expect_ack(self, sent_command: Optional[str] = None, timeout: Optional[float] = None) -> None:
        """
        Wait for ACK/NAK, tolerating command echo before the ACK.

        Some older BTC-series units and USB/RS-232 adapters echo the command text before
        returning the documented ACK/NAK. For example, after sending ``I 200`` the first
        bytes may be ``b'I 200\\r'`` followed by ACK. The earlier strict reader saw
        ``b'I 2'`` and failed; this scanner ignores echoed text and keeps looking for
        either binary ACK/NAK (0x06/0x15) or textual ACK/NAK.
        """
        deadline = time.monotonic() + (self.timeout if timeout is None else float(timeout))
        sent = (sent_command or "").strip().encode("ascii", errors="ignore")
        seen = bytearray()
        line = bytearray()

        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                if seen:
                    raise ProtocolError("expected ACK/NAK, got %r" % bytes(seen[:80]))
                raise ProtocolTimeout("no ACK/NAK received")
            chunk = self._read(1, timeout=remaining)
            if not chunk:
                continue
            b = chunk[0]

            if b == ACK_BYTE:
                return
            if b == NAK_BYTE:
                raise NakError("spectrometer returned NAK")

            if b in (10, 13):
                current = bytes(line).strip()
                line.clear()
                if not current:
                    continue
                upper = current.upper()
                if upper == b"ACK" or upper.startswith(b"ACK "):
                    return
                if upper == b"NAK" or upper.startswith(b"NAK "):
                    raise NakError("spectrometer returned NAK")
                # Most echoes are exactly the sent command. Ignore them and keep scanning.
                if sent and (current == sent or current.startswith(sent + b" ")):
                    continue
                # Unknown text before ACK is also ignored, but retained in `seen` for a
                # useful error if no ACK/NAK ever arrives.
                continue

            seen.append(b)
            line.append(b)
            if len(seen) > 512:
                raise ProtocolError("expected ACK/NAK, got too much non-ACK data: %r" % bytes(seen[:80]))

            upper_line = bytes(line).upper()
            if upper_line.endswith(b"ACK"):
                self._consume_immediate_line_endings()
                return
            if upper_line.endswith(b"NAK"):
                self._consume_immediate_line_endings()
                raise NakError("spectrometer returned NAK")

    def _command_ack(self, command: str, timeout: Optional[float] = None) -> None:
        with self._lock:
            self._discard_pending_input()
            self._write_command(command)
            old_timeout = self.timeout
            if timeout is not None:
                self.timeout = float(timeout)
            try:
                self._expect_ack(sent_command=command)
            finally:
                self.timeout = old_timeout

    def _set_command(self, letter: str, *values: Any) -> str:
        """Format a setter command for the selected firmware family.

        BTC100 units use compact commands such as I200 and A1. The newer
        BTC110/BRC/BTC200 command set uses spaces, such as I 200 and A 1.
        """
        text_values = [str(v) for v in values]
        if self.spec.compact_commands and len(text_values) == 1:
            return letter + text_values[0]
        if text_values:
            return letter + " " + " ".join(text_values)
        return letter


    def refresh_csv_browser(self) -> None:
        """Refresh the sidebar list of CSV files in the selected folder."""
        try:
            folder = self.csv_folder_var.get().strip() or os.getcwd()
            files = []
            if os.path.isdir(folder):
                for name in os.listdir(folder):
                    if name.lower().endswith(".csv"):
                        files.append(name)
            files.sort(key=lambda n: os.path.getmtime(os.path.join(folder, n)) if os.path.exists(os.path.join(folder, n)) else 0, reverse=True)
            self.csv_listbox.delete(0, "end")
            for name in files:
                self.csv_listbox.insert("end", name)
            self.log_message("CSV browser: %d file(s) in %s" % (len(files), folder))
        except Exception as exc:
            self.log_message("ERROR refreshing CSV browser: %s" % exc)

    def browse_csv_folder(self) -> None:
        from tkinter import filedialog
        folder = filedialog.askdirectory(initialdir=self.csv_folder_var.get() or os.getcwd())
        if folder:
            self.csv_folder_var.set(folder)
            self.refresh_csv_browser()

    def selected_csv_path(self) -> Optional[str]:
        selection = self.csv_listbox.curselection()
        if not selection:
            return None
        name = self.csv_listbox.get(selection[0])
        return os.path.join(self.csv_folder_var.get().strip() or os.getcwd(), name)

    def load_selected_csv_reference(self) -> None:
        path = self.selected_csv_path()
        if not path:
            self.log_message("Select a CSV file in the sidebar first")
            return
        try:
            spectrum = load_spectrum_csv(path)
            if self.calibration_coefficients is not None and spectrum.wavelengths_nm is None:
                apply_wavelength_calibration(spectrum, self.calibration_coefficients)
            label = os.path.basename(path)
            color = self.reference_colors[len(self.reference_traces) % len(self.reference_colors)]
            self.reference_traces.append((label, spectrum, color))
            self.update_reference_listbox()
            self.redraw_last_spectrum()
            self.log_message("Loaded reference trace %s" % label)
        except Exception as exc:
            self.log_message("ERROR loading reference CSV: %s" % exc)

    def load_selected_csv_as_dark(self) -> None:
        """Use the selected sidebar CSV as the current per-pixel dark spectrum."""
        path = self.selected_csv_path()
        if not path:
            self.log_message("Select a CSV file in the sidebar first")
            return
        self.load_dark_from_csv_path(path)

    def load_dark_csv(self) -> None:
        """Prompt for an exported CSV and load it as a per-pixel dark trace."""
        from tkinter import filedialog
        path = filedialog.askopenfilename(
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            initialdir=self.csv_folder_var.get().strip() or os.getcwd(),
        )
        if path:
            self.load_dark_from_csv_path(path)

    def load_dark_from_csv_path(self, path: str) -> None:
        """Load an exported scan CSV as the per-pixel black-level correction.

        Dark scans should subtract the detector counts that were actually measured
        during the covered-input acquisition, so the loader prefers the raw
        exported ``intensity`` column. If an older/hand-edited CSV lacks that
        column, it falls back to ``corrected`` and then ``dark``.
        """
        try:
            spectrum = load_spectrum_csv(path, preferred_columns=("intensity", "corrected", "dark"))
            if not spectrum.intensities:
                raise ConfigurationError("dark CSV contains no numeric samples")
            self.dark = [float(v) for v in spectrum.intensities]
            median_dark = scalar_black_level_from_dark(self.dark)
            if median_dark is not None:
                self.black_level_var.set("%.12g" % median_dark)
            self.correction_var.set("dark")
            self.redraw_last_spectrum()
            source_column = spectrum.metadata.get("source_column", "intensity") if hasattr(spectrum, "metadata") else "intensity"
            self.log_message("Loaded per-pixel dark from %s (%d points, column %s, median %.6g)" % (os.path.basename(path), len(self.dark), source_column, median_dark if median_dark is not None else float("nan")))
        except Exception as exc:
            self.log_message("ERROR loading dark CSV: %s" % exc)

    def update_reference_listbox(self) -> None:
        self.reference_listbox.delete(0, "end")
        for index, (label, _spectrum, color) in enumerate(self.reference_traces):
            self.reference_listbox.insert("end", "%d. %s  %s" % (index + 1, label, color))

    def remove_selected_reference(self) -> None:
        selection = self.reference_listbox.curselection()
        if not selection:
            self.log_message("Select a loaded reference trace first")
            return
        index = int(selection[0])
        if 0 <= index < len(self.reference_traces):
            label = self.reference_traces[index][0]
            del self.reference_traces[index]
            self.update_reference_listbox()
            self.redraw_last_spectrum()
            self.log_message("Removed reference trace %s" % label)

    def clear_reference_traces(self) -> None:
        self.reference_traces.clear()
        self.update_reference_listbox()
        self.redraw_last_spectrum()
        self.log_message("Cleared reference traces")

    def on_model_changed(self) -> None:
        """Update defaults that depend on the selected model."""
        try:
            model = normalize_model_name(self.model_var.get())
            spec = MODEL_SPECS[model]
            self.baud_var.set(str(spec.default_baud))
            self.integration_var.set(str(spec.default_integration_ms))
            # Keep the default manual 0..ADC max display for the selected model.
            if not self.y_auto_min_var.get():
                self.y_min_var.set("0")
            if not self.y_auto_max_var.get():
                self.y_max_var.set(str(spec.adc_max))
            self._last_applied_settings = None
            self.redraw_last_spectrum()
        except Exception as exc:
            self.log_message("ERROR: %s" % exc)

    def on_hot_pixel_scale_changed(self, _value: Any = None) -> None:
        """Update the displayed multiplier and redraw using the stored raw scan."""
        try:
            value = float(self.hot_pixel_scale_var.get())
        except Exception:
            value = 1.0
        self.hot_pixel_scale_label_var.set("%.3f" % value)
        # Scale changes are display-only, so use the stored raw scan and redraw.
        self.redraw_last_spectrum()

    def auto_hot_pixel_compensation(self) -> None:
        """Pick a dark-trace multiplier that minimizes high-frequency roughness."""
        try:
            raw = self.last_raw_spectrum if self.last_raw_spectrum is not None else self.last_spectrum
            if raw is None:
                raise ConfigurationError("acquire or load a scan first")
            dark_source = self.dark
            if dark_source is None:
                dark_source = self.scalar_dark_from_field(len(raw.pixels))
            if dark_source is None:
                raise ConfigurationError("capture/load a dark spectrum or enter a black level first")
            dark = align_series_to_pixels(dark_source, raw.pixels, "dark spectrum")
            scale = estimate_hot_pixel_compensation_scale(raw.intensities, dark)
            self.hot_pixel_scale_var.set(scale)
            self.hot_pixel_scale_label_var.set("%.3f" % scale)
            self.redraw_last_spectrum()
            self.log_message("Hot pixel compensation scale set to %.6g" % scale)
        except Exception as exc:
            self.log_message("ERROR: %s" % exc)

    def apply_black_level_from_field(self) -> None:
        """Apply a scalar black-level offset as the current dark spectrum."""
        try:
            text = self.black_level_var.get().strip()
            if not text:
                raise ConfigurationError("enter a black level in ADC counts")
            level = float(text)
            if not math.isfinite(level):
                raise ConfigurationError("black level must be finite")
            model = normalize_model_name(self.model_var.get())
            count = MODEL_SPECS[model].pixel_count
            self.dark = [level for _ in range(count)]
            self.redraw_last_spectrum()
            self.log_message("Applied scalar black level %.6g counts" % level)
        except Exception as exc:
            self.log_message("ERROR: %s" % exc)
    def redraw_corrections_from_window(self) -> None:
        """Redraw after correction controls changed, without modifying raw data.

        If no per-pixel dark has been captured/loaded yet, the black-level field is
        used as a plot-only scalar dark correction. Use Apply black level when you
        want that scalar saved as the current dark vector / CFG default.
        """
        self.redraw_last_spectrum()


    def default_cfg_path(self) -> str:
        """Return the default .cfg file path used for automatic GUI startup defaults."""
        base = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
        return os.path.join(base, "bwtek_spectrometer.cfg")

    def current_cfg_dict(self) -> Dict[str, Any]:
        """Build a JSON-safe configuration dictionary from the current GUI state."""
        dark_vector = spectrum_dark_to_config(self.dark)
        black_level = None
        if self.black_level_var.get().strip():
            black_level = float(self.black_level_var.get().strip())
        elif dark_vector is not None:
            black_level = scalar_black_level_from_dark(dark_vector)
        return {
            "format": "bwtek_spectrometer_cfg_v3",
            "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "model": normalize_model_name(self.model_var.get()),
            "baud": int(self.baud_var.get()) if self.baud_var.get().strip() else None,
            "integration_ms": int(self.integration_var.get()) if self.integration_var.get().strip() else None,
            "average": int(self.average_var.get()) if self.average_var.get().strip() else None,
            "data_mode": self.mode_var.get(),
            "correction": self.correction_var.get(),
            "black_level": black_level,
            "hot_pixel_compensation_scale": float(self.hot_pixel_scale_var.get()),
            "smooth_width": int(self.smooth_var.get() or "1"),
            "smooth_kind": self.smooth_kind_var.get(),
            "median_filter_width": int(self.median_filter_var.get() or "1"),
            "despike_enabled": bool(self.despike_var.get()),
            "despike_threshold": float(self.despike_threshold_var.get() or "6"),
            "ptc_result": dict(self.ptc_result) if self.ptc_result is not None else None,
            "dark_spectrum": dark_vector,
            "calibration_coefficients": list(self.calibration_coefficients) if self.calibration_coefficients is not None else None,
            "x_axis": self.x_axis_var.get(),
            "show_color_background": bool(self.show_color_background_var.get()),
            "show_references": bool(self.show_references_var.get()),
            "show_legend": bool(self.show_legend_var.get()),
            "y_auto_min": bool(self.y_auto_min_var.get()),
            "y_auto_max": bool(self.y_auto_max_var.get()),
            "y_min": self.y_min_var.get(),
            "y_max": self.y_max_var.get(),
        }

    def save_cfg_to_path(self, path: str) -> None:
        """Save calibration, black level, and display defaults to a specific path."""
        save_spectrometer_config(path, self.current_cfg_dict())

    def apply_cfg_dict(self, cfg: Dict[str, Any]) -> None:
        """Apply a loaded configuration dictionary to the GUI state."""
        model = cfg.get("model")
        if model:
            self.model_var.set(normalize_model_name(str(model)))
        if cfg.get("baud") is not None:
            self.baud_var.set(str(int(cfg["baud"])))
        if cfg.get("integration_ms") is not None:
            self.integration_var.set(str(int(cfg["integration_ms"])))
        if cfg.get("average") is not None:
            self.average_var.set(str(int(cfg["average"])))
        if cfg.get("data_mode") in ("compressed", "ascii", "binary"):
            self.mode_var.set(str(cfg["data_mode"]))
        if cfg.get("correction") in ("raw", "dark", "transmittance", "absorbance"):
            self.correction_var.set(str(cfg["correction"]))
        coeffs = cfg.get("calibration_coefficients")
        if coeffs is not None:
            if not isinstance(coeffs, list) or len(coeffs) != 4:
                raise ConfigurationError("CFG calibration_coefficients must be a list of four numbers")
            coeffs = [float(c) for c in coeffs]
            self.calibration_coefficients = coeffs
            self.set_calibration_fields(coeffs)
            if self.spec is not None:
                self.spec.coefficients = list(coeffs)
        else:
            self.calibration_coefficients = None
            for var in (self.cal_a0_var, self.cal_a1_var, self.cal_a2_var, self.cal_a3_var):
                var.set("")
        if cfg.get("x_axis") in ("pixel", "wavelength"):
            self.x_axis_var.set(str(cfg["x_axis"]))
        elif self.calibration_coefficients is not None:
            self.x_axis_var.set("wavelength")
        if "show_color_background" in cfg:
            self.show_color_background_var.set(bool(cfg["show_color_background"]))
        if "dark_mode" in cfg:
            self.dark_mode_var.set(bool(cfg["dark_mode"]))
            self.apply_theme(redraw=False)
        if "show_references" in cfg:
            self.show_references_var.set(bool(cfg["show_references"]))
            self.update_reference_area_visibility()
        if "show_legend" in cfg:
            self.show_legend_var.set(bool(cfg["show_legend"]))
        dark = cfg.get("dark_spectrum")
        if isinstance(dark, list) and dark:
            self.dark = [float(v) for v in dark]
            scalar = cfg.get("black_level", scalar_black_level_from_dark(self.dark))
            self.black_level_var.set("%.12g" % float(scalar) if scalar is not None else "")
        elif cfg.get("black_level") is not None:
            level = float(cfg["black_level"])
            self.black_level_var.set("%.12g" % level)
            count = MODEL_SPECS[normalize_model_name(self.model_var.get())].pixel_count
            self.dark = [level for _ in range(count)]
        if cfg.get("hot_pixel_compensation_scale") is not None:
            try:
                scale = float(cfg["hot_pixel_compensation_scale"])
                self.hot_pixel_scale_var.set(max(0.0, min(2.0, scale)))
                self.hot_pixel_scale_label_var.set("%.3f" % float(self.hot_pixel_scale_var.get()))
            except Exception:
                pass
        if cfg.get("smooth_width") is not None:
            try:
                self.smooth_var.set(str(max(1, int(cfg["smooth_width"]))))
            except Exception:
                pass
        if cfg.get("smooth_kind") is not None:
            try:
                kind = str(cfg["smooth_kind"]).strip().lower()
                if kind in ("boxcar", "triangular", "gaussian", "savitzky-golay", "none"):
                    self.smooth_kind_var.set(kind)
            except Exception:
                pass
        if cfg.get("median_filter_width") is not None:
            try:
                self.median_filter_var.set(str(max(1, int(cfg["median_filter_width"]))))
            except Exception:
                pass
        if cfg.get("despike_enabled") is not None:
            try:
                self.despike_var.set(bool(cfg["despike_enabled"]))
            except Exception:
                pass
        if cfg.get("despike_threshold") is not None:
            try:
                self.despike_threshold_var.set("%.6g" % float(cfg["despike_threshold"]))
            except Exception:
                pass
        if isinstance(cfg.get("ptc_result"), dict):
            try:
                self.ptc_result = {str(k): float(v) for k, v in cfg["ptc_result"].items() if isinstance(v, (int, float))}
            except Exception:
                self.ptc_result = None
        if "y_auto_min" in cfg:
            self.y_auto_min_var.set(bool(cfg["y_auto_min"]))
        elif "y_auto_scale" in cfg:
            self.y_auto_min_var.set(bool(cfg["y_auto_scale"]))
        if "y_auto_max" in cfg:
            self.y_auto_max_var.set(bool(cfg["y_auto_max"]))
        elif "y_auto_scale" in cfg:
            self.y_auto_max_var.set(bool(cfg["y_auto_scale"]))
        if cfg.get("y_min") is not None:
            self.y_min_var.set(str(cfg.get("y_min")))
        if cfg.get("y_max") is not None:
            self.y_max_var.set(str(cfg.get("y_max")))
        if self.last_spectrum is not None:
            if self.calibration_coefficients is not None:
                apply_wavelength_calibration(self.last_spectrum, self.calibration_coefficients)
            self.redraw_last_spectrum()
        for _label, ref_spectrum, _color in self.reference_traces:
            if self.calibration_coefficients is not None:
                apply_wavelength_calibration(ref_spectrum, self.calibration_coefficients)
        self._last_applied_settings = None

    def load_cfg_from_path(self, path: str) -> None:
        """Load calibration, black level, and display defaults from a specific path."""
        self.apply_cfg_dict(load_spectrometer_config(path))

    def save_cfg(self) -> None:
        """Save calibration and black-level defaults to a .cfg file."""
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(
            defaultextension=".cfg",
            filetypes=[("Spectrometer config", "*.cfg"), ("JSON files", "*.json"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            self.save_cfg_to_path(path)
            self.log_message("Saved CFG %s" % path)
        except Exception as exc:
            self.log_message("ERROR saving CFG: %s" % exc)

    def load_cfg(self) -> None:
        """Load calibration and black-level defaults from a .cfg file."""
        from tkinter import filedialog
        path = filedialog.askopenfilename(
            filetypes=[("Spectrometer config", "*.cfg"), ("JSON files", "*.json"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            self.load_cfg_from_path(path)
            self.log_message("Loaded CFG %s" % path)
        except Exception as exc:
            self.log_message("ERROR loading CFG: %s" % exc)

    def save_default_cfg(self) -> None:
        """Save the current settings to the auto-loaded default .cfg path."""
        path = self.default_cfg_path()
        try:
            self.save_cfg_to_path(path)
            self.log_message("Saved default CFG %s" % path)
        except Exception as exc:
            self.log_message("ERROR saving default CFG: %s" % exc)

    def load_default_cfg(self) -> None:
        """Load the auto-loaded default .cfg path on demand."""
        path = self.default_cfg_path()
        try:
            if not os.path.exists(path):
                raise ConfigurationError("default CFG not found: %s" % path)
            self.load_cfg_from_path(path)
            self.log_message("Loaded default CFG %s" % path)
        except Exception as exc:
            self.log_message("ERROR loading default CFG: %s" % exc)

    def load_default_cfg_if_present(self) -> None:
        """Auto-load bwtek_spectrometer.cfg at startup when present."""
        path = self.default_cfg_path()
        if os.path.exists(path):
            try:
                self.load_cfg_from_path(path)
                self.log_message("Loaded default CFG %s" % path)
            except Exception as exc:
                self.log_message("ERROR loading default CFG: %s" % exc)

    def initialize(self) -> None:
        self._command_ack("Q")
        self.average = 1
        self.integration_ms = self.spec.default_integration_ms
        self.data_mode = "compressed"
        self.pixel_mode = (0,)
        self.time_delay_ms = 35

    def set_ascii_mode(self) -> None:
        try:
            self._command_ack("a")
        except (NakError, ProtocolError):
            if not self.allow_legacy_data_mode_commands:
                raise
            self._command_ack("A")
        self.data_mode = "ascii"

    def set_compressed_binary_mode(self) -> None:
        self._command_ack("b")
        self.data_mode = "compressed"

    def set_uncompressed_binary_mode(self) -> None:
        try:
            self._command_ack("B")
        except (NakError, ProtocolError):
            if not self.allow_legacy_data_mode_commands:
                raise
            self._command_ack("b")
        self.data_mode = "binary"

    def set_data_mode(self, mode: str) -> None:
        mode = mode.lower()
        if mode == "ascii":
            self.set_ascii_mode()
        elif mode in ("compressed", "compressed-binary", "compressed_binary"):
            self.set_compressed_binary_mode()
        elif mode in ("binary", "uncompressed", "uncompressed-binary", "uncompressed_binary"):
            self.set_uncompressed_binary_mode()
        else:
            raise ConfigurationError("unknown data mode %r" % mode)

    def set_average(self, count: int) -> None:
        count = int(count)
        if not 1 <= count <= self.spec.max_average:
            raise ConfigurationError("average must be 1..%d for %s" % (self.spec.max_average, self.spec.name))
        self._command_ack(self._set_command("A", count))
        self.average = count

    def set_integration_time(self, milliseconds: int) -> None:
        milliseconds = int(milliseconds)
        if not self.spec.min_integration_ms <= milliseconds <= self.spec.max_integration_ms:
            raise ConfigurationError(
                "integration must be %d..%d ms for %s"
                % (self.spec.min_integration_ms, self.spec.max_integration_ms, self.spec.name)
            )
        self._command_ack(self._set_command("I", milliseconds))
        self.integration_ms = milliseconds

    def set_baud_rate(self, value: int) -> int:
        """Set baud by baud-rate value or command code. Returns actual baud rate."""
        value = int(value)
        if value in BAUD_CODES:
            code = value
            baud = BAUD_CODES[code]
        elif value in BAUD_TO_CODE:
            baud = value
            code = BAUD_TO_CODE[baud]
        else:
            raise ConfigurationError("baud must be one of %s or code 0..7" % sorted(BAUD_TO_CODE))
        self._command_ack(self._set_command("K", code))
        self.transport.set_baudrate(baud)
        return baud

    def set_coefficient(self, index_1_based: int, value: float) -> None:
        index_1_based = int(index_1_based)
        if not 1 <= index_1_based <= 4:
            raise ConfigurationError("coefficient index must be 1..4")
        self._command_ack(self._set_command("C", index_1_based, format(float(value), ".12g")))
        if self.coefficients is None:
            self.coefficients = [0.0, 1.0, 0.0, 0.0]
        self.coefficients[index_1_based - 1] = float(value)

    def set_coefficients(self, coefficients: Sequence[float]) -> None:
        if len(coefficients) != 4:
            raise ConfigurationError("four coefficients are required")
        for i, value in enumerate(coefficients, start=1):
            self.set_coefficient(i, float(value))

    def set_pixel_mode(self, *args: Any) -> None:
        parsed = parse_pixel_mode_args(args)
        if not self.spec.supports_pixel_mode:
            # Some firmware may still accept P; warn by exception unless model supports it.
            raise ConfigurationError("%s does not document pixel mode support" % self.spec.name)
        self._command_ack(self._set_command("P", *parsed))
        self.pixel_mode = parsed

    def set_time_delay(self, milliseconds: int) -> None:
        milliseconds = int(milliseconds)
        if not self.spec.supports_time_delay:
            raise ConfigurationError("%s does not document time delay support" % self.spec.name)
        if not 35 <= milliseconds <= 65000:
            raise ConfigurationError("time delay must be 35..65000 ms")
        self._command_ack(self._set_command("T", milliseconds))
        self.time_delay_ms = milliseconds

    def set_multiplier(self, multiplier: Union[int, float]) -> None:
        if not self.spec.supports_multiplier:
            raise ConfigurationError("%s does not document multiplier support" % self.spec.name)
        value = float(multiplier)
        self._command_ack(self._set_command("x", format(value, ".12g")))
        self.multiplier = value

    def query_raw(self, key: str, max_bytes: int = 512) -> str:
        if len(key) != 1:
            raise ConfigurationError("query key must be one character")
        with self._lock:
            self._discard_pending_input()
            command = "?%s" % key
            self._write_command(command)
            self._expect_ack(sent_command=command)
            payload = self._read_line(timeout=self.timeout, max_bytes=max_bytes)
        return payload.decode("ascii", errors="replace").strip()

    def query_average(self) -> int:
        self.average = int(float(self.query_raw("A")))
        return self.average

    def query_baud_code(self) -> int:
        return int(float(self.query_raw("K")))

    def query_baud_rate(self) -> int:
        code = self.query_baud_code()
        return BAUD_CODES.get(code, code)

    def query_integration_time(self) -> int:
        self.integration_ms = int(float(self.query_raw("I")))
        return self.integration_ms

    def query_data_mode(self) -> str:
        raw = self.query_raw("a")
        low = raw.strip().lower()
        if low in ("a", "ascii", "0"):
            self.data_mode = "ascii"
        elif low in ("b", "binary", "compressed", "compressed binary", "1"):
            self.data_mode = "compressed"
        elif low in ("uncompressed", "uncompressed binary", "2"):
            self.data_mode = "binary"
        else:
            # Keep the raw value visible if firmware uses another code.
            self.data_mode = raw or self.data_mode
        return self.data_mode

    def query_coefficients(self) -> List[float]:
        raw = self.query_raw("C", max_bytes=128)
        coeffs = parse_floats(raw)
        if len(coeffs) < 4:
            raise ProtocolError("could not parse four coefficients from %r" % raw)
        self.coefficients = coeffs[:4]
        return self.coefficients

    def query_version(self) -> str:
        return self.query_raw("v")

    def query_cooler_temperature(self) -> float:
        return float(self.query_raw("t"))

    def query_pixel_mode(self) -> Tuple[Any, ...]:
        raw = self.query_raw("P")
        parsed = parse_pixel_mode_args(raw.split())
        self.pixel_mode = parsed
        return parsed

    def query_time_delay(self) -> int:
        self.time_delay_ms = int(float(self.query_raw("T")))
        return self.time_delay_ms

    def query_multiplier(self) -> float:
        value = float(self.query_raw("x"))
        self.multiplier = value
        return value

    def query_all(self, include_optional: bool = True) -> Dict[str, Any]:
        out: Dict[str, Any] = {"model": self.spec.name}
        queries: List[Tuple[str, Callable[[], Any]]] = [
            ("average", self.query_average),
            ("baud_rate", self.query_baud_rate),
            ("integration_ms", self.query_integration_time),
            ("data_mode", self.query_data_mode),
            ("coefficients", self.query_coefficients),
            ("version", self.query_version),
        ]
        if include_optional and self.spec.supports_cooler_temperature:
            queries.append(("cooler_temperature_c", self.query_cooler_temperature))
        if include_optional and self.spec.supports_pixel_mode:
            queries.append(("pixel_mode", self.query_pixel_mode))
            queries.append(("time_delay_ms", self.query_time_delay))
        if include_optional and self.spec.supports_multiplier:
            queries.append(("multiplier", self.query_multiplier))
        for name, func in queries:
            try:
                out[name] = func()
            except Exception as exc:
                out[name + "_error"] = str(exc)
        return out

    def expected_pixels(self) -> List[int]:
        pixels = pixel_indices_for_mode(self.pixel_mode, self.spec.pixel_count)
        if self.pixel_mode and self.pixel_mode[0] == 4:
            expanded: List[int] = []
            for _ in range(256):
                expanded.extend(pixels)
            return expanded
        return pixels

    def acquisition_timeout(self, expected_values: int) -> float:
        exposure = (self.integration_ms / 1000.0) * max(1, self.average)
        if self.pixel_mode and self.pixel_mode[0] == 4:
            exposure += 256 * (self.time_delay_ms / 1000.0)
        transfer = max(2.0, expected_values * 3 * 10.0 / max(600.0, float(self.spec.default_baud)))
        return max(self.timeout, exposure + transfer + 2.0)

    def acquire(self, expected_count: Optional[int] = None, data_mode: Optional[str] = None) -> Spectrum:
        """
        Acquire a spectrum using the current or supplied data mode.

        expected_count is normally inferred from pixel mode. Pass it only for custom firmware
        modes where the number of returned values differs from the documented modes.
        """
        with self._lock:
            if data_mode and data_mode.lower() != "current":
                self.set_data_mode(data_mode)
            pixels = self.expected_pixels()
            count = int(expected_count) if expected_count is not None else len(pixels)
            if expected_count is not None:
                pixels = list(range(count))
            timeout = self.acquisition_timeout(count)
            self._discard_pending_input()
            self._write_command("S")
            self._discard_command_echo("S")
            if self.data_mode == "ascii":
                values = self._read_ascii_values(count, timeout)
            elif self.data_mode == "binary":
                payload = self._read_exact(count * 2, timeout=timeout)
                values = decode_uncompressed_binary(payload, count=count)
            else:
                # Old BTC100 scan packets are variable length and can be preceded by an
                # echoed command or ACK depending on the firmware/adapter. Reading until
                # the stream goes quiet makes the GUI show the scan immediately after the
                # instrument finishes instead of waiting for a per-byte timeout.
                raw_payload = self._read_until_idle(total_timeout=timeout, idle_timeout=0.55)
                values, ignored_prefix, decode_note = decode_compressed_binary_best_effort(
                    raw_payload, count=count, adc_max=self.spec.adc_max
                )
                if len(values) != count:
                    pixels = pixels[: len(values)]
                    count = len(values)
        wavelengths = wavelengths_for_pixels(pixels, self.coefficients) if self.coefficients else None
        metadata = {
            "model": self.spec.name,
            "average": self.average,
            "integration_ms": self.integration_ms,
            "data_mode": self.data_mode,
            "pixel_mode": list(self.pixel_mode),
            "count": count,
            "created_unix": time.time(),
        }
        if self.data_mode == "compressed" and "raw_payload" in locals():
            metadata["raw_payload_bytes"] = len(raw_payload)
            metadata["decode_note"] = decode_note
            metadata["ignored_prefix_bytes"] = ignored_prefix
        if self.coefficients:
            metadata["coefficients"] = list(self.coefficients)
        return Spectrum(pixels=pixels, intensities=[float(v) for v in values], wavelengths_nm=wavelengths, metadata=metadata)

    def _read_ascii_values(self, count: int, timeout: float) -> List[int]:
        deadline = time.monotonic() + timeout
        values: List[int] = []
        text = ""
        integer_re = re.compile(r"[-+]?\d+")
        while len(values) < count:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise ProtocolTimeout("timed out reading ASCII spectrum; got %d/%d values" % (len(values), count))
            chunk = self._read(128, timeout=min(remaining, self.inter_byte_timeout if text else remaining))
            if not chunk:
                continue
            text += chunk.decode("ascii", errors="ignore")
            # Parse complete tokens only. Keep the last partial token if the buffer does not end with whitespace.
            if text and not text[-1].isspace():
                last_split = max(text.rfind(" "), text.rfind("\r"), text.rfind("\n"), text.rfind("\t"))
                complete, text = text[: last_split + 1], text[last_split + 1 :] if last_split >= 0 else text
                if last_split < 0:
                    continue
            else:
                complete, text = text, ""
            for match in integer_re.finditer(complete):
                values.append(int(match.group(0)))
                if len(values) >= count:
                    break
        return values

    def capture_dark(self, scans: int = 1) -> List[float]:
        self.dark = average_scans([self.acquire().intensities for _ in range(max(1, int(scans)))])
        return self.dark

    def capture_reference(self, scans: int = 1) -> List[float]:
        self.reference = average_scans([self.acquire().intensities for _ in range(max(1, int(scans)))])
        return self.reference

    def acquire_corrected(
        self,
        correction: str = "dark",
        smooth_width: int = 1,
        expected_count: Optional[int] = None,
    ) -> Spectrum:
        spectrum = self.acquire(expected_count=expected_count)
        values: List[float]
        correction = correction.lower()
        if correction in ("none", "raw"):
            values = list(spectrum.intensities)
        elif correction in ("dark", "dark-subtract", "dark_subtract"):
            if self.dark is None:
                raise ConfigurationError("capture or load a dark spectrum first")
            dark = align_series_to_pixels(self.dark, spectrum.pixels, "dark spectrum")
            values = subtract_dark(spectrum.intensities, dark)
            spectrum.dark = list(dark)
            if len(self.dark) != len(dark):
                spectrum.metadata["dark_alignment"] = "aligned %d stored dark values to %d returned pixels" % (len(self.dark), len(dark))
        elif correction in ("transmittance", "transmission"):
            if self.dark is None or self.reference is None:
                raise ConfigurationError("capture or load dark and reference spectra first")
            dark = align_series_to_pixels(self.dark, spectrum.pixels, "dark spectrum")
            reference = align_series_to_pixels(self.reference, spectrum.pixels, "reference spectrum")
            values = transmittance(spectrum.intensities, dark, reference)
            spectrum.dark = list(dark)
            spectrum.reference = list(reference)
            if len(self.dark) != len(dark) or len(self.reference) != len(reference):
                spectrum.metadata["reference_alignment"] = "aligned stored dark/reference values to %d returned pixels" % len(spectrum.pixels)
        elif correction == "absorbance":
            if self.dark is None or self.reference is None:
                raise ConfigurationError("capture or load dark and reference spectra first")
            dark = align_series_to_pixels(self.dark, spectrum.pixels, "dark spectrum")
            reference = align_series_to_pixels(self.reference, spectrum.pixels, "reference spectrum")
            values = absorbance(spectrum.intensities, dark, reference)
            spectrum.dark = list(dark)
            spectrum.reference = list(reference)
            if len(self.dark) != len(dark) or len(self.reference) != len(reference):
                spectrum.metadata["reference_alignment"] = "aligned stored dark/reference values to %d returned pixels" % len(spectrum.pixels)
        else:
            raise ConfigurationError("unknown correction %r" % correction)
        if smooth_width and smooth_width > 1:
            values = boxcar_smooth(values, smooth_width)
            spectrum.metadata["smooth_width"] = int(smooth_width)
        if len(values) != len(spectrum.intensities):
            n = min(len(values), len(spectrum.intensities), len(spectrum.pixels))
            spectrum.metadata["length_alignment"] = "trimmed corrected scan to %d overlapping samples" % n
            spectrum.pixels = spectrum.pixels[:n]
            spectrum.intensities = spectrum.intensities[:n]
            if spectrum.wavelengths_nm is not None:
                spectrum.wavelengths_nm = spectrum.wavelengths_nm[:n]
            if spectrum.dark is not None:
                spectrum.dark = spectrum.dark[:n]
            if spectrum.reference is not None:
                spectrum.reference = spectrum.reference[:n]
            values = values[:n]
        spectrum.metadata["correction"] = correction
        spectrum.corrected = values
        return spectrum

    def auto_expose(
        self,
        target_fraction: float = 0.80,
        tolerance_fraction: float = 0.08,
        max_iterations: int = 8,
    ) -> int:
        """Adjust integration time so the raw peak is near target_fraction of ADC full scale."""
        target_fraction = float(target_fraction)
        if not 0.05 <= target_fraction <= 0.98:
            raise ConfigurationError("target_fraction must be 0.05..0.98")
        target = self.spec.adc_max * target_fraction
        low = self.spec.min_integration_ms
        high = self.spec.max_integration_ms
        current = max(low, min(high, int(self.integration_ms)))
        for _ in range(int(max_iterations)):
            self.set_integration_time(current)
            spectrum = self.acquire()
            peak = max(spectrum.intensities) if spectrum.intensities else 0.0
            if peak <= 0:
                current = min(high, current * 2)
                continue
            if abs(peak - target) <= self.spec.adc_max * tolerance_fraction:
                return current
            estimate = int(round(current * target / peak))
            if peak >= self.spec.adc_max * 0.98:
                high = max(low, current - 1)
                estimate = max(low, current // 2)
            elif peak < target:
                low = max(low, current)
            else:
                high = min(high, current)
            current = max(low, min(high, estimate))
            if high <= low:
                current = low
                break
        self.set_integration_time(current)
        return current


# ---------------------------------------------------------------------------
# Parsing, files, plotting
# ---------------------------------------------------------------------------


def parse_floats(text: str) -> List[float]:
    pattern = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?")
    return [float(m.group(0)) for m in pattern.finditer(text)]


def average_scans(scans: Sequence[Sequence[float]]) -> List[float]:
    if not scans:
        return []
    length = len(scans[0])
    for scan in scans:
        if len(scan) != length:
            raise ValueError("cannot average scans with different lengths")
    return [sum(float(scan[i]) for scan in scans) / len(scans) for i in range(length)]


def load_series_csv(path: str, preferred_columns: Sequence[str] = ("corrected", "intensity")) -> List[float]:
    with open(path, "r", newline="", encoding="utf-8") as handle:
        filtered = (line for line in handle if not line.lstrip().startswith("#"))
        reader = csv.DictReader(filtered)
        if not reader.fieldnames:
            raise ValueError("CSV file has no header")
        field = None
        for candidate in preferred_columns:
            if candidate in reader.fieldnames:
                field = candidate
                break
        if field is None:
            field = reader.fieldnames[-1]
        values = []
        for row in reader:
            cell = row.get(field, "")
            if cell != "":
                values.append(float(cell))
        return values


def load_spectrum_csv(path: str, preferred_columns: Sequence[str] = ("corrected", "intensity")) -> Spectrum:
    """Load a previously exported CSV as a Spectrum for overlay/reference plotting."""
    with open(path, "r", newline="", encoding="utf-8") as handle:
        filtered = (line for line in handle if not line.lstrip().startswith("#"))
        reader = csv.DictReader(filtered)
        if not reader.fieldnames:
            raise ValueError("CSV file has no header")
        field = None
        for candidate in preferred_columns:
            if candidate in reader.fieldnames:
                field = candidate
                break
        if field is None:
            non_coordinate = [name for name in reader.fieldnames if name not in ("pixel", "wavelength_nm")]
            field = non_coordinate[-1] if non_coordinate else reader.fieldnames[-1]
        pixels: List[int] = []
        wavelengths: List[float] = []
        values: List[float] = []
        have_wavelengths = "wavelength_nm" in reader.fieldnames
        for index, row in enumerate(reader):
            cell = row.get(field, "")
            if cell == "":
                continue
            try:
                value = float(cell)
            except ValueError:
                continue
            try:
                pixel = int(float(row.get("pixel", ""))) if row.get("pixel", "") != "" else index
            except ValueError:
                pixel = index
            pixels.append(pixel)
            if have_wavelengths:
                try:
                    wavelengths.append(float(row.get("wavelength_nm", "")))
                except ValueError:
                    have_wavelengths = False
            values.append(value)
        wavelength_list: Optional[List[float]] = wavelengths if have_wavelengths and len(wavelengths) == len(values) else None
        return Spectrum(
            pixels=pixels,
            intensities=values,
            wavelengths_nm=wavelength_list,
            metadata={"source_file": os.path.abspath(path), "source_column": field, "loaded_from_csv": True},
        )


def ascii_plot(values: Sequence[float], width: int = 80, height: int = 20) -> str:
    if not values:
        return "(no data)"
    width = max(10, int(width))
    height = max(5, int(height))
    n = len(values)
    if n > width:
        bucket = n / float(width)
        reduced = []
        for x in range(width):
            start = int(x * bucket)
            end = max(start + 1, int((x + 1) * bucket))
            reduced.append(max(float(v) for v in values[start:end]))
    else:
        reduced = [float(v) for v in values]
        width = len(reduced)
    lo = min(reduced)
    hi = max(reduced)
    span = hi - lo if hi != lo else 1.0
    grid = [[" " for _ in range(width)] for _ in range(height)]
    for x, value in enumerate(reduced):
        y = int(round((value - lo) / span * (height - 1)))
        grid[height - 1 - y][x] = "*"
    lines = ["".join(row) for row in grid]
    lines.append("min=%.6g max=%.6g count=%d" % (lo, hi, n))
    return "\n".join(lines)


def spectrum_xy(spectrum: Spectrum, use_wavelength_axis: bool = True) -> Tuple[List[float], List[float], str, str]:
    """Return x/y data and axis labels for plotting."""
    if use_wavelength_axis and spectrum.wavelengths_nm is not None:
        x_values = [float(x) for x in spectrum.wavelengths_nm]
        x_label = "Wavelength (nm)"
    else:
        x_values = [float(x) for x in spectrum.pixels]
        x_label = "Pixel"
    y_values = [float(y) for y in spectrum.active_values()]
    correction = str(spectrum.metadata.get("correction", "raw"))
    if correction in ("raw", "none"):
        y_label = "Intensity"
    elif correction in ("transmittance", "transmission"):
        y_label = "Transmittance"
    elif correction == "absorbance":
        y_label = "Absorbance"
    else:
        y_label = "Corrected intensity"
    return x_values, y_values, x_label, y_label


def finite_range(values: Sequence[float], pad_fraction: float = 0.03) -> Tuple[float, float]:
    finite = [float(v) for v in values if math.isfinite(float(v))]
    if not finite:
        return 0.0, 1.0
    lo = min(finite)
    hi = max(finite)
    if hi == lo:
        delta = abs(hi) * 0.05 or 1.0
        return lo - delta, hi + delta
    pad = (hi - lo) * float(pad_fraction)
    return lo - pad, hi + pad


def tick_values(lo: float, hi: float, count: int = 6) -> List[float]:
    if count <= 1 or hi <= lo:
        return [lo, hi]
    return [lo + (hi - lo) * i / float(count - 1) for i in range(count)]


def wavelength_to_rgb_hex(wavelength_nm: float, blend_with_white: float = 0.70) -> str:
    """Approximate visible wavelength color as a pale Tk-compatible #RRGGBB."""
    wl = float(wavelength_nm)
    if wl < 380.0 or wl > 780.0 or not math.isfinite(wl):
        return "#ffffff"
    if wl < 440.0:
        r, g, b = -(wl - 440.0) / (440.0 - 380.0), 0.0, 1.0
    elif wl < 490.0:
        r, g, b = 0.0, (wl - 440.0) / (490.0 - 440.0), 1.0
    elif wl < 510.0:
        r, g, b = 0.0, 1.0, -(wl - 510.0) / (510.0 - 490.0)
    elif wl < 580.0:
        r, g, b = (wl - 510.0) / (580.0 - 510.0), 1.0, 0.0
    elif wl < 645.0:
        r, g, b = 1.0, -(wl - 645.0) / (645.0 - 580.0), 0.0
    else:
        r, g, b = 1.0, 0.0, 0.0
    if wl < 420.0:
        factor = 0.3 + 0.7 * (wl - 380.0) / (420.0 - 380.0)
    elif wl > 700.0:
        factor = 0.3 + 0.7 * (780.0 - wl) / (780.0 - 700.0)
    else:
        factor = 1.0
    r, g, b = r * factor, g * factor, b * factor
    blend = max(0.0, min(1.0, float(blend_with_white)))
    r = r * (1.0 - blend) + blend
    g = g * (1.0 - blend) + blend
    b = b * (1.0 - blend) + blend
    return "#%02x%02x%02x" % (int(max(0, min(255, round(r * 255)))), int(max(0, min(255, round(g * 255)))), int(max(0, min(255, round(b * 255)))))


def save_spectrum_svg(
    spectrum: Spectrum,
    path: str,
    title: str = "BWTEK Spectrum",
    width: int = 1000,
    height: int = 620,
) -> None:
    """Save a portable SVG line graph without external plotting libraries."""
    x_values, y_values, x_label, y_label = spectrum_xy(spectrum)
    width = max(400, int(width))
    height = max(300, int(height))
    left, right, top, bottom = 82, 30, 56, 72
    plot_w = width - left - right
    plot_h = height - top - bottom
    x_lo, x_hi = finite_range(x_values, pad_fraction=0.0)
    y_lo, y_hi = finite_range(y_values, pad_fraction=0.05)

    def sx(x: float) -> float:
        return left + ((x - x_lo) / (x_hi - x_lo if x_hi != x_lo else 1.0)) * plot_w

    def sy(y: float) -> float:
        return top + plot_h - ((y - y_lo) / (y_hi - y_lo if y_hi != y_lo else 1.0)) * plot_h

    pairs = [(x, y) for x, y in zip(x_values, y_values) if math.isfinite(x) and math.isfinite(y)]
    point_text = " ".join("%.2f,%.2f" % (sx(x), sy(y)) for x, y in pairs)
    peak = max((y for _, y in pairs), default=float("nan"))
    escaped_title = html.escape(title)
    escaped_x = html.escape(x_label)
    escaped_y = html.escape(y_label)
    subtitle = "model=%s  integration=%sms  average=%s  points=%d  peak=%.6g" % (
        html.escape(str(spectrum.metadata.get("model", ""))),
        html.escape(str(spectrum.metadata.get("integration_ms", ""))),
        html.escape(str(spectrum.metadata.get("average", ""))),
        len(y_values),
        peak,
    )

    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d">'
        % (width, height, width, height),
        '<rect width="100%" height="100%" fill="white"/>',
        '<text x="%d" y="28" font-family="Arial, sans-serif" font-size="22" font-weight="bold">%s</text>'
        % (left, escaped_title),
        '<text x="%d" y="48" font-family="Arial, sans-serif" font-size="12" fill="#555">%s</text>'
        % (left, subtitle),
        '<rect x="%d" y="%d" width="%d" height="%d" fill="none" stroke="#222" stroke-width="1"/>'
        % (left, top, plot_w, plot_h),
    ]
    for x in tick_values(x_lo, x_hi):
        px = sx(x)
        lines.append('<line x1="%.2f" y1="%d" x2="%.2f" y2="%d" stroke="#e7e7e7" stroke-width="1"/>' % (px, top, px, top + plot_h))
        lines.append('<text x="%.2f" y="%d" font-family="Arial, sans-serif" font-size="11" text-anchor="middle">%.6g</text>' % (px, top + plot_h + 20, x))
    for y in tick_values(y_lo, y_hi):
        py = sy(y)
        lines.append('<line x1="%d" y1="%.2f" x2="%d" y2="%.2f" stroke="#e7e7e7" stroke-width="1"/>' % (left, py, left + plot_w, py))
        lines.append('<text x="%d" y="%.2f" font-family="Arial, sans-serif" font-size="11" text-anchor="end" dominant-baseline="middle">%.6g</text>' % (left - 8, py, y))
    if point_text:
        lines.append('<polyline points="%s" fill="none" stroke="#1769aa" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round"/>' % point_text)
    lines.append('<text x="%d" y="%d" font-family="Arial, sans-serif" font-size="14" text-anchor="middle">%s</text>' % (left + plot_w // 2, height - 24, escaped_x))
    lines.append('<text x="18" y="%d" font-family="Arial, sans-serif" font-size="14" text-anchor="middle" transform="rotate(-90,18,%d)">%s</text>' % (top + plot_h // 2, top + plot_h // 2, escaped_y))
    lines.append('</svg>')
    with open(path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines))


def draw_spectrum_on_canvas(
    canvas: Any,
    spectrum: Spectrum,
    title: str = "Spectrum",
    y_min: Optional[float] = None,
    y_max: Optional[float] = None,
    x_axis: str = "auto",
    reference_traces: Optional[Sequence[Tuple[str, Spectrum, str]]] = None,
    show_color_background: bool = False,
    show_legend: bool = True,
) -> None:
    """Draw the current spectrum and optional CSV reference traces on a Tkinter Canvas."""
    canvas.delete("all")
    canvas.update_idletasks()
    width = max(320, int(canvas.winfo_width() or 800))
    height = max(220, int(canvas.winfo_height() or 480))
    left, right, top, bottom = 78, 120, 42, 60
    plot_w = width - left - right
    plot_h = height - top - bottom
    use_wavelength_axis = str(x_axis).lower() not in ("pixel", "pixels")
    dark_mode = bool(getattr(canvas, "_dark_mode", False))
    bg_color = "#1e1f22" if dark_mode else "white"
    plot_bg = "#24262b" if dark_mode else "white"
    text_color = "#e8e8e8" if dark_mode else "#111111"
    axis_color = "#b8b8b8" if dark_mode else "#222222"
    grid_color = "#3a3d44" if dark_mode else "#e7e7e7"
    tooltip_bg = "#2d3036" if dark_mode else "#ffffe0"
    tooltip_outline = "#7e8491" if dark_mode else "#777777"
    cursor_color = "#aaaaaa" if dark_mode else "#888888"
    canvas.configure(background=bg_color)

    trace_specs: List[Dict[str, Any]] = []
    current_x, current_y, x_label, y_label = spectrum_xy(spectrum, use_wavelength_axis=use_wavelength_axis)
    trace_specs.append({"label": "Current", "spectrum": spectrum, "x": current_x, "y": current_y, "color": "#1769aa", "width": 2})

    for label, ref_spectrum, color in list(reference_traces or []):
        rx, ry, _r_x_label, _r_y_label = spectrum_xy(ref_spectrum, use_wavelength_axis=use_wavelength_axis)
        if rx and ry:
            trace_specs.append({"label": label, "spectrum": ref_spectrum, "x": rx, "y": ry, "color": color, "width": 1})

    all_x = [float(x) for trace in trace_specs for x in trace["x"] if math.isfinite(float(x))]
    all_y = [float(y) for trace in trace_specs for y in trace["y"] if math.isfinite(float(y))]
    if not all_x or not all_y:
        canvas.create_text(width // 2, height // 2, text="No data", fill=text_color)
        return

    x_lo, x_hi = finite_range(all_x, pad_fraction=0.0)
    auto_y_lo, auto_y_hi = finite_range(all_y, pad_fraction=0.05)
    if y_min is None and y_max is None:
        y_lo, y_hi = auto_y_lo, auto_y_hi
    else:
        y_lo = auto_y_lo if y_min is None else float(y_min)
        y_hi = auto_y_hi if y_max is None else float(y_max)
        if not math.isfinite(y_lo) or not math.isfinite(y_hi) or y_hi <= y_lo:
            y_lo, y_hi = auto_y_lo, auto_y_hi

    def sx(x: float) -> float:
        return left + ((x - x_lo) / (x_hi - x_lo if x_hi != x_lo else 1.0)) * plot_w

    def sy(y: float) -> float:
        return top + plot_h - ((y - y_lo) / (y_hi - y_lo if y_hi != y_lo else 1.0)) * plot_h

    canvas._spectrum_plot = {
        "traces": trace_specs,
        "spectrum": spectrum,
        "x_values": current_x,
        "y_values": current_y,
        "x_label": x_label,
        "y_label": y_label,
        "left": left,
        "right": right,
        "top": top,
        "bottom": bottom,
        "plot_w": plot_w,
        "plot_h": plot_h,
        "x_lo": x_lo,
        "x_hi": x_hi,
        "y_lo": y_lo,
        "y_hi": y_hi,
    }

    canvas.create_rectangle(left, top, left + plot_w, top + plot_h, outline=axis_color, fill=plot_bg)

    def wavelength_for_axis_value(x_value: float) -> Optional[float]:
        if use_wavelength_axis:
            return float(x_value)
        if spectrum.wavelengths_nm is None or not spectrum.pixels:
            return None
        pixels = [float(p) for p in spectrum.pixels]
        wavelengths = [float(w) for w in spectrum.wavelengths_nm]
        if len(pixels) != len(wavelengths):
            return None
        if x_value <= pixels[0]:
            return wavelengths[0]
        if x_value >= pixels[-1]:
            return wavelengths[-1]
        pos = (x_value - pixels[0]) / ((pixels[-1] - pixels[0]) or 1.0) * (len(pixels) - 1)
        i = int(max(0, min(len(pixels) - 2, math.floor(pos))))
        x0, x1 = pixels[i], pixels[i + 1]
        y0, y1 = wavelengths[i], wavelengths[i + 1]
        frac = 0.0 if x1 == x0 else (x_value - x0) / (x1 - x0)
        return y0 + frac * (y1 - y0)

    if show_color_background:
        strips = max(80, min(240, int(plot_w // 3) or 80))
        for i in range(strips):
            xa = x_lo + (x_hi - x_lo) * i / float(strips)
            xb = x_lo + (x_hi - x_lo) * (i + 1) / float(strips)
            wl = wavelength_for_axis_value((xa + xb) * 0.5)
            if wl is None or wl < 380.0 or wl > 780.0:
                continue
            canvas.create_rectangle(sx(xa), top, sx(xb) + 1, top + plot_h, outline="", fill=wavelength_to_rgb_hex(wl, 0.72))
        canvas.create_rectangle(left, top, left + plot_w, top + plot_h, outline=axis_color, fill="")

    if use_wavelength_axis:
        x_ticks = [float(v) for v in range(int(math.ceil(x_lo / 5.0) * 5), int(math.floor(x_hi / 5.0) * 5) + 1, 5)]
        # Keep labels readable: if there are too many 5 nm ticks, draw every Nth
        # label while still snapping to exact 5 nm values with no decimals.
        max_labels = max(4, int(plot_w // 60))
        label_stride = max(1, int(math.ceil(len(x_ticks) / float(max_labels))))
    else:
        x_ticks = tick_values(x_lo, x_hi)
        label_stride = 1
    for tick_index, x in enumerate(x_ticks):
        px = sx(x)
        canvas.create_line(px, top, px, top + plot_h, fill=grid_color)
        if tick_index % label_stride == 0:
            label = "%d" % int(round(x)) if use_wavelength_axis else "%.6g" % x
            canvas.create_text(px, top + plot_h + 18, text=label, anchor="n", font=("TkDefaultFont", 8), fill=text_color)
    for y in tick_values(y_lo, y_hi):
        py = sy(y)
        canvas.create_line(left, py, left + plot_w, py, fill=grid_color)
        canvas.create_text(left - 8, py, text="%.6g" % y, anchor="e", font=("TkDefaultFont", 8), fill=text_color)

    for trace in trace_specs:
        x_values = trace["x"]
        y_values = trace["y"]
        coords: List[float] = []
        max_points = max(2, int(plot_w * 2))
        n = len(y_values)
        if n > max_points:
            step = n / float(max_points)
            indices = [min(n - 1, int(i * step)) for i in range(max_points)]
        else:
            indices = list(range(n))
        for i in indices:
            x = float(x_values[i])
            y = float(y_values[i])
            if math.isfinite(x) and math.isfinite(y):
                coords.extend([sx(x), sy(y)])
        if len(coords) >= 4:
            canvas.create_line(*coords, fill=trace["color"], width=trace["width"])

    canvas.create_text(left, 16, anchor="w", text=title, font=("TkDefaultFont", 13, "bold"), fill=text_color)
    canvas.create_text(width - right, 18, anchor="e", text="peak %.6g   points %d" % (spectrum.peak(), len(current_y)), fill=text_color)
    canvas.create_text(left + plot_w / 2, height - 18, text=x_label, fill=text_color)
    canvas.create_text(18, top + plot_h / 2, text=y_label, angle=90, fill=text_color)

    if show_legend:
        legend_x = left + plot_w + 14
        legend_y = top + 6
        canvas.create_text(legend_x, legend_y, anchor="nw", text="Traces", font=("TkDefaultFont", 9, "bold"), fill=text_color)
        for index, trace in enumerate(trace_specs[:12]):
            y = legend_y + 20 + index * 18
            canvas.create_line(legend_x, y + 7, legend_x + 22, y + 7, fill=trace["color"], width=max(2, int(trace["width"])))
            label = str(trace["label"])
            if len(label) > 18:
                label = label[:15] + "..."
            canvas.create_text(legend_x + 28, y, anchor="nw", text=label, font=("TkDefaultFont", 8), fill=text_color)


def show_spectrum_window(spectrum: Spectrum, title: str = "BWTEK Spectrum") -> None:
    """Show a single acquired spectrum in a Tkinter window."""
    try:
        import tkinter as tk
        from tkinter import ttk
    except ImportError as exc:
        raise ConfigurationError("Tkinter is not available in this Python installation") from exc
    root = tk.Tk()
    root.title(title)
    root.columnconfigure(0, weight=1)
    root.rowconfigure(0, weight=1)
    canvas = tk.Canvas(root, background="white", width=900, height=560)
    canvas.grid(row=0, column=0, sticky="nsew", padx=8, pady=8)
    footer = ttk.Frame(root, padding=(8, 0, 8, 8))
    footer.grid(row=1, column=0, sticky="ew")
    footer.columnconfigure(0, weight=1)
    ttk.Label(footer, text="Close this window to return to the command line.").grid(row=0, column=0, sticky="w")
    ttk.Button(footer, text="Close", command=root.destroy).grid(row=0, column=1, sticky="e")

    def redraw(_event: Any = None) -> None:
        draw_spectrum_on_canvas(canvas, spectrum, title=title)

    canvas.bind("<Configure>", redraw)
    root.after(50, redraw)
    root.mainloop()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def available_serial_ports() -> List[str]:
    try:
        from serial.tools import list_ports  # type: ignore
    except ImportError:
        return []
    return [port.device for port in list_ports.comports()]


def terminator_from_name(name: str) -> bytes:
    mapping = {"cr": b"\r", "lf": b"\n", "crlf": b"\r\n", "none": b""}
    if name not in mapping:
        raise ConfigurationError("unknown terminator %r" % name)
    return mapping[name]


def make_spectrometer_from_args(args: argparse.Namespace) -> Spectrometer:
    model = normalize_model_name(args.model)
    spec = MODEL_SPECS[model]
    baud = int(args.baud) if args.baud else spec.default_baud
    if getattr(args, "simulate", False):
        transport: Transport = SimulatorTransport(model=model)
    else:
        if not args.port:
            raise ConfigurationError("--port is required for real hardware; use --simulate for the built-in simulator")
        transport = PySerialTransport(port=args.port, baudrate=baud, timeout=args.timeout)
    return Spectrometer(
        transport=transport,
        model=model,
        timeout=args.timeout,
        command_terminator=terminator_from_name(args.terminator),
        allow_legacy_data_mode_commands=not args.no_legacy_data_mode_commands,
    )


def configure_before_acquire(spec: Spectrometer, args: argparse.Namespace) -> None:
    if getattr(args, "initialize", False):
        spec.initialize()
    if getattr(args, "mode", None) and args.mode != "current":
        spec.set_data_mode(args.mode)
    if getattr(args, "integration", None) is not None:
        spec.set_integration_time(args.integration)
    if getattr(args, "average", None) is not None:
        spec.set_average(args.average)
    if getattr(args, "coefficients", None):
        spec.set_coefficients(args.coefficients)
    elif getattr(args, "query_coefficients", False):
        try:
            spec.query_coefficients()
        except Exception as exc:
            print("warning: could not query coefficients: %s" % exc, file=sys.stderr)
    if getattr(args, "auto_expose", False):
        chosen = spec.auto_expose(target_fraction=args.auto_expose_target)
        print("auto exposure selected integration_ms=%d" % chosen, file=sys.stderr)


def command_list_ports(_args: argparse.Namespace) -> int:
    ports = available_serial_ports()
    if not ports:
        print("No ports found, or pyserial is not installed.")
        print("For real hardware install pyserial: python -m pip install pyserial")
        return 0
    for port in ports:
        print(port)
    return 0


def command_query(args: argparse.Namespace) -> int:
    spec = make_spectrometer_from_args(args)
    try:
        result = spec.query_all(include_optional=not args.basic)
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0
    finally:
        spec.close()


def command_init(args: argparse.Namespace) -> int:
    spec = make_spectrometer_from_args(args)
    try:
        spec.initialize()
        print("initialized %s" % spec.spec.name)
        return 0
    finally:
        spec.close()


def command_set(args: argparse.Namespace) -> int:
    spec = make_spectrometer_from_args(args)
    try:
        if args.initialize:
            spec.initialize()
        if args.mode:
            spec.set_data_mode(args.mode)
        if args.integration is not None:
            spec.set_integration_time(args.integration)
        if args.average is not None:
            spec.set_average(args.average)
        if args.baud_set is not None:
            actual = spec.set_baud_rate(args.baud_set)
            print("baud_rate=%d" % actual)
        if args.coefficients:
            spec.set_coefficients(args.coefficients)
        if args.pixel_mode:
            spec.set_pixel_mode(*args.pixel_mode)
        if args.time_delay is not None:
            spec.set_time_delay(args.time_delay)
        if args.multiplier is not None:
            spec.set_multiplier(args.multiplier)
        print("set complete")
        return 0
    finally:
        spec.close()


def command_acquire(args: argparse.Namespace) -> int:
    spec = make_spectrometer_from_args(args)
    try:
        configure_before_acquire(spec, args)
        if args.dark:
            spec.dark = load_series_csv(args.dark)
        if args.reference:
            spec.reference = load_series_csv(args.reference)
        if args.correction and args.correction != "raw":
            spectrum = spec.acquire_corrected(correction=args.correction, smooth_width=args.smooth)
        else:
            spectrum = spec.acquire()
            if args.smooth and args.smooth > 1:
                spectrum.corrected = boxcar_smooth(spectrum.intensities, args.smooth)
                spectrum.metadata["smooth_width"] = args.smooth
                spectrum.metadata["correction"] = "smooth-only"
        if args.output:
            ext = os.path.splitext(args.output)[1].lower()
            if ext == ".json":
                spectrum.save_json(args.output)
            else:
                spectrum.save_csv(args.output)
            print("saved %d points to %s" % (len(spectrum.intensities), args.output))
        if args.graph:
            save_spectrum_svg(spectrum, args.graph, title="BWTEK Spectrum")
            print("saved graph to %s" % args.graph)
        if args.text_plot:
            print(ascii_plot(spectrum.active_values(), width=args.plot_width, height=args.plot_height))
        if args.plot:
            show_spectrum_window(spectrum, title="BWTEK Spectrum")
        if not args.output and not args.text_plot and not args.graph and not args.plot:
            print(json.dumps({"metadata": spectrum.metadata, "peak": spectrum.peak()}, indent=2, sort_keys=True))
        return 0
    finally:
        spec.close()


def save_spectrum_by_extension(spectrum: Spectrum, path: str) -> None:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".json":
        spectrum.save_json(path)
    else:
        spectrum.save_csv(path)


class LivePlotWindow:
    """Small continuously updating graph window used by the CLI live command."""

    def __init__(self, root: Any, spec: Spectrometer, args: argparse.Namespace) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.ttk = ttk
        self.root = root
        self.spec = spec
        self.args = args
        self.queue: "queue.Queue[Tuple[str, Any]]" = queue.Queue()
        self.running = True
        self.worker_busy = False
        self.scan_count = 0
        self.last_spectrum: Optional[Spectrum] = None
        self.interval_ms = max(0, int(round(float(args.interval) * 1000.0)))

        self.status_var = tk.StringVar(value="Starting live acquisition")
        self.button_text = tk.StringVar(value="Stop")

        self.root.title("BWTEK Live Spectrum")
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        self.canvas = tk.Canvas(root, background="white", width=950, height=560)
        self.canvas.grid(row=0, column=0, sticky="nsew", padx=8, pady=8)
        footer = ttk.Frame(root, padding=(8, 0, 8, 8))
        footer.grid(row=1, column=0, sticky="ew")
        footer.columnconfigure(0, weight=1)
        ttk.Label(footer, textvariable=self.status_var).grid(row=0, column=0, sticky="w")
        ttk.Button(footer, textvariable=self.button_text, command=self.toggle_running).grid(row=0, column=1, padx=(8, 0))
        ttk.Button(footer, text="Close", command=self.close).grid(row=0, column=2, padx=(8, 0))

        self.canvas.bind("<Configure>", self.redraw)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(50, self.start_next_scan)
        self.root.after(100, self.poll_queue)

    def redraw(self, _event: Any = None) -> None:
        if self.last_spectrum is not None:
            draw_spectrum_on_canvas(self.canvas, self.last_spectrum, title="BWTEK Live Spectrum")

    def toggle_running(self) -> None:
        self.running = not self.running
        self.button_text.set("Stop" if self.running else "Start")
        self.status_var.set("Live acquisition %s" % ("running" if self.running else "paused"))
        if self.running and not self.worker_busy:
            self.root.after(10, self.start_next_scan)

    def close(self) -> None:
        self.running = False
        try:
            self.spec.close()
        except Exception:
            pass
        self.root.destroy()

    def acquire_for_live(self, scan_index: int) -> Spectrum:
        correction = self.args.correction
        smooth = int(self.args.smooth or 1)
        if correction and correction != "raw":
            spectrum = self.spec.acquire_corrected(correction=correction, smooth_width=smooth)
        else:
            spectrum = self.spec.acquire()
            if smooth > 1:
                spectrum.corrected = boxcar_smooth(spectrum.intensities, smooth)
                spectrum.metadata["smooth_width"] = smooth
                spectrum.metadata["correction"] = "smooth-only"
        spectrum.metadata["scan_index"] = scan_index
        spectrum.metadata["live"] = True
        return spectrum

    def save_live_outputs(self, spectrum: Spectrum) -> None:
        if self.args.output:
            save_spectrum_by_extension(spectrum, self.args.output)
        if self.args.output_dir:
            os.makedirs(self.args.output_dir, exist_ok=True)
            csv_path = os.path.join(self.args.output_dir, "scan_%06d.csv" % int(spectrum.metadata.get("scan_index", 0)))
            spectrum.save_csv(csv_path)
        if self.args.graph:
            save_spectrum_svg(spectrum, self.args.graph, title="BWTEK Live Spectrum")

    def start_next_scan(self) -> None:
        if not self.running or self.worker_busy:
            return
        if self.args.max_scans is not None and self.scan_count >= int(self.args.max_scans):
            self.running = False
            self.button_text.set("Start")
            self.status_var.set("Stopped after %d scans" % self.scan_count)
            return
        scan_index = self.scan_count + 1
        self.worker_busy = True

        def worker() -> None:
            started = time.time()
            try:
                spectrum = self.acquire_for_live(scan_index)
                self.save_live_outputs(spectrum)
                elapsed = time.time() - started
                self.queue.put(("spectrum", (spectrum, elapsed)))
            except Exception as exc:
                self.queue.put(("error", str(exc)))
            finally:
                self.queue.put(("done", None))

        threading.Thread(target=worker, daemon=True).start()

    def poll_queue(self) -> None:
        try:
            while True:
                kind, payload = self.queue.get_nowait()
                if kind == "spectrum":
                    spectrum, elapsed = payload
                    self.last_spectrum = spectrum
                    self.scan_count = int(spectrum.metadata.get("scan_index", self.scan_count + 1))
                    draw_spectrum_on_canvas(self.canvas, spectrum, title="BWTEK Live Spectrum")
                    self.status_var.set(
                        "scan %d   peak %.6g   points %d   %.2fs"
                        % (self.scan_count, spectrum.peak(), len(spectrum.intensities), elapsed)
                    )
                elif kind == "error":
                    self.running = False
                    self.button_text.set("Start")
                    self.status_var.set("ERROR: %s" % payload)
                elif kind == "done":
                    self.worker_busy = False
                    if self.running:
                        self.root.after(self.interval_ms, self.start_next_scan)
        except queue.Empty:
            pass
        self.root.after(100, self.poll_queue)


def command_live(args: argparse.Namespace) -> int:
    try:
        import tkinter as tk
    except ImportError as exc:
        raise ConfigurationError("Tkinter is not available in this Python installation") from exc

    spec = make_spectrometer_from_args(args)
    try:
        configure_before_acquire(spec, args)
        if args.dark:
            spec.dark = load_series_csv(args.dark)
        if args.reference:
            spec.reference = load_series_csv(args.reference)
        if args.output_dir:
            os.makedirs(args.output_dir, exist_ok=True)
        root = tk.Tk()
        LivePlotWindow(root, spec, args)
        root.mainloop()
        return 0
    finally:
        spec.close()


def command_dark_reference(args: argparse.Namespace) -> int:
    spec = make_spectrometer_from_args(args)
    try:
        configure_before_acquire(spec, args)
        if args.kind == "dark":
            values = spec.capture_dark(scans=args.scans)
        else:
            values = spec.capture_reference(scans=args.scans)
        pixels = spec.expected_pixels()
        wavelengths = wavelengths_for_pixels(pixels, spec.coefficients) if spec.coefficients else None
        spectrum = Spectrum(
            pixels=pixels,
            intensities=values,
            wavelengths_nm=wavelengths,
            metadata={
                "model": spec.spec.name,
                "kind": args.kind,
                "scans": args.scans,
                "integration_ms": spec.integration_ms,
                "average": spec.average,
                "created_unix": time.time(),
            },
        )
        spectrum.save_csv(args.output)
        print("saved %s to %s" % (args.kind, args.output))
        return 0
    finally:
        spec.close()


def command_selftest(_args: argparse.Namespace) -> int:
    # Values and transmitted bytes from the compression example table in the command document.
    values = [
        185, 2151, 836, 453, 210, 118, 90, 89, 87, 89, 86, 88, 98, 121,
        383, 1162, 634, 356, 211, 132, 88, 83, 86, 82, 91, 92, 81, 80,
        84, 84, 85, 83, 80, 80, 88, 94, 90, 103, 111, 138,
    ]
    expected_hex = (
        "80 00 b9 80 08 67 80 03 44 80 01 c5 80 00 d2 a4 e4 ff fe 02 fd 02 0a 17 "
        "80 01 7f 80 04 8a 80 02 7a 80 01 64 80 00 d3 b1 d4 fb 03 fc 09 01 f5 "
        "ff 04 00 01 fe fd 00 08 06 fc 0d 08 1b"
    )
    expected = bytes.fromhex(expected_hex)
    encoded = encode_compressed_binary(values)
    decoded = decode_compressed_binary_bytes(expected, count=len(values))
    if encoded != expected:
        raise AssertionError("compression encoder did not match document example")
    if decoded != values:
        raise AssertionError("compression decoder did not match document example")
    sim = SimulatorTransport(model="BTC110")
    spec = Spectrometer(sim, model="BTC110")
    spec.set_compressed_binary_mode()
    spectrum = spec.acquire()
    if len(spectrum.intensities) != DEFAULT_PIXEL_COUNT:
        raise AssertionError("simulated acquisition returned wrong point count")
    class EchoSimulatorTransport(SimulatorTransport):
        def write(self, data: bytes) -> None:
            self._rx.extend(data)
            super().write(data)

    echo_sim = EchoSimulatorTransport(model="BTC100")
    echo_spec = Spectrometer(echo_sim, model="BTC100")
    echo_spec.set_integration_time(200)
    echo_spec.set_average(1)
    echo_spectrum = echo_spec.acquire()
    if len(echo_spectrum.intensities) != DEFAULT_PIXEL_COUNT:
        raise AssertionError("echo-tolerant acquisition returned wrong point count")
    print("selftest passed: compression example, decoder, simulator acquisition, command echo handling")
    return 0


def command_gui(args: argparse.Namespace) -> int:
    run_gui(args)
    return 0


def add_common_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--model", default="BTC110", choices=sorted(MODEL_SPECS), help="spectrometer model")
    parser.add_argument("--port", help="serial port, for example COM3 or /dev/ttyUSB0")
    parser.add_argument("--baud", type=int, default=None, help="startup baud rate; defaults by model")
    parser.add_argument("--timeout", type=float, default=2.0, help="serial timeout seconds")
    parser.add_argument("--terminator", default="cr", choices=["cr", "lf", "crlf", "none"], help="command terminator")
    parser.add_argument("--simulate", action="store_true", help="use built-in simulator instead of serial hardware")
    parser.add_argument(
        "--no-legacy-data-mode-commands",
        action="store_true",
        help="do not fall back to uppercase A/B for data mode commands",
    )


def add_acquire_setup_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--initialize", action="store_true", help="send Q before other setup")
    parser.add_argument("--mode", choices=["current", "ascii", "compressed", "binary"], default="current")
    parser.add_argument("--integration", type=int, help="integration time in ms")
    parser.add_argument("--average", type=int, help="number of spectra to average")
    parser.add_argument("--coefficients", type=float, nargs=4, metavar=("A0", "A1", "A2", "A3"), help="wavelength polynomial coefficients")
    parser.add_argument("--query-coefficients", action="store_true", help="query wavelength coefficients before acquisition")
    parser.add_argument("--auto-expose", action="store_true", help="automatically choose integration time")
    parser.add_argument("--auto-expose-target", type=float, default=0.80, help="target ADC fraction for auto exposure")


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Portable BWTEK BTC/BRC spectrometer software")
    add_common_args(parser)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("list-ports", help="list serial ports visible through pyserial")
    p.set_defaults(func=command_list_ports)

    p = sub.add_parser("query", help="query spectrometer parameters")
    p.add_argument("--basic", action="store_true", help="skip optional model-specific queries")
    p.set_defaults(func=command_query)

    p = sub.add_parser("init", help="initialize spectrometer with Q")
    p.set_defaults(func=command_init)

    p = sub.add_parser("set", help="set one or more parameters")
    p.add_argument("--initialize", action="store_true")
    p.add_argument("--mode", choices=["ascii", "compressed", "binary"])
    p.add_argument("--integration", type=int)
    p.add_argument("--average", type=int)
    p.add_argument("--baud-set", type=int, help="baud code 0..7 or actual baud value")
    p.add_argument("--coefficients", type=float, nargs=4, metavar=("A0", "A1", "A2", "A3"))
    p.add_argument("--pixel-mode", type=int, nargs="+", help="BRC110 P command args, e.g. 3 400 700 10")
    p.add_argument("--time-delay", type=int, help="BRC110 T command in ms")
    p.add_argument("--multiplier", type=float, help="BTC200 multiplier")
    p.set_defaults(func=command_set)

    p = sub.add_parser("acquire", help="acquire one spectrum")
    add_acquire_setup_args(p)
    p.add_argument("--output", "-o", help="CSV or JSON output path")
    p.add_argument("--dark", help="dark CSV to apply")
    p.add_argument("--reference", help="reference CSV to apply")
    p.add_argument("--correction", choices=["raw", "dark", "transmittance", "absorbance"], default="raw")
    p.add_argument("--smooth", type=int, default=1, help="boxcar smoothing width")
    p.add_argument("--text-plot", action="store_true", help="print a small terminal plot")
    p.add_argument("--plot", action="store_true", help="open a Tkinter graph window after acquisition")
    p.add_argument("--graph", "--svg", dest="graph", help="save a portable SVG graph to this path")
    p.add_argument("--plot-width", type=int, default=80)
    p.add_argument("--plot-height", type=int, default=20)
    p.set_defaults(func=command_acquire)

    p = sub.add_parser("live", help="continuously acquire and update a graph window")
    add_acquire_setup_args(p)
    p.add_argument("--dark", help="dark CSV to apply")
    p.add_argument("--reference", help="reference CSV to apply")
    p.add_argument("--correction", choices=["raw", "dark", "transmittance", "absorbance"], default="raw")
    p.add_argument("--smooth", type=int, default=1, help="boxcar smoothing width")
    p.add_argument("--interval", type=float, default=0.0, help="seconds to wait after each scan before starting the next")
    p.add_argument("--output", "-o", help="CSV or JSON path to overwrite with the latest scan")
    p.add_argument("--output-dir", help="directory where every scan is saved as scan_NNNNNN.csv")
    p.add_argument("--max-scans", type=int, help="stop after this many scans")
    p.add_argument("--graph", "--svg", dest="graph", help="SVG path to overwrite with the latest graph")
    p.set_defaults(func=command_live)

    p = sub.add_parser("capture", help="capture dark or reference spectrum")
    add_acquire_setup_args(p)
    p.add_argument("kind", choices=["dark", "reference"])
    p.add_argument("--scans", type=int, default=1, help="number of scans to average")
    p.add_argument("--output", "-o", required=True, help="CSV output path")
    p.set_defaults(func=command_dark_reference)

    p = sub.add_parser("gui", help="launch Tkinter GUI")
    p.set_defaults(func=command_gui)

    p = sub.add_parser("selftest", help="run compression and simulator self-tests")
    p.set_defaults(func=command_selftest)
    return parser


# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------


class GuiLogHandler:
    def __init__(self, callback: Callable[[str], None]) -> None:
        self.callback = callback

    def write(self, message: str) -> None:
        message = message.strip()
        if message:
            self.callback(message)

    def flush(self) -> None:
        pass


class ToolTip:
    """Small Tkinter tooltip helper used by the GUI buttons."""

    def __init__(self, widget: Any, text: str, delay_ms: int = 500) -> None:
        self.widget = widget
        self.text = text
        self.delay_ms = int(delay_ms)
        self._after_id: Optional[str] = None
        self._tip: Any = None
        widget.bind("<Enter>", self._schedule, add="+")
        widget.bind("<Leave>", self._hide, add="+")
        widget.bind("<ButtonPress>", self._hide, add="+")

    def _schedule(self, _event: Any = None) -> None:
        self._cancel()
        self._after_id = self.widget.after(self.delay_ms, self._show)

    def _cancel(self) -> None:
        if self._after_id is not None:
            try:
                self.widget.after_cancel(self._after_id)
            except Exception:
                pass
            self._after_id = None

    def _show(self) -> None:
        if self._tip is not None or not self.text:
            return
        try:
            import tkinter as tk
            x = self.widget.winfo_rootx() + 16
            y = self.widget.winfo_rooty() + self.widget.winfo_height() + 8
            self._tip = tk.Toplevel(self.widget)
            self._tip.wm_overrideredirect(True)
            self._tip.wm_geometry("+%d+%d" % (x, y))
            label = tk.Label(
                self._tip,
                text=self.text,
                justify="left",
                background="#ffffe0",
                relief="solid",
                borderwidth=1,
                padx=6,
                pady=3,
                font=("TkDefaultFont", 9),
                wraplength=360,
            )
            label.pack()
        except Exception:
            self._tip = None

    def _hide(self, _event: Any = None) -> None:
        self._cancel()
        if self._tip is not None:
            try:
                self._tip.destroy()
            except Exception:
                pass
            self._tip = None


def attach_tooltip(widget: Any, text: str) -> Any:
    ToolTip(widget, text)
    return widget


class SpectrometerGUI:
    def __init__(self, root: Any, args: argparse.Namespace) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.ttk = ttk
        self.root = root
        self.args = args
        self.root.title("BWTEK Spectrometer")
        self.spec: Optional[Spectrometer] = None
        self.last_spectrum: Optional[Spectrum] = None
        # last_raw_spectrum always remains as acquired from the instrument.
        # Display corrections are applied to a copy so the user can toggle raw/dark/Tx/Abs
        # without taking another scan or losing the original ADC values.
        self.last_raw_spectrum: Optional[Spectrum] = None
        self.dark: Optional[List[float]] = None
        self.reference: Optional[List[float]] = None
        self.live = False
        self.worker_queue: "queue.Queue[Tuple[str, Any]]" = queue.Queue()
        self._last_applied_settings: Optional[Tuple[Any, ...]] = None

        self.model_var = tk.StringVar(value=args.model)
        self.port_var = tk.StringVar(value=args.port or "")
        self.baud_var = tk.StringVar(value=str(args.baud or MODEL_SPECS[args.model].default_baud))
        self.sim_var = tk.BooleanVar(value=bool(args.simulate or not args.port))
        self.integration_var = tk.StringVar(value=str(MODEL_SPECS[args.model].default_integration_ms))
        self.average_var = tk.StringVar(value="1")
        self.mode_var = tk.StringVar(value="compressed")
        self.correction_var = tk.StringVar(value="raw")
        self.smooth_var = tk.StringVar(value="1")
        self.smooth_kind_var = tk.StringVar(value="boxcar")
        self.median_filter_var = tk.StringVar(value="1")
        self.despike_var = tk.BooleanVar(value=False)
        self.despike_threshold_var = tk.StringVar(value="6")
        self.status_var = tk.StringVar(value="Disconnected")
        self.peak_var = tk.StringVar(value="Peak: -")
        # Default the display to the full ADC range: manual min 0, manual max ADC max.
        # Auto-min and auto-max are independent so you can keep the lower axis
        # fixed at zero while allowing the top of the plot to follow the signal.
        self.y_auto_min_var = tk.BooleanVar(value=False)
        self.y_auto_max_var = tk.BooleanVar(value=False)
        self.y_min_var = tk.StringVar(value="0")
        self.y_max_var = tk.StringVar(value=str(MODEL_SPECS[args.model].adc_max))
        self.black_level_var = tk.StringVar(value="")
        self.hot_pixel_scale_var = tk.DoubleVar(value=1.0)
        self.hot_pixel_scale_label_var = tk.StringVar(value="1.000")
        self.x_axis_var = tk.StringVar(value="pixel")
        self.show_color_background_var = tk.BooleanVar(value=False)
        self.show_references_var = tk.BooleanVar(value=True)
        self.show_legend_var = tk.BooleanVar(value=True)
        self.dark_mode_var = tk.BooleanVar(value=False)
        self.acq_indicator_var = tk.StringVar(value="● Idle")
        self.calibration_coefficients: Optional[List[float]] = None
        self.ptc_result: Optional[Dict[str, float]] = None
        self.cal_a0_var = tk.StringVar(value="")
        self.cal_a1_var = tk.StringVar(value="")
        self.cal_a2_var = tk.StringVar(value="")
        self.cal_a3_var = tk.StringVar(value="")
        self.reference_traces: List[Tuple[str, Spectrum, str]] = []
        self.reference_colors = ["#d62728", "#2ca02c", "#9467bd", "#ff7f0e", "#8c564b", "#e377c2", "#17becf", "#bcbd22"]
        self.math_traces: List[Tuple[str, Spectrum, str, bool, float]] = []
        self.math_colors = ["#1f77b4", "#ff1493", "#00a6a6", "#7f3c8d", "#b8860b", "#2f4f4f", "#ff4500", "#4b0082"]
        self.csv_folder_var = tk.StringVar(value=os.getcwd())
        self.csv_filter_var = tk.StringVar(value="*.csv")
        self.ref_list_var = tk.StringVar(value="")

        self._build_widgets()
        self.apply_theme()
        self.root.after(50, self.draw_placeholder)
        self.root.after(200, self.load_default_cfg_if_present)
        self._poll_worker_queue()

    def _build_widgets(self) -> None:
        tk = self.tk
        ttk = self.ttk
        root = self.root
        root.columnconfigure(0, weight=1)
        root.rowconfigure(0, weight=1)
        self._build_menu_bar()

        middle = ttk.Frame(root, padding=(8, 8, 8, 8))
        middle.grid(row=0, column=0, sticky="nsew")
        middle.columnconfigure(1, weight=1)
        middle.rowconfigure(0, weight=1)

        self.sidebar = ttk.LabelFrame(middle, text="CSV references", padding=6)
        self.sidebar.grid(row=0, column=0, sticky="nsw", padx=(0, 8))
        self.sidebar.columnconfigure(0, weight=1)
        ttk.Label(self.sidebar, text="Folder").grid(row=0, column=0, sticky="w")
        folder_entry = ttk.Entry(self.sidebar, textvariable=self.csv_folder_var, width=26)
        folder_entry.grid(row=1, column=0, columnspan=2, sticky="ew")
        attach_tooltip(folder_entry, "Folder to scan for exported CSV files.")
        browse_btn = ttk.Button(self.sidebar, text="Browse", command=self.browse_csv_folder)
        browse_btn.grid(row=2, column=0, sticky="ew", pady=(4, 0))
        attach_tooltip(browse_btn, "Choose a folder containing saved spectrum CSV files.")
        refresh_btn = ttk.Button(self.sidebar, text="Refresh", command=self.refresh_csv_browser)
        refresh_btn.grid(row=2, column=1, sticky="ew", pady=(4, 0), padx=(4, 0))
        attach_tooltip(refresh_btn, "Refresh the CSV file list from the selected folder.")
        self.csv_listbox = tk.Listbox(self.sidebar, height=11, width=32, exportselection=False)
        self.csv_listbox.grid(row=3, column=0, columnspan=2, sticky="nsew", pady=(6, 0))
        self.csv_listbox.bind("<Double-Button-1>", lambda _event: self.load_selected_csv_reference())
        attach_tooltip(self.csv_listbox, "Double-click a CSV, or select one and click Load reference.")
        load_ref_btn = ttk.Button(self.sidebar, text="Load reference", command=self.load_selected_csv_reference)
        load_ref_btn.grid(row=4, column=0, sticky="ew", pady=(6, 0))
        attach_tooltip(load_ref_btn, "Overlay the selected CSV as a reference trace using the next available color.")
        save_sidebar_btn = ttk.Button(self.sidebar, text="Save CSV", command=self.save_csv)
        save_sidebar_btn.grid(row=4, column=1, sticky="ew", pady=(6, 0), padx=(4, 0))
        attach_tooltip(save_sidebar_btn, "Save the most recent spectrum to CSV or JSON.")
        dark_ref_btn = ttk.Button(self.sidebar, text="Use as dark", command=self.load_selected_csv_as_dark)
        dark_ref_btn.grid(row=5, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        attach_tooltip(dark_ref_btn, "Use the selected exported CSV as the per-pixel dark / black-level correction trace. Uses the intensity column by default.")
        ttk.Label(self.sidebar, text="Loaded references").grid(row=6, column=0, columnspan=2, sticky="w", pady=(10, 0))
        self.reference_listbox = tk.Listbox(self.sidebar, height=5, width=32, exportselection=False)
        self.reference_listbox.grid(row=7, column=0, columnspan=2, sticky="ew", pady=(4, 0))
        remove_ref_btn = ttk.Button(self.sidebar, text="Remove selected", command=self.remove_selected_reference)
        remove_ref_btn.grid(row=8, column=0, sticky="ew", pady=(6, 0))
        attach_tooltip(remove_ref_btn, "Remove the selected reference trace from the plot.")
        clear_ref_btn = ttk.Button(self.sidebar, text="Clear all", command=self.clear_reference_traces)
        clear_ref_btn.grid(row=8, column=1, sticky="ew", pady=(6, 0), padx=(4, 0))
        attach_tooltip(clear_ref_btn, "Remove all loaded reference traces from the plot.")

        self.canvas = tk.Canvas(middle, background="white", height=420)
        self.canvas.grid(row=0, column=1, sticky="nsew")
        self.canvas.bind("<Motion>", self.on_plot_motion)
        self.canvas.bind("<Leave>", self.on_plot_leave)
        self.root.after(100, self.refresh_csv_browser)

        settings = ttk.Frame(root, padding=(8, 0, 8, 8))
        settings.grid(row=1, column=0, sticky="ew")
        ttk.Label(settings, text="Integration ms").grid(row=0, column=0, sticky="w")
        ttk.Entry(settings, textvariable=self.integration_var, width=8).grid(row=0, column=1)
        ttk.Label(settings, text="Average").grid(row=0, column=2, padx=(10, 0), sticky="w")
        ttk.Entry(settings, textvariable=self.average_var, width=8).grid(row=0, column=3)
        ttk.Label(settings, text="Mode").grid(row=0, column=4, padx=(10, 0), sticky="w")
        ttk.Combobox(settings, textvariable=self.mode_var, values=["compressed", "ascii", "binary"], width=12, state="readonly").grid(row=0, column=5)
        ttk.Label(settings, text="Smooth").grid(row=0, column=6, padx=(10, 0), sticky="w")
        smooth_entry = ttk.Entry(settings, textvariable=self.smooth_var, width=6)
        smooth_entry.grid(row=0, column=7)
        attach_tooltip(smooth_entry, "Boxcar smoothing width. Change it and use File > Correction > Redraw, or Redraw scale, to reprocess the stored raw scan without reacquiring.")
        acquire_btn = ttk.Button(settings, text="Acquire", command=self.acquire_once)
        acquire_btn.grid(row=0, column=8, padx=(10, 0))
        attach_tooltip(acquire_btn, "Take one scan using the current integration, averaging, mode, correction, and smoothing settings.")
        live_btn = ttk.Button(settings, text="Live", command=self.toggle_live)
        live_btn.grid(row=0, column=9)
        attach_tooltip(live_btn, "Start or stop continuous acquisition. The plot stays visible while the next scan runs.")
        auto_btn = ttk.Button(settings, text="Auto expose", command=self.auto_expose)
        auto_btn.grid(row=0, column=10)
        attach_tooltip(auto_btn, "Automatically choose an integration time that keeps the peak below saturation.")

        y_frame = ttk.Frame(settings)
        y_frame.grid(row=1, column=0, columnspan=12, sticky="w", pady=(8, 0))
        y_auto_min = ttk.Checkbutton(y_frame, text="Auto Y min", variable=self.y_auto_min_var, command=self.redraw_last_spectrum)
        y_auto_min.grid(row=0, column=0, sticky="w")
        attach_tooltip(y_auto_min, "Automatically choose the lower Y-axis limit. Leave off to use Manual Y min, usually 0.")
        ttk.Label(y_frame, text="Manual Y min").grid(row=0, column=1, padx=(12, 0), sticky="w")
        y_min_entry = ttk.Entry(y_frame, textvariable=self.y_min_var, width=10)
        y_min_entry.grid(row=0, column=2)
        y_auto_max = ttk.Checkbutton(y_frame, text="Auto Y max", variable=self.y_auto_max_var, command=self.redraw_last_spectrum)
        y_auto_max.grid(row=0, column=3, padx=(14, 0), sticky="w")
        attach_tooltip(y_auto_max, "Automatically choose the upper Y-axis limit. Leave off to use Manual Y max, usually ADC max.")
        ttk.Label(y_frame, text="Manual Y max").grid(row=0, column=4, padx=(12, 0), sticky="w")
        y_max_entry = ttk.Entry(y_frame, textvariable=self.y_max_var, width=10)
        y_max_entry.grid(row=0, column=5)
        redraw_btn = ttk.Button(y_frame, text="Redraw scale", command=self.redraw_last_spectrum)
        redraw_btn.grid(row=0, column=6, padx=(10, 0))
        attach_tooltip(redraw_btn, "Apply the current Y-axis settings to the already displayed spectrum.")

        status = ttk.Frame(root, padding=(8, 0, 8, 8))
        status.grid(row=2, column=0, sticky="ew")
        status.columnconfigure(1, weight=1)
        ttk.Label(status, textvariable=self.status_var).grid(row=0, column=0, sticky="w")
        ttk.Label(status, textvariable=self.peak_var).grid(row=0, column=1, sticky="e")
        self.acq_indicator_label = tk.Label(status, textvariable=self.acq_indicator_var, fg="#008000")
        self.acq_indicator_label.grid(row=0, column=2, sticky="e", padx=(18, 0))
        attach_tooltip(self.acq_indicator_label, "Green means idle; red means a scan or command is currently running.")

        self.log = tk.Text(root, height=6)
        self.log.grid(row=3, column=0, sticky="ew", padx=8, pady=(0, 8))

    def _build_menu_bar(self) -> None:
        tk = self.tk
        menu = tk.Menu(self.root)
        file_menu = tk.Menu(menu, tearoff=False)
        file_menu.add_command(label="Save CFG...", command=self.save_cfg)
        file_menu.add_command(label="Load CFG...", command=self.load_cfg)
        file_menu.add_separator()
        file_menu.add_command(label="Calibration...", command=self.open_calibration_window)
        file_menu.add_command(label="Correction...", command=self.open_correction_window)
        menu.add_cascade(label="File", menu=file_menu)

        math_menu = tk.Menu(menu, tearoff=False)
        math_menu.add_command(label="Trace math...", command=self.open_math_window)
        menu.add_cascade(label="Math", menu=math_menu)

        view_menu = tk.Menu(menu, tearoff=False)
        view_menu.add_checkbutton(label="CSV references area", variable=self.show_references_var, command=self.update_reference_area_visibility)
        view_menu.add_checkbutton(label="Plot key", variable=self.show_legend_var, command=self.redraw_last_spectrum)
        view_menu.add_checkbutton(label="Color background", variable=self.show_color_background_var, command=self.redraw_last_spectrum)
        view_menu.add_checkbutton(label="Dark mode", variable=self.dark_mode_var, command=self.apply_theme)
        menu.add_cascade(label="View", menu=view_menu)

        serial_menu = tk.Menu(menu, tearoff=False)
        serial_menu.add_command(label="Connection settings...", command=self.open_serial_window)
        serial_menu.add_separator()
        serial_menu.add_command(label="Connect", command=self.connect)
        serial_menu.add_command(label="Disconnect", command=self.disconnect)
        serial_menu.add_command(label="Query", command=self.query)
        serial_menu.add_command(label="Init", command=self.initialize)
        menu.add_cascade(label="Serial", menu=serial_menu)
        self.root.configure(menu=menu)

    def update_reference_area_visibility(self) -> None:
        if hasattr(self, "sidebar"):
            if self.show_references_var.get():
                self.sidebar.grid()
            else:
                self.sidebar.grid_remove()
        self.redraw_last_spectrum()

    def math_source_options(self) -> List[Tuple[str, Spectrum]]:
        """Return traces that can be used as operands for trace math."""
        options: List[Tuple[str, Spectrum]] = []
        if self.last_spectrum is not None:
            options.append(("Current displayed", self.last_spectrum))
        if self.last_raw_spectrum is not None:
            options.append(("Current raw", self.last_raw_spectrum))
        for label, spectrum, _color in self.reference_traces:
            options.append(("Ref: " + label, spectrum))
        for label, spectrum, _color, _enabled, _offset in self.math_traces:
            options.append(("Math: " + label, spectrum))
        return options

    def math_trace_for_plot(self) -> List[Tuple[str, Spectrum, str]]:
        traces: List[Tuple[str, Spectrum, str]] = []
        for label, spectrum, color, enabled, y_offset in self.math_traces:
            if not enabled:
                continue
            if abs(float(y_offset)) > 1e-12:
                # Apply the Y offset only to the plotted math trace. The saved math
                # trace data remains unchanged, so the user can keep adjusting the
                # offset interactively without accumulating changes.
                shifted = Spectrum(
                    pixels=list(spectrum.pixels),
                    intensities=[float(v) + float(y_offset) for v in spectrum.intensities],
                    wavelengths_nm=list(spectrum.wavelengths_nm) if spectrum.wavelengths_nm is not None else None,
                    dark=list(spectrum.dark) if spectrum.dark is not None else None,
                    reference=list(spectrum.reference) if spectrum.reference is not None else None,
                    corrected=[float(v) + float(y_offset) for v in spectrum.corrected] if spectrum.corrected is not None else None,
                    metadata=dict(spectrum.metadata),
                )
                shifted.metadata["y_offset"] = float(y_offset)
                traces.append(("%s %+g" % (label, float(y_offset)), shifted, color))
            else:
                traces.append((label, spectrum, color))
        return traces

    def update_math_listbox(self, listbox: Optional[Any] = None) -> None:
        lb = listbox if listbox is not None else getattr(self, "math_listbox", None)
        if lb is None:
            return
        lb.delete(0, "end")
        for index, (label, _spectrum, color, enabled, y_offset) in enumerate(self.math_traces):
            state = "shown" if enabled else "hidden"
            offset_note = "" if abs(float(y_offset)) < 1e-12 else "  offset=%+g" % float(y_offset)
            lb.insert("end", "%d. [%s] %s%s  %s" % (index + 1, state, label, offset_note, color))

    def make_math_spectrum(self, a: Spectrum, b: Spectrum, operation: str) -> Spectrum:
        """Create a math trace by aligning two spectra on pixel number."""
        a_values = a.active_values()
        b_values = b.active_values()
        a_by_pixel: Dict[int, Tuple[float, Optional[float]]] = {}
        b_by_pixel: Dict[int, Tuple[float, Optional[float]]] = {}
        for i, pixel in enumerate(a.pixels):
            wl = a.wavelengths_nm[i] if a.wavelengths_nm is not None and i < len(a.wavelengths_nm) else None
            if i < len(a_values):
                a_by_pixel[int(pixel)] = (float(a_values[i]), wl)
        for i, pixel in enumerate(b.pixels):
            wl = b.wavelengths_nm[i] if b.wavelengths_nm is not None and i < len(b.wavelengths_nm) else None
            if i < len(b_values):
                b_by_pixel[int(pixel)] = (float(b_values[i]), wl)
        common_pixels = sorted(set(a_by_pixel).intersection(b_by_pixel))
        if not common_pixels:
            raise ConfigurationError("selected traces have no overlapping pixel numbers")

        pixels: List[int] = []
        wavelengths: List[float] = []
        have_wavelengths = True
        values: List[float] = []
        op = operation.strip().lower()
        eps = 1e-12
        for pixel in common_pixels:
            av, aw = a_by_pixel[pixel]
            bv, bw = b_by_pixel[pixel]
            if op in ("a + b", "add"):
                out = av + bv
            elif op in ("a - b", "subtract a-b"):
                out = av - bv
            elif op in ("b - a", "subtract b-a"):
                out = bv - av
            elif op in ("a * b", "multiply"):
                out = av * bv
            elif op in ("a / b", "divide a/b"):
                out = av / bv if abs(bv) > eps else float("nan")
            elif op in ("b / a", "divide b/a"):
                out = bv / av if abs(av) > eps else float("nan")
            elif op in ("average", "(a + b) / 2"):
                out = (av + bv) / 2.0
            elif op in ("transmission a/b %", "a / b * 100"):
                out = (av / bv * 100.0) if abs(bv) > eps else float("nan")
            elif op in ("transmission b/a %", "b / a * 100"):
                out = (bv / av * 100.0) if abs(av) > eps else float("nan")
            elif op in ("absorbance -log10(a/b)", "-log10(a/b)"):
                ratio = av / bv if abs(bv) > eps else float("nan")
                out = -math.log10(ratio) if ratio > 0 and math.isfinite(ratio) else float("nan")
            elif op in ("absorbance -log10(b/a)", "-log10(b/a)"):
                ratio = bv / av if abs(av) > eps else float("nan")
                out = -math.log10(ratio) if ratio > 0 and math.isfinite(ratio) else float("nan")
            else:
                raise ConfigurationError("unknown math operation %r" % operation)
            pixels.append(pixel)
            values.append(out)
            wl = aw if aw is not None else bw
            if wl is None:
                have_wavelengths = False
            else:
                wavelengths.append(float(wl))
        wavelength_list: Optional[List[float]] = wavelengths if have_wavelengths and len(wavelengths) == len(values) else None
        return Spectrum(pixels=pixels, intensities=values, wavelengths_nm=wavelength_list, metadata={"trace_math_operation": operation})

    def open_math_window(self) -> None:
        tk = self.tk
        ttk = self.ttk
        win = tk.Toplevel(self.root)
        win.title("Trace math")
        win.resizable(True, True)
        frame = ttk.Frame(win, padding=10)
        frame.grid(row=0, column=0, sticky="nsew")
        win.columnconfigure(0, weight=1)
        win.rowconfigure(0, weight=1)
        frame.columnconfigure(1, weight=1)
        sources = self.math_source_options()
        names = [name for name, _spec in sources]
        source_map = {name: spec for name, spec in sources}
        a_var = tk.StringVar(value=names[0] if names else "")
        b_var = tk.StringVar(value=names[1] if len(names) > 1 else (names[0] if names else ""))
        op_values = [
            "A - B",
            "B - A",
            "A + B",
            "A * B",
            "A / B",
            "B / A",
            "Average",
            "Transmission A/B %",
            "Transmission B/A %",
            "Absorbance -log10(A/B)",
            "Absorbance -log10(B/A)",
        ]
        op_var = tk.StringVar(value="A - B")
        name_var = tk.StringVar(value="")
        ttk.Label(frame, text="Trace A").grid(row=0, column=0, sticky="w")
        a_combo = ttk.Combobox(frame, textvariable=a_var, values=names, width=34, state="readonly")
        a_combo.grid(row=0, column=1, sticky="ew", pady=(0, 6))
        ttk.Label(frame, text="Trace B").grid(row=1, column=0, sticky="w")
        b_combo = ttk.Combobox(frame, textvariable=b_var, values=names, width=34, state="readonly")
        b_combo.grid(row=1, column=1, sticky="ew", pady=(0, 6))
        ttk.Label(frame, text="Operation").grid(row=2, column=0, sticky="w")
        op_combo = ttk.Combobox(frame, textvariable=op_var, values=op_values, width=34, state="readonly")
        op_combo.grid(row=2, column=1, sticky="ew", pady=(0, 6))
        ttk.Label(frame, text="Output name").grid(row=3, column=0, sticky="w")
        name_entry = ttk.Entry(frame, textvariable=name_var, width=36)
        name_entry.grid(row=3, column=1, sticky="ew", pady=(0, 8))
        attach_tooltip(name_entry, "Optional custom label. Leave blank to label the math trace with its operation and source traces.")

        offset_var = tk.StringVar(value="0")
        ttk.Label(frame, text="Selected Y offset").grid(row=4, column=0, sticky="w")
        offset_entry = ttk.Entry(frame, textvariable=offset_var, width=12)
        offset_entry.grid(row=4, column=1, sticky="w", pady=(0, 8))
        attach_tooltip(offset_entry, "Display-only Y offset for the selected math trace. Use this to line up math traces with references.")

        self.math_listbox = tk.Listbox(frame, height=8, width=72, exportselection=False)
        self.math_listbox.grid(row=6, column=0, columnspan=2, sticky="nsew", pady=(10, 0))
        frame.rowconfigure(6, weight=1)

        def refresh_sources() -> None:
            nonlocal sources, names, source_map
            sources = self.math_source_options()
            names = [name for name, _spec in sources]
            source_map = {name: spec for name, spec in sources}
            a_combo.configure(values=names)
            b_combo.configure(values=names)
            if names and a_var.get() not in names:
                a_var.set(names[0])
            if names and b_var.get() not in names:
                b_var.set(names[1] if len(names) > 1 else names[0])
            self.update_math_listbox(self.math_listbox)

        def add_trace() -> None:
            try:
                if a_var.get() not in source_map or b_var.get() not in source_map:
                    raise ConfigurationError("load or acquire at least two traces first")
                a_name = a_var.get()
                b_name = b_var.get()
                op_name = op_var.get()
                spectrum = self.make_math_spectrum(source_map[a_name], source_map[b_name], op_name)
                label = name_var.get().strip() or ("%s: %s | %s" % (op_name, a_name, b_name))
                spectrum.metadata["trace_math_label"] = label
                spectrum.metadata["trace_math_a"] = a_name
                spectrum.metadata["trace_math_b"] = b_name
                spectrum.metadata["trace_math_operation"] = op_name
                color = self.math_colors[len(self.math_traces) % len(self.math_colors)]
                self.math_traces.append((label, spectrum, color, True, 0.0))
                refresh_sources()
                self.redraw_last_spectrum()
                self.log_message("Created math trace %s" % label)
            except Exception as exc:
                self.log_message("ERROR creating math trace: %s" % exc)

        def toggle_selected() -> None:
            sel = self.math_listbox.curselection()
            if not sel:
                self.log_message("Select a math trace first")
                return
            i = int(sel[0])
            if 0 <= i < len(self.math_traces):
                label, spectrum, color, enabled, y_offset = self.math_traces[i]
                self.math_traces[i] = (label, spectrum, color, not enabled, y_offset)
                self.update_math_listbox(self.math_listbox)
                self.redraw_last_spectrum()

        def remove_selected() -> None:
            sel = self.math_listbox.curselection()
            if not sel:
                self.log_message("Select a math trace first")
                return
            i = int(sel[0])
            if 0 <= i < len(self.math_traces):
                label = self.math_traces[i][0]
                del self.math_traces[i]
                refresh_sources()
                self.redraw_last_spectrum()
                self.log_message("Removed math trace %s" % label)

        def clear_math() -> None:
            self.math_traces.clear()
            refresh_sources()
            self.redraw_last_spectrum()
            self.log_message("Cleared math traces")

        def load_selected_offset(_event: Any = None) -> None:
            sel = self.math_listbox.curselection()
            if not sel:
                return
            i = int(sel[0])
            if 0 <= i < len(self.math_traces):
                offset_var.set("%.12g" % float(self.math_traces[i][4]))

        def apply_selected_offset() -> None:
            sel = self.math_listbox.curselection()
            if not sel:
                self.log_message("Select a math trace first")
                return
            i = int(sel[0])
            try:
                new_offset = float(offset_var.get().strip() or "0")
            except Exception:
                self.log_message("ERROR: math trace Y offset must be a number")
                return
            if 0 <= i < len(self.math_traces):
                label, spectrum, color, enabled, _old_offset = self.math_traces[i]
                self.math_traces[i] = (label, spectrum, color, enabled, new_offset)
                self.update_math_listbox(self.math_listbox)
                self.math_listbox.selection_set(i)
                self.redraw_last_spectrum()
                self.log_message("Set math trace offset for %s to %+g" % (label, new_offset))

        self.math_listbox.bind("<<ListboxSelect>>", load_selected_offset)

        buttons = ttk.Frame(frame)
        buttons.grid(row=5, column=0, columnspan=2, sticky="ew")
        ttk.Button(buttons, text="Create math trace", command=add_trace).grid(row=0, column=0, sticky="ew")
        ttk.Button(buttons, text="Refresh sources", command=refresh_sources).grid(row=0, column=1, sticky="ew", padx=(4, 0))
        ttk.Button(buttons, text="Show/hide selected", command=toggle_selected).grid(row=0, column=2, sticky="ew", padx=(4, 0))
        ttk.Button(buttons, text="Apply Y offset", command=apply_selected_offset).grid(row=0, column=3, sticky="ew", padx=(4, 0))
        ttk.Button(buttons, text="Remove selected", command=remove_selected).grid(row=0, column=4, sticky="ew", padx=(4, 0))
        ttk.Button(buttons, text="Clear math", command=clear_math).grid(row=0, column=5, sticky="ew", padx=(4, 0))
        attach_tooltip(a_combo, "First operand for trace math. Use CSV references or the latest current scan.")
        attach_tooltip(b_combo, "Second operand for trace math. Traces are aligned by pixel number.")
        attach_tooltip(op_combo, "Math operation to compute point-by-point on matching pixel numbers.")
        refresh_sources()

    def open_serial_window(self) -> None:
        tk = self.tk
        ttk = self.ttk
        win = tk.Toplevel(self.root)
        win.title("Serial connection")
        win.resizable(False, False)
        frame = ttk.Frame(win, padding=10)
        frame.grid(row=0, column=0, sticky="nsew")
        ttk.Label(frame, text="Model").grid(row=0, column=0, sticky="w")
        model_combo = ttk.Combobox(frame, textvariable=self.model_var, values=sorted(MODEL_SPECS), width=10, state="readonly")
        model_combo.grid(row=0, column=1, sticky="ew")
        model_combo.bind("<<ComboboxSelected>>", lambda _event: self.on_model_changed())
        ttk.Label(frame, text="Port").grid(row=1, column=0, sticky="w", pady=(6, 0))
        ports = available_serial_ports()
        ttk.Combobox(frame, textvariable=self.port_var, values=ports, width=18).grid(row=1, column=1, sticky="ew", pady=(6, 0))
        ttk.Label(frame, text="Baud").grid(row=2, column=0, sticky="w", pady=(6, 0))
        ttk.Combobox(frame, textvariable=self.baud_var, values=[str(v) for v in sorted(BAUD_TO_CODE)], width=10).grid(row=2, column=1, sticky="ew", pady=(6, 0))
        sim_check = ttk.Checkbutton(frame, text="Simulate", variable=self.sim_var)
        sim_check.grid(row=3, column=0, columnspan=2, sticky="w", pady=(6, 0))
        buttons = ttk.Frame(frame)
        buttons.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        for i in range(4):
            buttons.columnconfigure(i, weight=1)
        ttk.Button(buttons, text="Connect", command=self.connect).grid(row=0, column=0, sticky="ew")
        ttk.Button(buttons, text="Disconnect", command=self.disconnect).grid(row=0, column=1, sticky="ew", padx=(4, 0))
        ttk.Button(buttons, text="Query", command=self.query).grid(row=0, column=2, sticky="ew", padx=(4, 0))
        ttk.Button(buttons, text="Init", command=self.initialize).grid(row=0, column=3, sticky="ew", padx=(4, 0))

    def open_calibration_window(self) -> None:
        tk = self.tk
        ttk = self.ttk
        win = tk.Toplevel(self.root)
        win.title("Wavelength calibration")
        frame = ttk.Frame(win, padding=10)
        frame.grid(row=0, column=0, sticky="nsew")
        ttk.Label(frame, text="X axis").grid(row=0, column=0, sticky="w")
        x_axis_combo = ttk.Combobox(frame, textvariable=self.x_axis_var, values=["pixel", "wavelength"], width=12, state="readonly")
        x_axis_combo.grid(row=0, column=1, sticky="w")
        x_axis_combo.bind("<<ComboboxSelected>>", lambda _event: self.redraw_last_spectrum())
        labels = ["A0", "A1", "A2", "A3"]
        vars_ = [self.cal_a0_var, self.cal_a1_var, self.cal_a2_var, self.cal_a3_var]
        for i, (label, var) in enumerate(zip(labels, vars_), start=1):
            ttk.Label(frame, text=label).grid(row=i, column=0, sticky="w", pady=(6, 0))
            entry = ttk.Entry(frame, textvariable=var, width=18)
            entry.grid(row=i, column=1, sticky="ew", pady=(6, 0))
            attach_tooltip(entry, "Wavelength polynomial coefficient: nm = A0 + A1*pixel + A2*pixel^2 + A3*pixel^3.")
        buttons = ttk.Frame(frame)
        buttons.grid(row=5, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        ttk.Button(buttons, text="Apply calibration", command=self.apply_calibration_from_fields).grid(row=0, column=0, sticky="ew")
        ttk.Button(buttons, text="Fit peaks", command=self.fit_calibration_dialog).grid(row=0, column=1, sticky="ew", padx=(4, 0))
        ttk.Button(buttons, text="Photon transfer curve", command=self.photon_transfer_curve_dialog).grid(row=0, column=2, sticky="ew", padx=(4, 0))
        ttk.Button(buttons, text="Clear calibration", command=self.clear_calibration).grid(row=0, column=3, sticky="ew", padx=(4, 0))

    def photon_transfer_curve_dialog(self) -> None:
        """Load and fit a photon transfer curve CSV to estimate gain/noise/black level."""
        tk = self.tk
        ttk = self.ttk
        from tkinter import filedialog, messagebox
        try:
            path = filedialog.askopenfilename(
                title="Load photon transfer curve CSV",
                filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
                initialdir=self.csv_folder_var.get().strip() or os.getcwd(),
            )
            if not path:
                return
            pairs = load_photon_transfer_csv(path)
            result = fit_photon_transfer_curve(pairs)
            self.ptc_result = dict(result)
            win = tk.Toplevel(self.root)
            win.title("Photon transfer curve calibration")
            frame = ttk.Frame(win, padding=10)
            frame.grid(row=0, column=0, sticky="nsew")
            win.columnconfigure(0, weight=1)
            ttk.Label(frame, text="Loaded: %s" % os.path.basename(path)).grid(row=0, column=0, columnspan=2, sticky="w")
            rows = [
                ("Points", "%.0f" % result["point_count"]),
                ("Fit slope", "%.8g variance/count" % result["slope_variance_per_count"]),
                ("Conversion gain", "%.8g e-/count" % result["conversion_gain_e_per_count"]),
                ("Intercept", "%.8g count^2" % result["intercept_variance"]),
                ("Estimated black level", "%.8g counts" % result["black_level_counts"]),
                ("Read noise", "%.8g counts  (%.8g e-)" % (result["read_noise_counts"], result["read_noise_electrons"])),
                ("Fit R^2", "%.6f" % result["r2"]),
            ]
            for i, (label, value) in enumerate(rows, start=1):
                ttk.Label(frame, text=label).grid(row=i, column=0, sticky="w", pady=(5, 0))
                ttk.Label(frame, text=value).grid(row=i, column=1, sticky="w", pady=(5, 0), padx=(12, 0))

            def apply_black() -> None:
                black = result.get("black_level_counts", float("nan"))
                if not math.isfinite(black):
                    messagebox.showerror("PTC", "The fitted black level is not finite.", parent=win)
                    return
                self.black_level_var.set("%.12g" % black)
                self.apply_black_level_from_field()
                self.log_message("Applied PTC black level %.6g counts" % black)

            button_frame = ttk.Frame(frame)
            button_frame.grid(row=len(rows) + 1, column=0, columnspan=2, sticky="ew", pady=(12, 0))
            ttk.Button(button_frame, text="Apply black level", command=apply_black).grid(row=0, column=0, sticky="ew")
            ttk.Button(button_frame, text="Close", command=win.destroy).grid(row=0, column=1, sticky="ew", padx=(6, 0))
            self.log_message("PTC fit: gain %.6g e-/count, black %.6g counts, R^2 %.4f" % (result["conversion_gain_e_per_count"], result["black_level_counts"], result["r2"]))
        except Exception as exc:
            self.log_message("ERROR fitting PTC: %s" % exc)

    def open_correction_window(self) -> None:
        tk = self.tk
        ttk = self.ttk
        win = tk.Toplevel(self.root)
        win.title("Correction")
        frame = ttk.Frame(win, padding=10)
        frame.grid(row=0, column=0, sticky="nsew")
        ttk.Label(frame, text="Correction mode").grid(row=0, column=0, sticky="w")
        ttk.Combobox(frame, textvariable=self.correction_var, values=["raw", "dark", "transmittance", "absorbance"], width=16, state="readonly").grid(row=0, column=1, sticky="ew")
        ttk.Label(frame, text="Black level").grid(row=1, column=0, sticky="w", pady=(8, 0))
        black_entry = ttk.Entry(frame, textvariable=self.black_level_var, width=14)
        black_entry.grid(row=1, column=1, sticky="ew", pady=(8, 0))
        attach_tooltip(black_entry, "Default scalar dark/black level in ADC counts.")

        ttk.Label(frame, text="Hot pixel compensation").grid(row=2, column=0, sticky="w", pady=(10, 0))
        comp_frame = ttk.Frame(frame)
        comp_frame.grid(row=2, column=1, sticky="ew", pady=(10, 0))
        comp_frame.columnconfigure(0, weight=1)
        comp_slider = ttk.Scale(
            comp_frame,
            from_=0.0,
            to=2.0,
            orient="horizontal",
            variable=self.hot_pixel_scale_var,
            command=self.on_hot_pixel_scale_changed,
        )
        comp_slider.grid(row=0, column=0, sticky="ew")
        attach_tooltip(comp_slider, "Multiplier applied to the black/dark trace before correction. 1.000 means normal subtraction; higher or lower values can suppress hot pixels when the detector baseline has shifted.")
        comp_value = ttk.Label(comp_frame, textvariable=self.hot_pixel_scale_label_var, width=7)
        comp_value.grid(row=0, column=1, sticky="e", padx=(8, 0))
        attach_tooltip(comp_value, "Current hot-pixel compensation multiplier applied to dark correction.")

        filter_frame = ttk.LabelFrame(frame, text="Display filters", padding=6)
        filter_frame.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        ttk.Label(filter_frame, text="Smoothing type").grid(row=0, column=0, sticky="w")
        smooth_type = ttk.Combobox(filter_frame, textvariable=self.smooth_kind_var, values=["none", "boxcar", "triangular", "gaussian", "savitzky-golay"], width=14, state="readonly")
        smooth_type.grid(row=0, column=1, sticky="w", padx=(8, 0))
        attach_tooltip(smooth_type, "Display-only smoothing algorithm. Savitzky-Golay preserves peak shapes well; Gaussian and triangular are gentle; boxcar is simple averaging.")
        ttk.Label(filter_frame, text="Width").grid(row=0, column=2, sticky="w", padx=(18, 0))
        smooth_entry = ttk.Entry(filter_frame, textvariable=self.smooth_var, width=8)
        smooth_entry.grid(row=0, column=3, sticky="w", padx=(8, 0))
        attach_tooltip(smooth_entry, "Display-only smoothing width. Use 1 to disable. Redraw applies this to the stored raw scan without reacquiring.")
        ttk.Label(filter_frame, text="Median width").grid(row=1, column=0, sticky="w", pady=(6, 0))
        median_entry = ttk.Entry(filter_frame, textvariable=self.median_filter_var, width=8)
        median_entry.grid(row=1, column=1, sticky="w", padx=(8, 0), pady=(6, 0))
        attach_tooltip(median_entry, "Display-only median filter width. Use 1 to disable. Even widths are rounded up to the next odd width.")
        despike_check = ttk.Checkbutton(filter_frame, text="Despike", variable=self.despike_var)
        despike_check.grid(row=1, column=2, sticky="w", padx=(18, 0), pady=(6, 0))
        attach_tooltip(despike_check, "Replace isolated hot-pixel spikes using a local median/MAD detector before smoothing.")
        ttk.Label(filter_frame, text="Threshold").grid(row=1, column=3, sticky="w", pady=(6, 0))
        despike_entry = ttk.Entry(filter_frame, textvariable=self.despike_threshold_var, width=8)
        despike_entry.grid(row=1, column=4, sticky="w", padx=(8, 0), pady=(6, 0))
        attach_tooltip(despike_entry, "Despike threshold in local robust-sigma units. Try 5-8; higher preserves more sharp peaks.")

        buttons = ttk.Frame(frame)
        buttons.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        ttk.Button(buttons, text="Apply black level", command=self.apply_black_level_from_field).grid(row=0, column=0, sticky="ew")
        ttk.Button(buttons, text="Load Dark CSV", command=self.load_dark_csv).grid(row=0, column=1, sticky="ew", padx=(4, 0))
        ttk.Button(buttons, text="Capture Dark", command=self.capture_dark).grid(row=0, column=2, sticky="ew", padx=(4, 0))
        ttk.Button(buttons, text="Capture Reference", command=self.capture_reference).grid(row=0, column=3, sticky="ew", padx=(4, 0))
        hp_btn = ttk.Button(buttons, text="Hot pixel compensation", command=self.auto_hot_pixel_compensation)
        hp_btn.grid(row=0, column=4, sticky="ew", padx=(4, 0))
        attach_tooltip(hp_btn, "Automatically choose the dark-trace multiplier that makes the corrected waveform smoothest by suppressing sharp hot-pixel artifacts.")
        ttk.Button(buttons, text="Redraw", command=self.redraw_corrections_from_window).grid(row=0, column=5, sticky="ew", padx=(4, 0))
    def apply_theme(self, redraw: bool = True) -> None:
        """Apply light/dark UI colors without requiring any external theme packages."""
        dark = bool(self.dark_mode_var.get()) if hasattr(self, "dark_mode_var") else False
        self.bg_color = "#1e1f22" if dark else "#f0f0f0"
        self.panel_bg_color = "#2b2d31" if dark else "#f0f0f0"
        self.field_bg_color = "#1e1f22" if dark else "white"
        self.text_color = "#e8e8e8" if dark else "#111111"
        self.muted_text_color = "#c7c7c7" if dark else "#555555"
        self.plot_bg_color = "#24262b" if dark else "white"
        self.tooltip_bg_color = "#2d3036" if dark else "#ffffe0"
        self.tooltip_outline_color = "#7e8491" if dark else "#777777"
        self.cursor_color = "#aaaaaa" if dark else "#888888"
        try:
            self.root.configure(bg=self.bg_color)
        except Exception:
            pass
        try:
            style = self.ttk.Style(self.root)
            # clam permits fieldbackground and is present with Tk on Windows/macOS/Linux.
            try:
                style.theme_use("clam")
            except Exception:
                pass
            style.configure(".", background=self.panel_bg_color, foreground=self.text_color, fieldbackground=self.field_bg_color)
            style.configure("TFrame", background=self.panel_bg_color)
            style.configure("TLabelframe", background=self.panel_bg_color, foreground=self.text_color)
            style.configure("TLabelframe.Label", background=self.panel_bg_color, foreground=self.text_color)
            style.configure("TLabel", background=self.panel_bg_color, foreground=self.text_color)
            style.configure("TCheckbutton", background=self.panel_bg_color, foreground=self.text_color)
            style.configure("TButton", background="#3a3d44" if dark else "#f5f5f5", foreground=self.text_color)
            style.configure("TEntry", fieldbackground=self.field_bg_color, foreground=self.text_color, insertcolor=self.text_color)
            style.configure("TCombobox", fieldbackground=self.field_bg_color, foreground=self.text_color, background=self.field_bg_color)
            try:
                self.root.option_add("*TCombobox*Listbox.background", self.field_bg_color)
                self.root.option_add("*TCombobox*Listbox.foreground", self.text_color)
                self.root.option_add("*TCombobox*Listbox.selectBackground", "#4a607a" if dark else "#cde5ff")
            except Exception:
                pass
        except Exception:
            pass
        def visit(widget: Any) -> None:
            try:
                cls = widget.winfo_class()
            except Exception:
                cls = ""
            try:
                if cls in ("Frame", "Labelframe", "TFrame"):
                    widget.configure(bg=self.panel_bg_color)
                elif cls == "Canvas":
                    widget.configure(bg=self.bg_color)
                    widget._dark_mode = dark
                elif cls == "Text":
                    widget.configure(bg=self.field_bg_color, fg=self.text_color, insertbackground=self.text_color)
                elif cls == "Listbox":
                    widget.configure(bg=self.field_bg_color, fg=self.text_color, selectbackground="#4a607a" if dark else "#cde5ff", selectforeground=self.text_color if dark else "#111111")
                elif cls == "Label":
                    widget.configure(bg=self.panel_bg_color, fg=self.text_color)
            except Exception:
                pass
            try:
                for child in widget.winfo_children():
                    visit(child)
            except Exception:
                pass
        visit(self.root)
        if hasattr(self, "canvas"):
            self.canvas._dark_mode = dark
        if hasattr(self, "acq_indicator_label"):
            # Preserve red/green indicator while updating its background.
            try:
                self.acq_indicator_label.configure(bg=self.panel_bg_color)
            except Exception:
                pass
        if redraw:
            if self.last_spectrum is not None:
                self.redraw_last_spectrum()
            elif hasattr(self, "canvas"):
                self.draw_placeholder()

    def draw_placeholder(self, message: str = "No spectrum yet. Click Acquire or Live to start.") -> None:
        self.canvas._spectrum_plot = None
        self.canvas.delete("all")
        self.canvas.update_idletasks()
        width = max(320, int(self.canvas.winfo_width() or 900))
        height = max(220, int(self.canvas.winfo_height() or 360))
        self.canvas.create_rectangle(20, 20, width - 20, height - 20, outline="#4a4d55" if self.dark_mode_var.get() else "#d0d0d0", fill=getattr(self, "plot_bg_color", "white"))
        self.canvas.create_text(width // 2, height // 2, text=message, fill=getattr(self, "muted_text_color", "#555555"), font=("TkDefaultFont", 12))

    def set_acquiring(self, acquiring: bool) -> None:
        self.acq_indicator_var.set("● Acquiring" if acquiring else "● Idle")
        if hasattr(self, "acq_indicator_label"):
            self.acq_indicator_label.configure(fg="#b00020" if acquiring else "#008000")

    def log_message(self, message: str) -> None:
        self.log.insert("end", time.strftime("%H:%M:%S ") + message + "\n")
        self.log.see("end")
        self.status_var.set(message)

    def _poll_worker_queue(self) -> None:
        try:
            while True:
                kind, payload = self.worker_queue.get_nowait()
                if kind == "log":
                    self.log_message(str(payload))
                elif kind == "spectrum":
                    # Payloads from acquisition workers are raw scans. Keep that raw data
                    # unchanged, then apply current plot-only corrections to a copy.
                    self.last_raw_spectrum = payload
                    displayed = self.make_display_spectrum(payload)
                    self.last_spectrum = displayed
                    self.draw_spectrum(displayed)
                    self.peak_var.set("Peak: %.6g, points: %d" % (displayed.peak(), len(displayed.intensities)))
                    auto_ms = payload.metadata.get("auto_expose_ms") if hasattr(payload, "metadata") else None
                    if auto_ms is not None:
                        self.integration_var.set(str(int(auto_ms)))
                        self._last_applied_settings = None
                        self.log_message("Auto exposure selected %d ms" % int(auto_ms))
                    note = payload.metadata.get("decode_note") if hasattr(payload, "metadata") else None
                    if note:
                        self.log_message(str(note))
                elif kind == "error":
                    self.log_message("ERROR: %s" % payload)
                elif kind == "redraw":
                    self.redraw_last_spectrum()
                elif kind == "acq_idle":
                    self.set_acquiring(False)
                elif kind == "live_done":
                    if self.live:
                        self.root.after(50, self.acquire_once)
        except queue.Empty:
            pass
        self.root.after(100, self._poll_worker_queue)

    def run_worker(self, func: Callable[[], Any], live_done: bool = False) -> None:
        self.set_acquiring(True)
        def target() -> None:
            try:
                result = func()
                if isinstance(result, Spectrum):
                    self.worker_queue.put(("spectrum", result))
                elif isinstance(result, tuple) and len(result) == 2 and result[0] == "log_redraw":
                    self.worker_queue.put(("log", result[1]))
                    self.worker_queue.put(("redraw", None))
                elif result is not None:
                    self.worker_queue.put(("log", result))
            except Exception as exc:
                self.worker_queue.put(("error", str(exc)))
            finally:
                self.worker_queue.put(("acq_idle", None))
                if live_done:
                    self.worker_queue.put(("live_done", None))
        threading.Thread(target=target, daemon=True).start()

    def connect(self) -> None:
        try:
            self.disconnect(silent=True)
            model = normalize_model_name(self.model_var.get())
            baud = int(self.baud_var.get()) if self.baud_var.get() else MODEL_SPECS[model].default_baud
            if self.sim_var.get():
                transport: Transport = SimulatorTransport(model=model)
                port_label = "simulator"
            else:
                port = self.port_var.get().strip()
                if not port:
                    raise ConfigurationError("enter a serial port or enable simulator")
                transport = PySerialTransport(port=port, baudrate=baud, timeout=float(self.args.timeout))
                port_label = port
            self.spec = Spectrometer(transport=transport, model=model, timeout=float(self.args.timeout))
            self._last_applied_settings = None
            self.log_message("Connected to %s at %s" % (model, port_label))
        except Exception as exc:
            self.log_message("ERROR: %s" % exc)

    def disconnect(self, silent: bool = False) -> None:
        if self.spec:
            try:
                self.spec.close()
            except Exception:
                pass
        self.spec = None
        if not silent:
            self.log_message("Disconnected")

    def require_spec(self) -> Spectrometer:
        if self.spec is None:
            self.connect()
        if self.spec is None:
            raise ConfigurationError("not connected")
        return self.spec

    def apply_settings(self) -> Spectrometer:
        spec = self.require_spec()
        mode = self.mode_var.get()
        integration = int(self.integration_var.get())
        average = int(self.average_var.get())
        coeff_key = tuple(round(float(c), 12) for c in self.calibration_coefficients) if self.calibration_coefficients else None
        wanted = (mode, integration, average, coeff_key)
        # Live acquisition should not resend three setup commands before every
        # scan unless the user actually changed a setting. This matters on the
        # older BTC100 because each command/ACK round trip over 9600 baud is slow.
        if self._last_applied_settings != wanted:
            spec.set_data_mode(mode)
            spec.set_integration_time(integration)
            spec.set_average(average)
            if self.calibration_coefficients is not None:
                # Store locally in the driver for wavelength tagging. We do not write
                # coefficients to the BTC100 flash unless the CLI set command is used.
                spec.coefficients = list(self.calibration_coefficients)
            self._last_applied_settings = wanted
        return spec

    def calibration_from_fields(self) -> List[float]:
        values = [self.cal_a0_var.get(), self.cal_a1_var.get(), self.cal_a2_var.get(), self.cal_a3_var.get()]
        if not any(v.strip() for v in values):
            raise ConfigurationError("enter A0..A3 coefficients or use Fit peaks")
        coeffs: List[float] = []
        for index, text in enumerate(values):
            text = text.strip()
            if text == "":
                coeffs.append(0.0)
            else:
                coeffs.append(float(text))
        return coeffs

    def set_calibration_fields(self, coeffs: Sequence[float]) -> None:
        fields = [self.cal_a0_var, self.cal_a1_var, self.cal_a2_var, self.cal_a3_var]
        for var, value in zip(fields, coeffs):
            var.set("%.12g" % float(value))

    def apply_calibration_from_fields(self) -> None:
        try:
            coeffs = self.calibration_from_fields()
            self.calibration_coefficients = coeffs
            self.x_axis_var.set("wavelength")
            self._last_applied_settings = None
            if self.spec is not None:
                self.spec.coefficients = list(coeffs)
            if self.last_spectrum is not None:
                apply_wavelength_calibration(self.last_spectrum, coeffs)
            for _label, ref_spectrum, _color in self.reference_traces:
                apply_wavelength_calibration(ref_spectrum, coeffs)
            for _label, math_spectrum, _color, _enabled, _offset in self.math_traces:
                apply_wavelength_calibration(math_spectrum, coeffs)
            for _label, math_spectrum, _color, _enabled, _offset in self.math_traces:
                apply_wavelength_calibration(math_spectrum, coeffs)
            self.redraw_last_spectrum()
            self.log_message("Applied wavelength calibration: %s" % ", ".join("%.6g" % c for c in coeffs))
        except Exception as exc:
            self.log_message("ERROR: %s" % exc)

    def clear_calibration(self) -> None:
        self.calibration_coefficients = None
        for var in (self.cal_a0_var, self.cal_a1_var, self.cal_a2_var, self.cal_a3_var):
            var.set("")
        self.x_axis_var.set("pixel")
        self._last_applied_settings = None
        if self.spec is not None:
            self.spec.coefficients = None
        if self.last_spectrum is not None:
            apply_wavelength_calibration(self.last_spectrum, None)
            self.redraw_last_spectrum()
        self.log_message("Cleared wavelength calibration")

    def fit_calibration_dialog(self) -> None:
        try:
            from tkinter import simpledialog
            example = (
                "Enter known peaks as pixel,wavelength_nm pairs.\n"
                "Use one pair per line. Example:\n"
                "120, 404.66\n"
                "644, 435.83\n"
                "1120, 546.07\n"
                "1490, 578.01"
            )
            text = simpledialog.askstring("Fit wavelength calibration", example, parent=self.root)
            if not text:
                return
            points = parse_calibration_points(text)
            coeffs = fit_wavelength_coefficients(points)
            self.set_calibration_fields(coeffs)
            self.calibration_coefficients = coeffs
            self.x_axis_var.set("wavelength")
            self._last_applied_settings = None
            if self.spec is not None:
                self.spec.coefficients = list(coeffs)
            if self.last_spectrum is not None:
                apply_wavelength_calibration(self.last_spectrum, coeffs)
            for _label, ref_spectrum, _color in self.reference_traces:
                apply_wavelength_calibration(ref_spectrum, coeffs)
            for _label, math_spectrum, _color, _enabled, _offset in self.math_traces:
                apply_wavelength_calibration(math_spectrum, coeffs)
            for _label, math_spectrum, _color, _enabled, _offset in self.math_traces:
                apply_wavelength_calibration(math_spectrum, coeffs)
            self.redraw_last_spectrum()
            degree = min(3, len(points) - 1)
            self.log_message("Fit wavelength calibration from %d point(s), degree %d" % (len(points), degree))
        except Exception as exc:
            self.log_message("ERROR: %s" % exc)

    def on_plot_leave(self, _event: Any = None) -> None:
        try:
            self.canvas.delete("cursor")
        except Exception:
            pass
        if self.last_spectrum is not None:
            self.peak_var.set("Peak: %.6g, points: %d" % (self.last_spectrum.peak(), len(self.last_spectrum.intensities)))

    def on_plot_motion(self, event: Any) -> None:
        plot = getattr(self.canvas, "_spectrum_plot", None)
        if not plot:
            return
        left = float(plot["left"])
        top = float(plot["top"])
        plot_w = float(plot["plot_w"])
        plot_h = float(plot["plot_h"])
        if event.x < left or event.x > left + plot_w or event.y < top or event.y > top + plot_h:
            self.on_plot_leave()
            return
        x_lo = float(plot["x_lo"])
        x_hi = float(plot["x_hi"])
        y_lo = float(plot["y_lo"])
        y_hi = float(plot["y_hi"])
        x_at_cursor = x_lo + (event.x - left) / (plot_w or 1.0) * (x_hi - x_lo)

        def sx_for_pick(x: float) -> float:
            return left + ((x - x_lo) / (x_hi - x_lo if x_hi != x_lo else 1.0)) * plot_w

        def sy_for_pick(y: float) -> float:
            return top + plot_h - ((y - y_lo) / (y_hi - y_lo if y_hi != y_lo else 1.0)) * plot_h

        best: Optional[Tuple[float, Dict[str, Any], int]] = None
        for trace in plot.get("traces", []):
            x_values = trace.get("x", [])
            y_values = trace.get("y", [])
            if not x_values or not y_values:
                continue
            # Snap to the nearest visible point on any plotted trace, not just
            # the current acquisition. Downsample for responsiveness on 2048+
            # point overlays while still keeping snap accuracy within a pixel or two.
            n = min(len(x_values), len(y_values))
            step = max(1, n // 2048)
            for i in range(0, n, step):
                xv = float(x_values[i])
                yv = float(y_values[i])
                if not (math.isfinite(xv) and math.isfinite(yv)):
                    continue
                px_i = sx_for_pick(xv)
                py_i = sy_for_pick(yv)
                distance = (px_i - event.x) * (px_i - event.x) + (py_i - event.y) * (py_i - event.y)
                if best is None or distance < best[0]:
                    best = (distance, trace, i)
        if best is None:
            return

        _distance, trace, idx = best
        spectrum: Spectrum = trace["spectrum"]
        x_values = trace["x"]
        y_values = trace["y"]
        pixel = spectrum.pixels[idx] if idx < len(spectrum.pixels) else idx
        wavelength = None
        if spectrum.wavelengths_nm is not None and idx < len(spectrum.wavelengths_nm):
            wavelength = spectrum.wavelengths_nm[idx]
        intensity = float(y_values[idx])

        def sx(x: float) -> float:
            return left + ((x - x_lo) / (x_hi - x_lo if x_hi != x_lo else 1.0)) * plot_w

        def sy(y: float) -> float:
            return top + plot_h - ((y - y_lo) / (y_hi - y_lo if y_hi != y_lo else 1.0)) * plot_h

        px = sx(float(x_values[idx]))
        py = sy(float(intensity))
        self.canvas.delete("cursor")
        self.canvas.create_line(px, top, px, top + plot_h, fill=getattr(self, "cursor_color", "#888888"), dash=(3, 3), tags="cursor")
        self.canvas.create_line(left, py, left + plot_w, py, fill=getattr(self, "cursor_color", "#888888"), dash=(3, 3), tags="cursor")
        self.canvas.create_oval(px - 3, py - 3, px + 3, py + 3, outline=str(trace.get("color", "#111111")), fill=getattr(self, "plot_bg_color", "white"), tags="cursor")
        wl_text = "n/a" if wavelength is None else "%.4g nm" % float(wavelength)
        label = "%s\npixel %d\nwl %s\ny %.6g" % (str(trace.get("label", "Trace")), int(pixel), wl_text, intensity)
        tx = min(max(px + 10, left + 4), left + plot_w - 150)
        ty = min(max(py - 64, top + 4), top + plot_h - 68)
        self.canvas.create_rectangle(tx, ty, tx + 146, ty + 62, fill=getattr(self, "tooltip_bg_color", "#ffffe0"), outline=getattr(self, "tooltip_outline_color", "#777777"), tags="cursor")
        self.canvas.create_text(tx + 6, ty + 5, anchor="nw", text=label, font=("TkDefaultFont", 9), fill=getattr(self, "text_color", "#111111"), tags="cursor")
        self.peak_var.set("%s   Pixel: %d   Wavelength: %s   Y: %.6g" % (str(trace.get("label", "Trace")), int(pixel), wl_text, intensity))

    def refresh_csv_browser(self) -> None:
        """Refresh the sidebar list of CSV files in the selected folder."""
        try:
            folder = self.csv_folder_var.get().strip() or os.getcwd()
            files = []
            if os.path.isdir(folder):
                for name in os.listdir(folder):
                    if name.lower().endswith(".csv"):
                        files.append(name)
            files.sort(key=lambda n: os.path.getmtime(os.path.join(folder, n)) if os.path.exists(os.path.join(folder, n)) else 0, reverse=True)
            self.csv_listbox.delete(0, "end")
            for name in files:
                self.csv_listbox.insert("end", name)
            self.log_message("CSV browser: %d file(s) in %s" % (len(files), folder))
        except Exception as exc:
            self.log_message("ERROR refreshing CSV browser: %s" % exc)

    def browse_csv_folder(self) -> None:
        from tkinter import filedialog
        folder = filedialog.askdirectory(initialdir=self.csv_folder_var.get() or os.getcwd())
        if folder:
            self.csv_folder_var.set(folder)
            self.refresh_csv_browser()

    def selected_csv_path(self) -> Optional[str]:
        selection = self.csv_listbox.curselection()
        if not selection:
            return None
        name = self.csv_listbox.get(selection[0])
        return os.path.join(self.csv_folder_var.get().strip() or os.getcwd(), name)

    def load_selected_csv_reference(self) -> None:
        path = self.selected_csv_path()
        if not path:
            self.log_message("Select a CSV file in the sidebar first")
            return
        try:
            spectrum = load_spectrum_csv(path)
            if self.calibration_coefficients is not None and spectrum.wavelengths_nm is None:
                apply_wavelength_calibration(spectrum, self.calibration_coefficients)
            label = os.path.basename(path)
            color = self.reference_colors[len(self.reference_traces) % len(self.reference_colors)]
            self.reference_traces.append((label, spectrum, color))
            self.update_reference_listbox()
            self.redraw_last_spectrum()
            self.log_message("Loaded reference trace %s" % label)
        except Exception as exc:
            self.log_message("ERROR loading reference CSV: %s" % exc)

    def load_selected_csv_as_dark(self) -> None:
        """Use the selected sidebar CSV as the current per-pixel dark spectrum."""
        path = self.selected_csv_path()
        if not path:
            self.log_message("Select a CSV file in the sidebar first")
            return
        self.load_dark_from_csv_path(path)

    def load_dark_csv(self) -> None:
        """Prompt for an exported CSV and load it as a per-pixel dark trace."""
        from tkinter import filedialog
        path = filedialog.askopenfilename(
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            initialdir=self.csv_folder_var.get().strip() or os.getcwd(),
        )
        if path:
            self.load_dark_from_csv_path(path)

    def load_dark_from_csv_path(self, path: str) -> None:
        """Load an exported scan CSV as the per-pixel black-level correction.

        Dark scans should subtract the detector counts that were actually measured
        during the covered-input acquisition, so the loader prefers the raw
        exported ``intensity`` column. If an older/hand-edited CSV lacks that
        column, it falls back to ``corrected`` and then ``dark``.
        """
        try:
            spectrum = load_spectrum_csv(path, preferred_columns=("intensity", "corrected", "dark"))
            if not spectrum.intensities:
                raise ConfigurationError("dark CSV contains no numeric samples")
            self.dark = [float(v) for v in spectrum.intensities]
            median_dark = scalar_black_level_from_dark(self.dark)
            if median_dark is not None:
                self.black_level_var.set("%.12g" % median_dark)
            self.correction_var.set("dark")
            self.redraw_last_spectrum()
            source_column = spectrum.metadata.get("source_column", "intensity") if hasattr(spectrum, "metadata") else "intensity"
            self.log_message("Loaded per-pixel dark from %s (%d points, column %s, median %.6g)" % (os.path.basename(path), len(self.dark), source_column, median_dark if median_dark is not None else float("nan")))
        except Exception as exc:
            self.log_message("ERROR loading dark CSV: %s" % exc)

    def update_reference_listbox(self) -> None:
        self.reference_listbox.delete(0, "end")
        for index, (label, _spectrum, color) in enumerate(self.reference_traces):
            self.reference_listbox.insert("end", "%d. %s  %s" % (index + 1, label, color))

    def remove_selected_reference(self) -> None:
        selection = self.reference_listbox.curselection()
        if not selection:
            self.log_message("Select a loaded reference trace first")
            return
        index = int(selection[0])
        if 0 <= index < len(self.reference_traces):
            label = self.reference_traces[index][0]
            del self.reference_traces[index]
            self.update_reference_listbox()
            self.redraw_last_spectrum()
            self.log_message("Removed reference trace %s" % label)

    def clear_reference_traces(self) -> None:
        self.reference_traces.clear()
        self.update_reference_listbox()
        self.redraw_last_spectrum()
        self.log_message("Cleared reference traces")

    def on_model_changed(self) -> None:
        """Update defaults that depend on the selected model."""
        try:
            model = normalize_model_name(self.model_var.get())
            spec = MODEL_SPECS[model]
            self.baud_var.set(str(spec.default_baud))
            self.integration_var.set(str(spec.default_integration_ms))
            # Keep the default manual 0..ADC max display for the selected model.
            if not self.y_auto_min_var.get():
                self.y_min_var.set("0")
            if not self.y_auto_max_var.get():
                self.y_max_var.set(str(spec.adc_max))
            self._last_applied_settings = None
            self.redraw_last_spectrum()
        except Exception as exc:
            self.log_message("ERROR: %s" % exc)

    def on_hot_pixel_scale_changed(self, _value: Any = None) -> None:
        """Update the displayed multiplier and redraw using the stored raw scan."""
        try:
            value = float(self.hot_pixel_scale_var.get())
        except Exception:
            value = 1.0
        self.hot_pixel_scale_label_var.set("%.3f" % value)
        # Scale changes are display-only, so use the stored raw scan and redraw.
        self.redraw_last_spectrum()

    def auto_hot_pixel_compensation(self) -> None:
        """Pick a dark-trace multiplier that minimizes high-frequency roughness."""
        try:
            raw = self.last_raw_spectrum if self.last_raw_spectrum is not None else self.last_spectrum
            if raw is None:
                raise ConfigurationError("acquire or load a scan first")
            dark_source = self.dark
            if dark_source is None:
                dark_source = self.scalar_dark_from_field(len(raw.pixels))
            if dark_source is None:
                raise ConfigurationError("capture/load a dark spectrum or enter a black level first")
            dark = align_series_to_pixels(dark_source, raw.pixels, "dark spectrum")
            scale = estimate_hot_pixel_compensation_scale(raw.intensities, dark)
            self.hot_pixel_scale_var.set(scale)
            self.hot_pixel_scale_label_var.set("%.3f" % scale)
            self.redraw_last_spectrum()
            self.log_message("Hot pixel compensation scale set to %.6g" % scale)
        except Exception as exc:
            self.log_message("ERROR: %s" % exc)

    def apply_black_level_from_field(self) -> None:
        """Apply a scalar black-level offset as the current dark spectrum."""
        try:
            text = self.black_level_var.get().strip()
            if not text:
                raise ConfigurationError("enter a black level in ADC counts")
            level = float(text)
            if not math.isfinite(level):
                raise ConfigurationError("black level must be finite")
            model = normalize_model_name(self.model_var.get())
            count = MODEL_SPECS[model].pixel_count
            self.dark = [level for _ in range(count)]
            self.redraw_last_spectrum()
            self.log_message("Applied scalar black level %.6g counts" % level)
        except Exception as exc:
            self.log_message("ERROR: %s" % exc)
    def redraw_corrections_from_window(self) -> None:
        """Redraw after correction controls changed, without modifying raw data.

        If no per-pixel dark has been captured/loaded yet, the black-level field is
        used as a plot-only scalar dark correction. Use Apply black level when you
        want that scalar saved as the current dark vector / CFG default.
        """
        self.redraw_last_spectrum()


    def default_cfg_path(self) -> str:
        """Return the default .cfg file path used for automatic GUI startup defaults."""
        base = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
        return os.path.join(base, "bwtek_spectrometer.cfg")

    def current_cfg_dict(self) -> Dict[str, Any]:
        """Build a JSON-safe configuration dictionary from the current GUI state."""
        dark_vector = spectrum_dark_to_config(self.dark)
        black_level = None
        if self.black_level_var.get().strip():
            black_level = float(self.black_level_var.get().strip())
        elif dark_vector is not None:
            black_level = scalar_black_level_from_dark(dark_vector)
        return {
            "format": "bwtek_spectrometer_cfg_v3",
            "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "model": normalize_model_name(self.model_var.get()),
            "baud": int(self.baud_var.get()) if self.baud_var.get().strip() else None,
            "integration_ms": int(self.integration_var.get()) if self.integration_var.get().strip() else None,
            "average": int(self.average_var.get()) if self.average_var.get().strip() else None,
            "data_mode": self.mode_var.get(),
            "correction": self.correction_var.get(),
            "black_level": black_level,
            "hot_pixel_compensation_scale": float(self.hot_pixel_scale_var.get()),
            "smooth_width": int(self.smooth_var.get() or "1"),
            "smooth_kind": self.smooth_kind_var.get(),
            "median_filter_width": int(self.median_filter_var.get() or "1"),
            "despike_enabled": bool(self.despike_var.get()),
            "despike_threshold": float(self.despike_threshold_var.get() or "6"),
            "ptc_result": dict(self.ptc_result) if self.ptc_result is not None else None,
            "dark_spectrum": dark_vector,
            "calibration_coefficients": list(self.calibration_coefficients) if self.calibration_coefficients is not None else None,
            "x_axis": self.x_axis_var.get(),
            "y_auto_min": bool(self.y_auto_min_var.get()),
            "y_auto_max": bool(self.y_auto_max_var.get()),
            "y_min": self.y_min_var.get(),
            "y_max": self.y_max_var.get(),
        }

    def save_cfg_to_path(self, path: str) -> None:
        """Save calibration, black level, and display defaults to a specific path."""
        save_spectrometer_config(path, self.current_cfg_dict())

    def apply_cfg_dict(self, cfg: Dict[str, Any]) -> None:
        """Apply a loaded configuration dictionary to the GUI state."""
        model = cfg.get("model")
        if model:
            self.model_var.set(normalize_model_name(str(model)))
        if cfg.get("baud") is not None:
            self.baud_var.set(str(int(cfg["baud"])))
        if cfg.get("integration_ms") is not None:
            self.integration_var.set(str(int(cfg["integration_ms"])))
        if cfg.get("average") is not None:
            self.average_var.set(str(int(cfg["average"])))
        if cfg.get("data_mode") in ("compressed", "ascii", "binary"):
            self.mode_var.set(str(cfg["data_mode"]))
        if cfg.get("correction") in ("raw", "dark", "transmittance", "absorbance"):
            self.correction_var.set(str(cfg["correction"]))
        coeffs = cfg.get("calibration_coefficients")
        if coeffs is not None:
            if not isinstance(coeffs, list) or len(coeffs) != 4:
                raise ConfigurationError("CFG calibration_coefficients must be a list of four numbers")
            coeffs = [float(c) for c in coeffs]
            self.calibration_coefficients = coeffs
            self.set_calibration_fields(coeffs)
            if self.spec is not None:
                self.spec.coefficients = list(coeffs)
        else:
            self.calibration_coefficients = None
            for var in (self.cal_a0_var, self.cal_a1_var, self.cal_a2_var, self.cal_a3_var):
                var.set("")
        if cfg.get("x_axis") in ("pixel", "wavelength"):
            self.x_axis_var.set(str(cfg["x_axis"]))
        elif self.calibration_coefficients is not None:
            self.x_axis_var.set("wavelength")
        dark = cfg.get("dark_spectrum")
        if isinstance(dark, list) and dark:
            self.dark = [float(v) for v in dark]
            scalar = cfg.get("black_level", scalar_black_level_from_dark(self.dark))
            self.black_level_var.set("%.12g" % float(scalar) if scalar is not None else "")
        elif cfg.get("black_level") is not None:
            level = float(cfg["black_level"])
            self.black_level_var.set("%.12g" % level)
            count = MODEL_SPECS[normalize_model_name(self.model_var.get())].pixel_count
            self.dark = [level for _ in range(count)]
        if cfg.get("hot_pixel_compensation_scale") is not None:
            try:
                scale = float(cfg["hot_pixel_compensation_scale"])
                self.hot_pixel_scale_var.set(max(0.0, min(2.0, scale)))
                self.hot_pixel_scale_label_var.set("%.3f" % float(self.hot_pixel_scale_var.get()))
            except Exception:
                pass
        if cfg.get("smooth_width") is not None:
            try:
                self.smooth_var.set(str(max(1, int(cfg["smooth_width"]))))
            except Exception:
                pass
        if cfg.get("smooth_kind") is not None:
            try:
                kind = str(cfg["smooth_kind"]).strip().lower()
                if kind in ("boxcar", "triangular", "gaussian", "savitzky-golay", "none"):
                    self.smooth_kind_var.set(kind)
            except Exception:
                pass
        if cfg.get("median_filter_width") is not None:
            try:
                self.median_filter_var.set(str(max(1, int(cfg["median_filter_width"]))))
            except Exception:
                pass
        if cfg.get("despike_enabled") is not None:
            try:
                self.despike_var.set(bool(cfg["despike_enabled"]))
            except Exception:
                pass
        if cfg.get("despike_threshold") is not None:
            try:
                self.despike_threshold_var.set("%.6g" % float(cfg["despike_threshold"]))
            except Exception:
                pass
        if isinstance(cfg.get("ptc_result"), dict):
            try:
                self.ptc_result = {str(k): float(v) for k, v in cfg["ptc_result"].items() if isinstance(v, (int, float))}
            except Exception:
                self.ptc_result = None
        if "y_auto_min" in cfg:
            self.y_auto_min_var.set(bool(cfg["y_auto_min"]))
        elif "y_auto_scale" in cfg:
            self.y_auto_min_var.set(bool(cfg["y_auto_scale"]))
        if "y_auto_max" in cfg:
            self.y_auto_max_var.set(bool(cfg["y_auto_max"]))
        elif "y_auto_scale" in cfg:
            self.y_auto_max_var.set(bool(cfg["y_auto_scale"]))
        if cfg.get("y_min") is not None:
            self.y_min_var.set(str(cfg.get("y_min")))
        if cfg.get("y_max") is not None:
            self.y_max_var.set(str(cfg.get("y_max")))
        if self.last_spectrum is not None:
            if self.calibration_coefficients is not None:
                apply_wavelength_calibration(self.last_spectrum, self.calibration_coefficients)
            self.redraw_last_spectrum()
        for _label, ref_spectrum, _color in self.reference_traces:
            if self.calibration_coefficients is not None:
                apply_wavelength_calibration(ref_spectrum, self.calibration_coefficients)
        self._last_applied_settings = None

    def load_cfg_from_path(self, path: str) -> None:
        """Load calibration, black level, and display defaults from a specific path."""
        self.apply_cfg_dict(load_spectrometer_config(path))

    def save_cfg(self) -> None:
        """Save calibration and black-level defaults to a .cfg file."""
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(
            defaultextension=".cfg",
            filetypes=[("Spectrometer config", "*.cfg"), ("JSON files", "*.json"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            self.save_cfg_to_path(path)
            self.log_message("Saved CFG %s" % path)
        except Exception as exc:
            self.log_message("ERROR saving CFG: %s" % exc)

    def load_cfg(self) -> None:
        """Load calibration and black-level defaults from a .cfg file."""
        from tkinter import filedialog
        path = filedialog.askopenfilename(
            filetypes=[("Spectrometer config", "*.cfg"), ("JSON files", "*.json"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            self.load_cfg_from_path(path)
            self.log_message("Loaded CFG %s" % path)
        except Exception as exc:
            self.log_message("ERROR loading CFG: %s" % exc)

    def save_default_cfg(self) -> None:
        """Save the current settings to the auto-loaded default .cfg path."""
        path = self.default_cfg_path()
        try:
            self.save_cfg_to_path(path)
            self.log_message("Saved default CFG %s" % path)
        except Exception as exc:
            self.log_message("ERROR saving default CFG: %s" % exc)

    def load_default_cfg(self) -> None:
        """Load the auto-loaded default .cfg path on demand."""
        path = self.default_cfg_path()
        try:
            if not os.path.exists(path):
                raise ConfigurationError("default CFG not found: %s" % path)
            self.load_cfg_from_path(path)
            self.log_message("Loaded default CFG %s" % path)
        except Exception as exc:
            self.log_message("ERROR loading default CFG: %s" % exc)

    def load_default_cfg_if_present(self) -> None:
        """Auto-load bwtek_spectrometer.cfg at startup when present."""
        path = self.default_cfg_path()
        if os.path.exists(path):
            try:
                self.load_cfg_from_path(path)
                self.log_message("Loaded default CFG %s" % path)
            except Exception as exc:
                self.log_message("ERROR loading default CFG: %s" % exc)

    def initialize(self) -> None:
        def work() -> str:
            spec = self.require_spec()
            spec.initialize()
            return "Initialized"
        self.run_worker(work)

    def query(self) -> None:
        def work() -> str:
            spec = self.require_spec()
            return json.dumps(spec.query_all(), sort_keys=True)
        self.run_worker(work)

    def acquire_once(self) -> None:
        self.log_message("Acquiring spectrum...")
        if not self.live or self.last_spectrum is None:
            self.draw_placeholder("Acquiring spectrum... this may take a few seconds at 9600 baud.")

        def work() -> Spectrum:
            # Always acquire and return raw instrument data. Correction mode, black
            # level, reference math, and smoothing are display-only operations applied
            # by make_display_spectrum() on the UI thread.
            spec = self.apply_settings()
            spectrum = spec.acquire()
            spectrum.metadata["correction"] = "raw"
            return spectrum
        self.run_worker(work, live_done=self.live)

    def toggle_live(self) -> None:
        self.live = not self.live
        self.log_message("Live acquisition %s" % ("started" if self.live else "stopped"))
        if self.live:
            self.acquire_once()

    def auto_expose(self) -> None:
        self.log_message("Auto exposure running...")
        def work() -> Spectrum:
            spec = self.apply_settings()
            chosen = spec.auto_expose()
            # Return a fresh raw scan at the selected integration time so the graph
            # immediately shows the result. The UI thread updates integration_var.
            spectrum = spec.acquire()
            spectrum.metadata["correction"] = "raw"
            spectrum.metadata["auto_expose_ms"] = int(chosen)
            return spectrum
        self.run_worker(work)

    def capture_dark(self) -> None:
        def work() -> str:
            spec = self.apply_settings()
            self.dark = spec.capture_dark()
            median_dark = scalar_black_level_from_dark(self.dark)
            if median_dark is not None:
                self.black_level_var.set("%.12g" % median_dark)
                return ("log_redraw", "Captured dark spectrum; median black level %.6g counts" % median_dark)
            return ("log_redraw", "Captured dark spectrum")
        self.run_worker(work)

    def capture_reference(self) -> None:
        def work() -> str:
            spec = self.apply_settings()
            self.reference = spec.capture_reference()
            return ("log_redraw", "Captured reference spectrum")
        self.run_worker(work)

    def save_csv(self) -> None:
        if self.last_spectrum is None:
            self.log_message("No spectrum to save")
            return
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("JSON files", "*.json"), ("All files", "*.*")],
        )
        if not path:
            return
        # Save the currently displayed correction, but keep the raw ADC counts in the intensity column.
        if self.last_raw_spectrum is not None:
            try:
                self.last_spectrum = self.make_display_spectrum(self.last_raw_spectrum)
            except Exception:
                pass
        if path.lower().endswith(".json"):
            self.last_spectrum.save_json(path)
        else:
            self.last_spectrum.save_csv(path)
        self.log_message("Saved %s" % path)

    def current_y_limits(self) -> Tuple[Optional[float], Optional[float]]:
        def parse_limit(text: str) -> Optional[float]:
            text = text.strip()
            return None if not text else float(text)
        y_min = None if self.y_auto_min_var.get() else parse_limit(self.y_min_var.get())
        y_max = None if self.y_auto_max_var.get() else parse_limit(self.y_max_var.get())
        if y_min is not None and y_max is not None and y_max <= y_min:
            raise ConfigurationError("manual Y max must be greater than manual Y min")
        return y_min, y_max

    def scalar_dark_from_field(self, count: int) -> Optional[List[float]]:
        """Return a scalar dark vector from the black-level field when present."""
        text = self.black_level_var.get().strip()
        if not text:
            return None
        level = float(text)
        if not math.isfinite(level):
            raise ConfigurationError("black level must be finite")
        return [level for _ in range(max(0, int(count)))]

    def make_display_spectrum(self, raw: Spectrum) -> Spectrum:
        """Build a display-only corrected copy from the stored raw scan.

        The raw Spectrum object is never modified. This makes Correction -> Redraw
        and changing raw/dark/transmittance/absorbance an immediate plot operation
        instead of requiring a new scan or permanently replacing the raw data.
        """
        display = Spectrum(
            pixels=list(raw.pixels),
            intensities=[float(v) for v in raw.intensities],
            wavelengths_nm=list(raw.wavelengths_nm) if raw.wavelengths_nm is not None else None,
            metadata=dict(raw.metadata),
        )
        if self.calibration_coefficients is not None and display.wavelengths_nm is None:
            apply_wavelength_calibration(display, self.calibration_coefficients)
        correction = self.correction_var.get().strip().lower() or "raw"
        smooth = max(1, int(self.smooth_var.get() or "1"))
        smooth_kind = self.smooth_kind_var.get().strip().lower() or "boxcar"
        median_width = max(1, int(self.median_filter_var.get() or "1"))
        despike_enabled = bool(self.despike_var.get())
        try:
            despike_threshold = float(self.despike_threshold_var.get() or "6")
        except Exception:
            despike_threshold = 6.0
        display.metadata["correction"] = correction
        display.metadata["raw_preserved"] = True
        display.metadata["smooth_width"] = smooth
        display.metadata["smooth_kind"] = smooth_kind
        display.metadata["median_filter_width"] = median_width
        display.metadata["despike_enabled"] = despike_enabled
        display.metadata["despike_threshold"] = despike_threshold

        try:
            if correction in ("raw", "none"):
                if smooth > 1 or median_width > 1:
                    display.corrected = apply_display_filters(display.intensities, median_width=median_width, smooth_width=smooth, smooth_kind=smooth_kind, despike_enabled=despike_enabled, despike_threshold=despike_threshold)
                    display.metadata["correction"] = "raw"
                return display

            dark_source = self.dark
            if dark_source is None:
                dark_source = self.scalar_dark_from_field(len(display.pixels))
            if dark_source is None:
                raise ConfigurationError("capture/load a dark spectrum or enter a black level first")
            dark = align_series_to_pixels(dark_source, display.pixels, "dark spectrum")
            dark_scale = float(self.hot_pixel_scale_var.get())
            if not math.isfinite(dark_scale):
                dark_scale = 1.0
            dark = scaled_series(dark, dark_scale)
            display.dark = list(dark)
            display.metadata["hot_pixel_compensation_scale"] = dark_scale

            if correction in ("dark", "dark-subtract", "dark_subtract"):
                values = subtract_dark(display.intensities, dark)
                display.corrected = values
            elif correction in ("transmittance", "transmission"):
                if self.reference is None:
                    raise ConfigurationError("capture/load a reference spectrum first")
                reference = align_series_to_pixels(self.reference, display.pixels, "reference spectrum")
                display.reference = list(reference)
                display.corrected = transmittance(display.intensities, dark, reference)
            elif correction == "absorbance":
                if self.reference is None:
                    raise ConfigurationError("capture/load a reference spectrum first")
                reference = align_series_to_pixels(self.reference, display.pixels, "reference spectrum")
                display.reference = list(reference)
                display.corrected = absorbance(display.intensities, dark, reference)
            else:
                raise ConfigurationError("unknown correction %r" % correction)

            if display.corrected is not None:
                # Median and smoothing are display-only operations. They are applied
                # after correction so the user can change them and redraw the stored
                # raw acquisition without taking another scan.
                display.corrected = apply_display_filters(display.corrected, median_width=median_width, smooth_width=smooth, smooth_kind=smooth_kind, despike_enabled=despike_enabled, despike_threshold=despike_threshold)
            return display
        except Exception:
            # Leave the raw data intact and re-raise so the GUI can log the issue.
            raise

    def redraw_last_spectrum(self) -> None:
        raw = self.last_raw_spectrum if self.last_raw_spectrum is not None else self.last_spectrum
        if raw is not None:
            try:
                displayed = self.make_display_spectrum(raw)
                self.last_spectrum = displayed
                self.draw_spectrum(displayed)
                self.peak_var.set("Peak: %.6g, points: %d" % (displayed.peak(), len(displayed.intensities)))
            except Exception as exc:
                self.log_message("ERROR: %s" % exc)

    def draw_spectrum(self, spectrum: Spectrum) -> None:
        y_min, y_max = self.current_y_limits()
        overlay_traces = list(self.reference_traces) + self.math_trace_for_plot()
        draw_spectrum_on_canvas(self.canvas, spectrum, title="BWTEK Spectrum", y_min=y_min, y_max=y_max, x_axis=self.x_axis_var.get(), reference_traces=overlay_traces, show_color_background=bool(self.show_color_background_var.get()), show_legend=bool(self.show_legend_var.get()))


def run_gui(args: argparse.Namespace) -> None:
    try:
        import tkinter as tk
    except ImportError as exc:
        raise ConfigurationError("Tkinter is not available in this Python installation") from exc
    root = tk.Tk()
    SpectrometerGUI(root, args)
    root.mainloop()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except KeyboardInterrupt:
        print("interrupted", file=sys.stderr)
        return 130
    except SpectrometerError as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
