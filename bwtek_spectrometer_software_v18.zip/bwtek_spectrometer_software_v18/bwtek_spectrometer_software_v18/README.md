# BWTEK Spectrometer Software v17

Run the GUI:

```powershell
python bwtek_spectrometer.py --model BTC100 --port COM4 gui
```

## v17 changes


- Added **File -> Calibration -> Photon transfer curve**. Load a PTC CSV with mean/variance columns to estimate conversion gain, read noise, and an optional black-level offset. The result can be applied directly to the black-level correction.
- Added an adjustable **Median filter** in **File -> Correction**.
- Smoothing is now explicitly display-only: change the boxcar smoothing or median-filter width after a scan and click **Redraw** to reprocess the stored raw acquisition without reacquiring.
- Added **View -> Dark mode**.
- Added labels for newly created math traces that include the operation and source traces by default.
- Added a display-only **Y offset** field for math traces in **Math -> Trace math...**.
- Moved **Save CSV** to the left CSV/reference panel beside **Load reference**.
- Improved auto exposure behavior so the selected integration time is written back into the GUI and followed by a fresh plotted scan.
- Cursor snapping searches the current trace, loaded CSV references, and visible math traces.

## Trace math

Open **Math -> Trace math...** to create plot overlays from two saved/reference/current traces.

Supported operations include addition, subtraction, multiplication, division, average, transmission %, and absorbance. Math traces are aligned by pixel number. You can show/hide traces, remove them, clear them, or apply a display-only Y offset to line them up against references.

## Correction workflow

The GUI keeps the most recent instrument scan as raw ADC data internally. Correction modes are applied only to a display copy, so you can switch between Raw, Dark, Transmittance, and Absorbance from **File -> Correction** and click **Redraw** without acquiring again or losing the original raw scan.

Correction behavior:

- Raw: plots the raw ADC counts.
- Dark: subtracts the per-pixel dark trace if one has been captured/loaded. If no per-pixel dark is loaded, the Black level field is used as a scalar plot-only dark correction.
- Transmittance/Absorbance: uses the stored raw scan, current dark correction, and captured reference trace.
- Save CSV writes the raw counts in the intensity column and the displayed correction in the corrected column when a correction is active.

## Other features

- Load a previously exported CSV scan as the per-pixel dark / black-level correction.
- Hot pixel compensation slider and auto button in **File -> Correction**.
- Wavelength X-axis ticks snap to 5 nm increments and display as whole numbers.
- Top menu bar:
  - File: Save CFG, Load CFG, Calibration, Correction
  - View: CSV references area, Plot key, Color background, Dark mode
  - Serial: Connection settings, Connect, Disconnect, Query, Init
- CSV reference browser can be shown or hidden from View.
- Plot hover readout searches all traces, including loaded CSV reference waveforms and math traces.
- Dark/transmittance/absorbance correction is tolerant of BTC100 short/long scan edge cases.

## v18 filtering and PTC notes

Display filters are now all plot-only and can be changed after acquisition from **File > Correction** followed by **Redraw**. Available filters:

- Median filter: good first step for isolated hot pixels.
- Despike: robust local median/MAD replacement for single-pixel spikes.
- Boxcar smoothing: simple moving average.
- Triangular smoothing: weighted moving average with less edge harshness than boxcar.
- Gaussian smoothing: gentle smoothing for noisy broadband spectra.
- Savitzky-Golay: quadratic local fit that preserves peak location/shape better than basic averaging.

`ILX511_estimated_ptc_template.csv` is included only as a software-test/template PTC. It is not a measured calibration for your spectrometer electronics. For real photon transfer calibration, capture flat-field frame pairs at several integration times, subtract the black level, then fit variance vs mean.

